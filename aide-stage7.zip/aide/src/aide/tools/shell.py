"""Command tools: run_command, run_background, read_background, stop_background."""
from __future__ import annotations

import time
from typing import Any

from .base import Tool, ToolContext, ToolResult
from .errors import ToolError
from .process import RunResult, clean_output
from .util import truncate_middle

MAX_COMMAND_CHARS = 20_000


def _cwd(ctx: ToolContext, given: str | None):
    if not given:
        return ctx.sandbox.root
    path = ctx.sandbox.resolve(given, must_exist=True)
    if not path.is_dir():
        raise ToolError(f"cwd '{given}' is not a directory.")
    return path


def _check_command(command: str) -> None:
    if not command.strip():
        raise ToolError("command is empty.")
    if "\x00" in command:
        raise ToolError("command contains a NUL character.")
    if len(command) > MAX_COMMAND_CHARS:
        raise ToolError(f"command is too long ({len(command)} characters). Put long scripts in a "
                        f"file with write_file and run that file.")


def format_run(res: RunResult, timeout: float) -> str:
    if res.timed_out:
        head = f"TIMED OUT after {timeout:g}s; the process and its children were killed. Partial output below."
    elif res.cancelled:
        head = "CANCELLED by the user; the process and its children were killed. Partial output below."
    else:
        head = f"exit code: {res.exit_code}  ({res.duration:.2f}s)"
    parts = [head]
    if res.leftover_killed:
        parts.append("Note: background processes started by this command were still running and "
                     "were killed. Use run_background for servers and other long-running processes.")
    if res.stdout.strip():
        parts.append("--- stdout ---\n" + res.stdout.rstrip("\n"))
    if res.stderr.strip():
        parts.append("--- stderr ---\n" + res.stderr.rstrip("\n"))
    if not res.stdout.strip() and not res.stderr.strip():
        parts.append("(no output)")
    return "\n".join(parts)


def _run_command(ctx: ToolContext, a: dict[str, Any]) -> ToolResult:
    from .process import run_shell
    command: str = a["command"]
    _check_command(command)
    cwd = _cwd(ctx, a.get("cwd"))
    timeout = float(a.get("timeout", ctx.limits.command_timeout))
    lim = ctx.limits
    if ctx.before_exec:
        ctx.before_exec(command)
    try:
        res = run_shell(command, cwd=cwd, timeout=timeout, cancel=ctx.cancel_event,
                        head=lim.command_output_head, tail=lim.command_output_tail)
    except OSError as exc:
        raise ToolError(f"Could not start the command: {exc.strerror or exc}") from exc
    ok = res.exit_code == 0 and not res.timed_out and not res.cancelled
    return ToolResult(ok, format_run(res, timeout), meta={
        "exit_code": res.exit_code, "timed_out": res.timed_out, "cancelled": res.cancelled,
        "duration": res.duration})


def _recent_output(text: str, limit: int = 6000) -> str:
    text = text.rstrip("\n")
    if len(text) <= limit:
        return text
    return f"[... {len(text) - limit} earlier characters not shown ...]\n{text[-limit:]}"


def _run_background(ctx: ToolContext, a: dict[str, Any]) -> ToolResult:
    command: str = a["command"]
    _check_command(command)
    cwd = _cwd(ctx, a.get("cwd"))
    if ctx.before_exec:
        ctx.before_exec(command)
    try:
        bg = ctx.background.start(command, cwd=cwd, name=a.get("name", ""),
                                  startup_wait=a.get("startup_wait", 1.5), cancel=ctx.cancel_event)
    except RuntimeError as exc:
        raise ToolError(str(exc)) from exc
    except OSError as exc:
        raise ToolError(f"Could not start the command: {exc.strerror or exc}") from exc
    text, bg.cursor, _ = bg.capture.read_from(0)
    lines = [f"Started {bg.ident} (pid {bg.pid}): {bg.command}", f"Status: {bg.status()}"]
    if text.strip():
        lines.append("Output so far:\n" + _recent_output(text))
    if bg.exit_code() is None:
        lines.append(f"Use read_background(id='{bg.ident}') to see new output and "
                     f"stop_background(id='{bg.ident}') to stop it.")
    ok = bg.exit_code() in (None, 0)
    return ToolResult(ok, "\n".join(lines), meta={"id": bg.ident, "pid": bg.pid})


def _read_background(ctx: ToolContext, a: dict[str, Any]) -> ToolResult:
    ident = a.get("id")
    if not ident:
        procs = ctx.background.list()
        if not procs:
            return ToolResult(True, "No background processes.")
        rows = [f"{p.ident}  {p.status():<22} pid {p.pid}  up {p.uptime():.0f}s  {p.name}" for p in procs]
        return ToolResult(True, "\n".join(rows))
    bg = ctx.background.get(ident)
    if bg is None:
        known = ", ".join(p.ident for p in ctx.background.list()) or "none"
        raise ToolError(f"Unknown background process '{ident}'. Known: {known}.")
    deadline = time.monotonic() + a.get("wait_seconds", 0)
    while (time.monotonic() < deadline and bg.exit_code() is None
           and bg.capture.total <= bg.cursor and not ctx.cancel_event.is_set()):
        time.sleep(0.05)
    text, bg.cursor, lost = bg.capture.read_from(bg.cursor)
    lines = [f"{bg.ident}: {bg.status()}  (pid {bg.pid}, up {bg.uptime():.0f}s)"]
    if lost:
        lines.append(f"[{lost} bytes of output were dropped: too much output between reads]")
    lines.append("New output:\n" + _recent_output(text) if text.strip() else "(no new output)")
    return ToolResult(True, "\n".join(lines))


def _stop_background(ctx: ToolContext, a: dict[str, Any]) -> ToolResult:
    bg = ctx.background.get(a["id"])
    if bg is None:
        known = ", ".join(p.ident for p in ctx.background.list()) or "none"
        raise ToolError(f"Unknown background process '{a['id']}'. Known: {known}.")
    was_running = bg.exit_code() is None
    ctx.background.stop(bg)
    text, bg.cursor, _ = bg.capture.read_from(bg.cursor)
    head = f"Stopped {bg.ident}." if was_running else f"{bg.ident} had already finished ({bg.status()})."
    return ToolResult(True, head + (f"\nFinal output:\n{_recent_output(text, 3000)}" if text.strip() else ""))


_CMD_PROPS = {
    "command": {"type": "string", "description": "Shell command line (bash). Runs with the workspace "
                                                 "as the working directory."},
    "cwd": {"type": "string", "description": "Subdirectory of the workspace to run in (default: the root)."},
}

TOOLS = [
    Tool(
        name="run_command",
        description=("Run a shell command in the workspace and wait for it to finish. Returns the exit "
                     "code, stdout and stderr (long output is shortened, keeping the end). stdin is "
                     "closed, so interactive programs fail instead of hanging; pass flags like -y. "
                     "Use it to run scripts, tests, linters, builds and git. Do NOT use it for servers "
                     "or other long-running processes (use run_background), and do not use it to read "
                     "or edit files when a file tool can do it."),
        parameters={"type": "object", "properties": {
            **_CMD_PROPS,
            "timeout": {"type": "integer", "minimum": 1, "maximum": 600,
                        "description": "Seconds before the command is killed. Default 120."},
        }, "required": ["command"]},
        handler=_run_command, kind="exec",
    ),
    Tool(
        name="run_background",
        description=("Start a long-running process (dev server, watcher) without waiting for it. "
                     "Returns an id and the first output after a short startup wait. Then use "
                     "run_command (e.g. curl) to test it, read_background for its logs and "
                     "stop_background to stop it."),
        parameters={"type": "object", "properties": {
            **_CMD_PROPS,
            "name": {"type": "string", "description": "Short label, e.g. 'web server'."},
            "startup_wait": {"type": "number", "minimum": 0, "maximum": 30,
                             "description": "Seconds to wait for startup output. Default 1.5."},
        }, "required": ["command"]},
        handler=_run_background, kind="exec",
    ),
    Tool(
        name="read_background",
        description=("Show new output of a background process since the last read, plus its status "
                     "(running / exited with code). Without id, list all background processes. "
                     "wait_seconds waits for new output or exit."),
        parameters={"type": "object", "properties": {
            "id": {"type": "string", "description": "e.g. 'bg1'. Omit to list all."},
            "wait_seconds": {"type": "number", "minimum": 0, "maximum": 30,
                             "description": "Wait up to this long for new output. Default 0."},
        }},
        handler=_read_background,  # only inspects processes this session started
    ),
    Tool(
        name="stop_background",
        description="Stop a background process (and its children) started with run_background.",
        parameters={"type": "object", "properties": {
            "id": {"type": "string", "description": "e.g. 'bg1'."}}, "required": ["id"]},
        handler=_stop_background,  # only affects processes the user already approved
    ),
]
