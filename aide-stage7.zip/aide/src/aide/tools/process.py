"""Running child processes: bounded output capture, process-group control, background jobs.

Design notes
------------
* Every child runs in its own session/process group, so a timeout or Ctrl+C can kill the
  whole tree (shell, compilers, dev servers, ...), not just the direct child.
* Output is captured by reader threads into bounded buffers (head + tail), so a command that
  prints gigabytes cannot exhaust memory; the middle is dropped and counted.
* stdin is /dev/null: anything that waits for input fails fast instead of hanging.
* Secrets meant for aide itself (OMNIROUTE_*, AIDE_*) are removed from the child environment.
"""
from __future__ import annotations

import atexit
import os
import re
import shutil
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

# --------------------------------------------------------------------------- text cleanup
_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[@-Z\\-_]")
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_output(text: str) -> str:
    """Remove colour codes and control characters; keep the final state of progress lines."""
    text = _ANSI_RE.sub("", text.replace("\r\n", "\n"))
    if "\r" in text:
        lines = []
        for line in text.split("\n"):
            parts = [p for p in line.split("\r") if p]
            lines.append(parts[-1] if parts else "")
        text = "\n".join(lines)
    return _CTRL_RE.sub("", text)


# --------------------------------------------------------------------------- environment
_STRIP_PREFIXES = ("OMNIROUTE_", "AIDE_")
_STRIP_NAMES = {"BASH_ENV", "ENV", "PROMPT_COMMAND"}


def child_env(base: Mapping[str, str] | None = None) -> dict[str, str]:
    env = {k: v for k, v in (os.environ if base is None else base).items()
           if not k.startswith(_STRIP_PREFIXES) and k not in _STRIP_NAMES}
    env.update({
        "TERM": "dumb", "NO_COLOR": "1", "PAGER": "cat", "GIT_PAGER": "cat",
        "GIT_TERMINAL_PROMPT": "0", "PYTHONUNBUFFERED": "1", "DEBIAN_FRONTEND": "noninteractive",
    })
    return env


def shell_path() -> str:
    return shutil.which("bash") or "/bin/sh"


# --------------------------------------------------------------------------- bounded capture
class BoundedCapture:
    """Keeps the first `head` and last `tail` bytes of a stream and counts the rest."""

    def __init__(self, head: int, tail: int) -> None:
        self._head_limit, self._tail_limit = head, tail
        self._head = bytearray()
        self._tail = bytearray()
        self.total = 0
        self._lock = threading.Lock()

    def feed(self, data: bytes) -> None:
        with self._lock:
            self.total += len(data)
            room = self._head_limit - len(self._head)
            if room > 0:
                self._head += data[:room]
                data = data[room:]
            if data and self._tail_limit > 0:
                self._tail += data
                excess = len(self._tail) - self._tail_limit
                if excess > 0:
                    del self._tail[:excess]

    def _snapshot(self) -> tuple[bytes, bytes, int]:
        with self._lock:
            head, tail, total = bytes(self._head), bytes(self._tail), self.total
        return head, tail, total

    def text(self) -> str:
        head, tail, total = self._snapshot()
        omitted = total - len(head) - len(tail)
        dec = lambda b: b.decode("utf-8", errors="replace")  # noqa: E731
        if omitted <= 0:
            return clean_output(dec(head + tail))
        return clean_output(dec(head)) + f"\n[... {omitted} bytes omitted ...]\n" + clean_output(dec(tail))

    def read_from(self, offset: int) -> tuple[str, int, int]:
        """New output since absolute byte `offset`: (text, new_offset, bytes_lost_before_it)."""
        head, tail, total = self._snapshot()
        tail_start = total - len(tail)
        lost = 0
        if offset >= tail_start:
            data = tail[offset - tail_start:]
        else:
            parts = []
            gap_from = offset
            if offset < len(head):
                parts.append(head[offset:])
                gap_from = len(head)
            lost = max(tail_start - gap_from, 0)
            parts.append(tail)
            data = b"".join(parts)
        return clean_output(data.decode("utf-8", errors="replace")), total, lost


def _pump(stream, capture: BoundedCapture) -> None:
    try:
        fd = stream.fileno()
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            capture.feed(chunk)
    except (OSError, ValueError):
        pass
    finally:
        try:
            stream.close()
        except OSError:
            pass


# --------------------------------------------------------------------------- process groups
def group_alive(pgid: int) -> bool:
    """Is any non-zombie process still in this process group? (A zombie is already dead; it
    only waits for its parent to collect it, which can take a while in containers.)"""
    try:
        entries = os.listdir("/proc")
    except OSError:                                   # no /proc: fall back to signal 0
        try:
            os.killpg(pgid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
    for name in entries:
        if not name.isdigit():
            continue
        try:
            with open(f"/proc/{name}/stat") as fh:
                data = fh.read()
        except OSError:
            continue
        rest = data.rpartition(")")[2].split()        # state, ppid, pgrp, ...
        if len(rest) >= 3 and rest[0] != "Z" and rest[2] == str(pgid):
            return True
    return False


def kill_group(pgid: int, *, proc: subprocess.Popen | None = None, grace: float = 2.0) -> None:
    """SIGTERM the whole group, wait up to `grace` seconds, then SIGKILL what is left."""
    try:
        os.killpg(pgid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass
    deadline = time.monotonic() + grace
    while time.monotonic() < deadline:
        if proc is not None:
            proc.poll()  # reap the direct child so it stops counting as alive
        if not group_alive(pgid):
            break
        time.sleep(0.02)
    if group_alive(pgid):
        try:
            os.killpg(pgid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    if proc is not None:
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass


# --------------------------------------------------------------------------- foreground run
@dataclass
class RunResult:
    exit_code: int | None       # None if killed by timeout/cancel before exiting on its own
    timed_out: bool
    cancelled: bool
    leftover_killed: bool       # background children were still running and got killed
    duration: float
    stdout: str
    stderr: str


def run_shell(command: str, *, cwd: Path, timeout: float, cancel: threading.Event | None,
              head: int, tail: int, env: Mapping[str, str] | None = None) -> RunResult:
    proc = subprocess.Popen(
        [shell_path(), "-c", command], cwd=cwd, env=dict(env) if env else child_env(),
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True,
    )
    pgid = proc.pid
    out, err = BoundedCapture(head, tail), BoundedCapture(head, tail)
    readers = [threading.Thread(target=_pump, args=(proc.stdout, out), daemon=True),
               threading.Thread(target=_pump, args=(proc.stderr, err), daemon=True)]
    for t in readers:
        t.start()

    started = time.monotonic()
    timed_out = cancelled = False
    while True:
        try:
            proc.wait(timeout=0.02)
            break
        except subprocess.TimeoutExpired:
            pass
        if cancel is not None and cancel.is_set():
            cancelled = True
        elif time.monotonic() - started > timeout:
            timed_out = True
        if cancelled or timed_out:
            kill_group(pgid, proc=proc)
            break
    duration = time.monotonic() - started

    for t in readers:
        t.join(timeout=0.5)
    leftover = False
    if not (timed_out or cancelled) and group_alive(pgid):
        leftover = True                      # a background child outlived the shell
        kill_group(pgid, proc=proc, grace=1.0)
    for t in readers:
        t.join(timeout=1.0)
    return RunResult(None if (timed_out or cancelled) else proc.returncode,
                     timed_out, cancelled, leftover, duration, out.text(), err.text())


# --------------------------------------------------------------------------- background jobs
class BackgroundProcess:
    def __init__(self, ident: str, name: str, command: str, proc: subprocess.Popen,
                 capture: BoundedCapture) -> None:
        self.ident, self.name, self.command = ident, name, command
        self.proc, self.capture = proc, capture
        self.started = time.monotonic()
        self.cursor = 0                      # bytes of output already shown to the model

    @property
    def pid(self) -> int:
        return self.proc.pid

    def exit_code(self) -> int | None:
        return self.proc.poll()

    def status(self) -> str:
        code = self.exit_code()
        if code is None:
            return "running"
        return f"exited with code {code}" if code >= 0 else f"killed by signal {-code}"

    def uptime(self) -> float:
        return time.monotonic() - self.started


class BackgroundManager:
    def __init__(self, *, max_procs: int = 5, buffer_bytes: int = 262_144) -> None:
        self.max_procs, self.buffer_bytes = max_procs, buffer_bytes
        self._procs: dict[str, BackgroundProcess] = {}
        self._counter = 0
        atexit.register(self.shutdown)

    def list(self) -> list[BackgroundProcess]:
        return list(self._procs.values())

    def get(self, ident: str) -> BackgroundProcess | None:
        return self._procs.get(ident)

    def start(self, command: str, *, cwd: Path, name: str = "",
              startup_wait: float = 1.5, cancel: threading.Event | None = None) -> BackgroundProcess:
        running = [p for p in self._procs.values() if p.exit_code() is None]
        if len(running) >= self.max_procs:
            raise RuntimeError(f"Too many background processes running ({len(running)}). "
                               f"Stop one first: {', '.join(p.ident for p in running)}.")
        proc = subprocess.Popen(
            [shell_path(), "-c", command], cwd=cwd, env=child_env(),
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        self._counter += 1
        capture = BoundedCapture(0, self.buffer_bytes)
        threading.Thread(target=_pump, args=(proc.stdout, capture), daemon=True).start()
        bg = BackgroundProcess(f"bg{self._counter}", name or command[:40], command, proc, capture)
        self._procs[bg.ident] = bg
        deadline = time.monotonic() + startup_wait
        while time.monotonic() < deadline and bg.exit_code() is None:
            if cancel is not None and cancel.is_set():
                break
            time.sleep(0.02)
        return bg

    def stop(self, bg: BackgroundProcess, grace: float = 3.0) -> None:
        kill_group(bg.pid, proc=bg.proc, grace=grace)

    def shutdown(self) -> None:
        for bg in self._procs.values():
            if bg.exit_code() is None or group_alive(bg.pid):
                kill_group(bg.pid, proc=bg.proc, grace=1.0)
