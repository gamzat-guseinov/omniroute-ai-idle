"""Manual harness: run a tool without a model, through the same permission checks as the agent.

    python -m aide.tools list
    python -m aide.tools call read_file '{"path": "app.py"}' -w /path/to/workspace
    python -m aide.tools call run_command '{"command": "ls -la"}' --mode ask
    python -m aide.tools call edit_file '{...}' --preview     # show the diff, change nothing
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .registry import create_registry


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m aide.tools", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-w", "--workspace", default=".", help="workspace directory (default: .)")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list", help="list tools and their arguments")
    c = sub.add_parser("call", help="call one tool")
    c.add_argument("tool")
    c.add_argument("args", nargs="?", default="{}", help="JSON object with the arguments")
    c.add_argument("--mode", default="ask", choices=["ask", "auto-edit", "auto"],
                   help="permission mode (default: ask)")
    c.add_argument("--preview", action="store_true", help="show the diff instead of applying")
    ns = p.parse_args(argv)

    registry = create_registry(ns.workspace)
    try:
        if ns.cmd == "list":
            for tool in registry.schemas():
                fn = tool["function"]
                kind = registry.get(fn["name"]).kind
                print(f"{fn['name']}({', '.join(fn['parameters'].get('properties', {}))})  [{kind}]")
            return 0
        try:
            args = json.loads(ns.args)
        except ValueError as exc:
            print(f"Arguments are not valid JSON: {exc}", file=sys.stderr)
            return 2
        if ns.preview:
            from .errors import ToolError
            try:
                text = registry.preview(ns.tool, args)
            except ToolError as exc:
                print(f"ERROR: {exc}")
                return 1
            print(text if text is not None else "(this tool has no preview)")
            return 0
        from ..agent.executor import ToolExecutor
        from ..agent.permissions import PermissionPolicy
        from ..agent.terminal import terminal_approver
        executor = ToolExecutor(registry, PermissionPolicy(ns.mode, registry.ctx.sandbox),
                                terminal_approver)
        result = asyncio.run(executor.run(ns.tool, args))
        print(result.output if result.ok else f"ERROR: {result.output}")
        return 0 if result.ok else 1
    finally:
        registry.ctx.close()


if __name__ == "__main__":
    sys.exit(main())
