"""Safety checks for shell commands."""
