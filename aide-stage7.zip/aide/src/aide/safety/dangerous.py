"""Best-effort analysis of shell commands before they run.

This is a SAFETY NET, not a security boundary. It reads the command the way a shell would
(quotes, pipes, `;`/`&&`, $(...), `bash -c '...'`, wrappers such as env/xargs/timeout) and flags:

* dangerous operations (recursive deletes, sudo, curl|sh, disk/network/system tools, ...), and
* references to paths outside the workspace.

Both make aide ask the user, in every permission mode. Anything a shell can hide from a static
reading (aliases, downloaded scripts, `python -c "shutil.rmtree(...)"`) is NOT caught; real
confinement needs an OS-level sandbox (container, bubblewrap, ...).
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

MAX_DEPTH = 6

FETCHERS = {"curl", "wget", "fetch", "aria2c", "xh", "http", "https"}
SHELLS = {"sh", "bash", "zsh", "dash", "ksh", "fish", "ash"}
INTERPRETERS = SHELLS | {"csh", "tcsh", "python", "python2", "perl", "ruby", "node", "nodejs",
                         "php", "lua", "tclsh", "pwsh", "sudo", "su", "doas", "source", ".", "eval"}
PRIVILEGE = {"sudo", "su", "doas", "pkexec", "runuser", "run0"}
DISK_TOOLS = {"mkfs", "fdisk", "sfdisk", "cfdisk", "parted", "gdisk", "wipefs", "mkswap", "swapon",
              "swapoff", "mount", "umount", "losetup", "cryptsetup", "lvremove", "vgremove",
              "pvremove", "blkdiscard", "hdparm"}
NETWORK_TOOLS = {"nmap", "masscan", "zmap", "arp-scan", "iptables", "ip6tables", "nft", "ufw",
                 "firewall-cmd", "ifconfig", "route", "ifup", "ifdown", "nmcli", "tc", "brctl",
                 "tcpdump", "tshark", "ettercap", "hping3", "ssh", "scp", "sftp", "sshfs", "ftp",
                 "telnet", "nc", "ncat", "netcat", "socat"}
SYSTEM_TOOLS = {"systemctl", "service", "shutdown", "reboot", "halt", "poweroff", "init", "telinit",
                "crontab", "launchctl", "loginctl", "hostnamectl", "timedatectl", "modprobe",
                "insmod", "rmmod", "useradd", "userdel", "usermod", "groupadd", "groupdel",
                "passwd", "chsh", "visudo", "update-alternatives"}
PACKAGE_MANAGERS = {"apt", "apt-get", "aptitude", "dpkg", "dnf", "yum", "rpm", "pacman", "zypper",
                    "apk", "snap", "flatpak", "brew"}
DEVICE_PREFIXES = ("/dev/sd", "/dev/hd", "/dev/vd", "/dev/nvme", "/dev/mmcblk", "/dev/disk",
                   "/dev/mem", "/dev/kmem", "/dev/loop")

# wrapper -> (options that consume the next argument, number of positional arguments to skip)
WRAPPERS: dict[str, tuple[set[str], int]] = {
    "env": ({"-u", "-C", "-S"}, 0), "nice": ({"-n"}, 0), "nohup": (set(), 0), "time": (set(), 0),
    "command": (set(), 0), "builtin": (set(), 0), "exec": (set(), 0), "setsid": (set(), 0),
    "xargs": ({"-I", "-n", "-P", "-L", "-s", "-d", "-E", "-a"}, 0),
    "watch": ({"-n"}, 0), "stdbuf": ({"-i", "-o", "-e"}, 0), "ionice": ({"-c", "-n", "-p"}, 0),
    "timeout": ({"-s", "-k"}, 1), "taskset": ({"-c"}, 1),
}

_ASSIGN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*=")
_FORK_BOMB_RE = re.compile(r":\s*\(\s*\)\s*\{")
_REDIR_RE = re.compile(r"^[0-9&]*(?:>>|>&|>\||<&|<<<|<<|>|<)+")


# --------------------------------------------------------------------------- lexer
@dataclass
class Segment:
    tokens: list[str]
    sep: str                                  # operator joining it to the previous segment
    nested: list[str] = field(default_factory=list)  # bodies of $(...), `...`, <(...), >(...)


def _match_close(cmd: str, i: int) -> int:
    """Index of the ')' matching a '(' that was just consumed (i = first char after it)."""
    depth, n = 1, len(cmd)
    while i < n:
        c = cmd[i]
        if c == "\\":
            i += 2
            continue
        if c == "'":
            j = cmd.find("'", i + 1)
            i = (n if j == -1 else j) + 1
            continue
        if c == '"':
            i += 1
            while i < n and cmd[i] != '"':
                i += 2 if cmd[i] == "\\" else 1
            i += 1
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return n


def lex(cmd: str) -> list[Segment]:
    """Split a command line into simple commands with quotes resolved (like a shell would)."""
    segments: list[Segment] = []
    state = {"tokens": [], "nested": [], "sep": ""}
    cur: list[str] = []
    in_tok = False
    i, n = 0, len(cmd)

    def end_token() -> None:
        nonlocal in_tok
        if in_tok:
            state["tokens"].append("".join(cur))
            cur.clear()
            in_tok = False

    def end_segment(next_sep: str) -> None:
        end_token()
        if state["tokens"] or state["nested"]:
            segments.append(Segment(state["tokens"], state["sep"], state["nested"]))
        state["tokens"], state["nested"], state["sep"] = [], [], next_sep

    def grab_subshell(start: int) -> int:
        end = _match_close(cmd, start)
        state["nested"].append(cmd[start:end])
        return end + 1

    while i < n:
        c = cmd[i]
        nxt = cmd[i + 1] if i + 1 < n else ""
        if c == "\\":
            if nxt == "\n":
                i += 2
                continue
            if nxt:
                cur.append(nxt)
                in_tok = True
            i += 2
            continue
        if c == "'":
            j = cmd.find("'", i + 1)
            j = n if j == -1 else j
            cur.append(cmd[i + 1:j])
            in_tok = True
            i = j + 1
            continue
        if c == '"':
            i += 1
            in_tok = True
            while i < n and cmd[i] != '"':
                d = cmd[i]
                if d == "\\" and i + 1 < n:
                    cur.append(cmd[i + 1])
                    i += 2
                elif d == "$" and cmd[i + 1:i + 2] == "(":
                    i = grab_subshell(i + 2)
                elif d == "`":
                    end = cmd.find("`", i + 1)
                    end = n if end == -1 else end
                    state["nested"].append(cmd[i + 1:end])
                    i = end + 1
                else:
                    cur.append(d)
                    i += 1
            i += 1
            continue
        if (c == "$" and nxt == "(") or (c in "<>" and nxt == "("):
            in_tok = True
            i = grab_subshell(i + 2)
            continue
        if c == "`":
            end = cmd.find("`", i + 1)
            end = n if end == -1 else end
            state["nested"].append(cmd[i + 1:end])
            in_tok = True
            i = end + 1
            continue
        if c == "#" and not in_tok:
            j = cmd.find("\n", i)
            i = n if j == -1 else j
            continue
        if c in " \t":
            end_token()
            i += 1
        elif c == "\n":
            end_segment("\n")
            i += 1
        elif c == ";":
            end_segment(";")
            i += 2 if nxt == ";" else 1
        elif c == "|":
            if nxt == "|":
                end_segment("||")
                i += 2
            elif nxt == "&":
                end_segment("|")
                i += 2
            else:
                end_segment("|")
                i += 1
        elif c == "&":
            prev = cmd[i - 1] if i else ""
            if nxt == "&":
                end_segment("&&")
                i += 2
            elif (prev and prev in "<>") or nxt == ">":   # 2>&1, &>file
                cur.append(c)
                in_tok = True
                i += 1
            else:
                end_segment("&")
                i += 1
        elif c in "()":
            end_segment("")
            i += 1
        elif c in "{}" and not in_tok and nxt in ("", " ", "\t", "\n", ";"):
            end_segment("")
            i += 1
        else:
            cur.append(c)
            in_tok = True
            i += 1
    end_segment("")
    return segments


# --------------------------------------------------------------------------- helpers
def norm_prog(token: str) -> str:
    base = os.path.basename(token)
    if re.fullmatch(r"python[\d.]*", base):
        return "python"
    if re.fullmatch(r"pip[\d.]*", base):
        return "pip"
    return base


def strip_wrappers(tokens: list[str]) -> list[str]:
    """Drop leading VAR=x assignments and wrappers (env, xargs, timeout, ...) to reach the
    program that really runs."""
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if _ASSIGN_RE.match(t):
            i += 1
            continue
        name = os.path.basename(t)
        if name not in WRAPPERS:
            break
        takes_arg, positionals = WRAPPERS[name]
        i += 1
        while i < len(tokens) and tokens[i].startswith("-") and tokens[i] != "-":
            opt = tokens[i]
            i += 1
            if opt in takes_arg and i < len(tokens):
                i += 1
        for _ in range(positionals):
            if i < len(tokens) and not tokens[i].startswith("-"):
                i += 1
    return tokens[i:]


def _opts(args: list[str]) -> tuple[set[str], set[str]]:
    short: set[str] = set()
    long: set[str] = set()
    for a in args:
        if a == "--":
            break
        if a.startswith("--"):
            long.add(a.split("=", 1)[0])
        elif a.startswith("-") and len(a) > 1:
            short.update(a[1:])
    return short, long


def _git_subcommand(args: list[str]) -> tuple[str, list[str]]:
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-C", "-c", "--git-dir", "--work-tree", "--namespace"):
            i += 2
        elif a.startswith("-"):
            i += 1
        else:
            return a, args[i + 1:]
    return "", []


# --------------------------------------------------------------------------- analysis
class _Analyzer:
    def __init__(self) -> None:
        self.reasons: list[str] = []
        self.programs: list[str] = []
        self.tokens: list[str] = []

    def flag(self, reason: str) -> None:
        if reason not in self.reasons:
            self.reasons.append(reason)

    def analyze(self, command: str, depth: int = 0) -> None:
        if depth > MAX_DEPTH:
            self.flag("deeply nested shell commands")
            return
        if _FORK_BOMB_RE.search(command):
            self.flag("looks like a fork bomb")
        segments = lex(command)
        for seg in segments:
            self.tokens.extend(seg.tokens)
            words = strip_wrappers(seg.tokens)
            if words:
                self._check(words, seg, depth)
            for body in seg.nested:
                self.analyze(body, depth + 1)
        for prev, cur in zip(segments, segments[1:]):
            if cur.sep == "|":
                pw, cw = strip_wrappers(prev.tokens), strip_wrappers(cur.tokens)
                if pw and cw and norm_prog(pw[0]) in FETCHERS and norm_prog(cw[0]) in INTERPRETERS:
                    self.flag("pipes a download into an interpreter (curl | sh)")

    def _check(self, words: list[str], seg: Segment, depth: int) -> None:
        prog, args = norm_prog(words[0]), words[1:]
        self.programs.append(prog)
        short, long = _opts(args)

        if prog in INTERPRETERS and seg.nested:
            for body in seg.nested:
                sub = _Analyzer()
                sub.analyze(body, depth + 1)
                if FETCHERS & set(sub.programs):
                    self.flag("runs downloaded code (curl/wget inside a shell substitution)")
        if prog in SHELLS:
            for k, a in enumerate(args):
                if a.startswith("-") and not a.startswith("--") and "c" in a and k + 1 < len(args):
                    self.analyze(args[k + 1], depth + 1)
                    break
        if prog == "eval":
            self.analyze(" ".join(args), depth + 1)

        if prog in PRIVILEGE:
            self.flag(f"runs with elevated privileges ({prog})")
        elif prog == "rm":
            if short & {"r", "R"} or "--recursive" in long:
                self.flag("recursively deletes files (rm -r)")
            if "--no-preserve-root" in long:
                self.flag("rm --no-preserve-root")
        elif prog == "shred":
            self.flag("destroys file contents (shred)")
        elif prog == "find":
            if "-delete" in args:
                self.flag("find -delete removes files")
            for k, a in enumerate(args):
                if a in ("-exec", "-execdir", "-ok", "-okdir"):
                    sub_tokens = []
                    for b in args[k + 1:]:
                        if b in (";", "+"):
                            break
                        sub_tokens.append(b)
                    if sub_tokens:
                        self._check(strip_wrappers(sub_tokens) or sub_tokens, Segment(sub_tokens, ""), depth)
        elif prog in ("chmod", "chown", "chgrp", "setfacl", "chattr"):
            if "R" in short or "--recursive" in long:
                self.flag(f"changes permissions/ownership recursively ({prog} -R)")
        elif prog == "dd":
            if any(a.startswith(("of=/dev/", "if=/dev/")) for a in args):
                self.flag("dd on a device file")
        elif prog.startswith("mkfs") or prog in DISK_TOOLS:
            self.flag(f"disk or filesystem operation ({prog})")
        elif prog == "ip":
            if set(args) & {"add", "del", "delete", "set", "flush", "change", "replace"}:
                self.flag("changes network configuration (ip)")
        elif prog == "rsync":
            if any(re.match(r"^[\w.-]+@[\w.-]+:|^[\w.-]+:[^/=]", a) for a in args):
                self.flag("copies files to/from a remote host (rsync)")
        elif prog in NETWORK_TOOLS:
            self.flag(f"network tool that reaches other machines ({prog})")
        elif prog in SYSTEM_TOOLS:
            self.flag(f"system-wide change ({prog})")
        elif prog in PACKAGE_MANAGERS:
            self.flag(f"system package manager ({prog})")
        elif prog in ("killall", "pkill"):
            self.flag(f"kills processes by name ({prog})")
        elif prog == "kill":
            if "-1" in args and len(args) >= 2:
                self.flag("kill -1 signals every process you may signal")
        elif prog == "git":
            self._check_git(args)
        elif prog in ("npm", "yarn", "pnpm"):
            if {"-g", "--global"} & set(args):
                self.flag(f"global package install ({prog} -g)")
            if "publish" in args:
                self.flag(f"publishes a package ({prog} publish)")
        elif prog in ("twine", "cargo", "gem") and ({"upload", "publish", "push"} & set(args)):
            self.flag(f"publishes a package ({prog})")
        elif prog == "pip" and "--break-system-packages" in args:
            self.flag("pip --break-system-packages modifies the system Python")
        elif prog in ("docker", "podman"):
            if "--privileged" in args or ("system" in args and "prune" in args):
                self.flag(f"privileged or destructive {prog} operation")

        for tok in args:
            t = _REDIR_RE.sub("", tok, count=1)
            if t.startswith(DEVICE_PREFIXES):
                self.flag("reads/writes a raw disk device")

    def _check_git(self, args: list[str]) -> None:
        sub, rest = _git_subcommand(args)
        short, long = _opts(rest)
        if sub == "push":
            self.flag("git push sends commits to a remote")
        elif sub == "reset" and "--hard" in long:
            self.flag("git reset --hard discards uncommitted changes")
        elif sub == "clean" and ("f" in short or "--force" in long):
            self.flag("git clean deletes untracked files")
        elif sub == "branch" and "D" in short:
            self.flag("git branch -D deletes a branch")
        elif sub in ("filter-branch", "filter-repo"):
            self.flag(f"git {sub} rewrites history")
        elif sub == "config" and ({"--global", "--system"} & long):
            self.flag("changes global git configuration")
        elif sub == "stash" and rest and rest[0] in ("drop", "clear"):
            self.flag("git stash drop/clear discards saved work")


# --------------------------------------------------------------------------- outside paths
_BENIGN_EXACT = {"/dev/null", "/dev/zero", "/dev/urandom", "/dev/random", "/dev/stdin",
                 "/dev/stdout", "/dev/stderr", "/dev/tty", "/usr", "/bin", "/sbin", "/lib", "/opt"}
_BENIGN_PREFIXES = ("/usr/", "/bin/", "/sbin/", "/lib/", "/lib32/", "/lib64/", "/opt/")


def _benign(path: str) -> bool:
    return path in _BENIGN_EXACT or path.startswith(_BENIGN_PREFIXES)


def outside_paths(tokens: list[str], workspace: Path, cwd: Path) -> list[str]:
    """Tokens that look like paths pointing outside the workspace (home, /etc, ../x, ...)."""
    root = Path(os.path.realpath(workspace))
    base = os.path.realpath(cwd)
    found: list[str] = []
    for tok in tokens:
        t = _REDIR_RE.sub("", tok, count=1)
        m = re.match(r"^(?:--[\w-]+|[A-Za-z_]\w*)=(.*)$", t)
        if m:
            t = m.group(1)
        if not t or t.startswith("-"):
            continue
        if "$" in t:
            if not re.match(r"^\$\{?HOME\}?(/|$)", t):
                continue
            t = "~" + re.sub(r"^\$\{?HOME\}?", "", t)
        if t.startswith("~"):
            p = os.path.expanduser(t)
        elif t.startswith("/"):
            first = t.split("/")[1] if len(t) > 1 else ""
            if first and not os.path.isdir("/" + first):
                continue                      # "/api/v1" is not a real location on this machine
            p = t
        elif ".." in t.split("/"):
            p = os.path.join(base, t)
        else:
            continue
        real = os.path.realpath(p)
        if Path(real).is_relative_to(root) or _benign(p) or _benign(real):
            continue
        found.append(tok)
    return found


# --------------------------------------------------------------------------- public API
@dataclass
class Assessment:
    reasons: list[str]          # why the command is dangerous
    outside: list[str]          # paths it seems to touch outside the workspace
    programs: list[str]         # programs it runs (used for the session allow-list)

    @property
    def dangerous(self) -> bool:
        return bool(self.reasons)

    @property
    def needs_confirmation(self) -> bool:
        return bool(self.reasons or self.outside)


def assess_command(command: str, workspace: Path, cwd: Path | None = None) -> Assessment:
    an = _Analyzer()
    an.analyze(command)
    outside = outside_paths(an.tokens, workspace, cwd or workspace)
    return Assessment(an.reasons, outside, an.programs)
