"""Audit trail: one JSON line per tool call (what ran, who approved it, how it ended).

It is always on (unless disabled in the config), private (mode 600), small (rotated at 1 MB), and
contains no file contents: long argument values are replaced by their length. Commands are kept,
because they are exactly what a reviewer wants to see.
"""
from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

KEEP_CHARS = 300


def summarize_args(args: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in args.items():
        if isinstance(v, str) and len(v) > KEEP_CHARS:
            out[k] = f"<{len(v)} chars>"
        else:
            out[k] = v
    return out


class AuditLog:
    def __init__(self, path: Path | None, *, session: str = "", max_bytes: int = 1_000_000,
                 redact: Callable[[str], str] | None = None) -> None:
        self.path, self.session, self.max_bytes = path, session, max_bytes
        self._redact = redact or (lambda s: s)
        self._lock = threading.Lock()

    @property
    def enabled(self) -> bool:
        return self.path is not None

    def log(self, event: str, **fields: Any) -> None:
        if self.path is None:
            return
        entry = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                 "session": self.session, "event": event, **fields}
        line = self._redact(json.dumps(entry, ensure_ascii=False, default=str))
        with self._lock:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                    os.replace(self.path, self.path.with_name(self.path.name + ".1"))
                fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
                with os.fdopen(fd, "a", encoding="utf-8") as fh:
                    os.fchmod(fh.fileno(), 0o600)
                    fh.write(line + "\n")
            except OSError:
                pass                                  # auditing must never break the agent

    def tool(self, name: str, args: dict[str, Any], *, decision: str, ok: bool,
             duration: float, exit_code: int | None = None, detail: str = "") -> None:
        self.log("tool", tool=name, args=summarize_args(args), decision=decision, ok=ok,
                 duration=round(duration, 3), exit_code=exit_code, detail=detail[:200])

    def tail(self, n: int = 10) -> list[dict[str, Any]]:
        if self.path is None:
            return []
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()[-n:]
        except OSError:
            return []
        out = []
        for line in lines:
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
        return out
