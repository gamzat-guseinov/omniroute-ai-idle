"""Workspace snapshots in a private git repository that lives OUTSIDE the workspace.

`snapshot()` records every file of the workspace (respecting its .gitignore, and skipping
node_modules, virtualenvs, caches and very large files) as a git tree and returns the tree id.
Two trees can be compared (`changes`, `patch`), and a tree can be restored (`restore`). This
captures effects of ANY tool, including shell commands, without touching the user's own
repository (a separate git dir is used, so the workspace's .git is never modified).

Files ignored by .gitignore (build output, .env, ...) are not tracked, and therefore not undone.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path, PurePosixPath

from ..tools.gitignore import ALWAYS_HIDDEN, NOISE_NAMES

MAX_FILES = 50_000
MAX_TOTAL_BYTES = 1_000_000_000
MAX_FILE_BYTES = 10_000_000
GIT_TIMEOUT = 120


class ShadowError(Exception):
    """Snapshots are not possible (no git, workspace too large, git failed)."""


def git_available() -> bool:
    return shutil.which("git") is not None


class ShadowRepo:
    def __init__(self, workspace: Path, root: Path) -> None:
        self.workspace = Path(os.path.realpath(workspace))
        self.root = root                      # the shadow repo lives in root/.git
        self.git_dir = root / ".git"
        self._skipped_large: list[str] = []

    # ------------------------------------------------------------------ git plumbing
    def _env(self, index: Path | None = None) -> dict[str, str]:
        env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
        env.update({
            "GIT_DIR": str(self.git_dir), "GIT_WORK_TREE": str(self.workspace),
            "GIT_INDEX_FILE": str(index or self.git_dir / "aide-index"),
            "GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C",
            "HOME": str(self.root),           # keeps the user's global git config out of it
        })
        return env

    _CONFIG = ["-c", "core.excludesFile=", "-c", "core.autocrlf=false", "-c", "core.safecrlf=false",
               "-c", "core.quotepath=false", "-c", "gc.auto=0", "-c", "core.hooksPath=/dev/null",
               "-c", "core.fsmonitor=false"]

    def _git(self, *args: str, input: bytes | None = None, index: Path | None = None,
             check: bool = True) -> subprocess.CompletedProcess:
        try:
            proc = subprocess.run(["git", *self._CONFIG, *args], cwd=self.workspace,
                                  env=self._env(index), input=input, capture_output=True,
                                  timeout=GIT_TIMEOUT)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ShadowError(f"git could not run: {exc}") from exc
        if check and proc.returncode != 0:
            raise ShadowError(f"git {args[0]} failed: {proc.stderr.decode('utf-8', 'replace').strip()[:300]}")
        return proc

    def _ensure_init(self) -> None:
        if (self.git_dir / "HEAD").exists():
            return
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            subprocess.run(["git", "init", "-q"], cwd=self.root, capture_output=True, check=True,
                           timeout=GIT_TIMEOUT, env={k: v for k, v in os.environ.items() if not k.startswith("GIT_")})
        except (OSError, subprocess.SubprocessError) as exc:
            raise ShadowError(f"could not create the snapshot repository: {exc}") from exc

    # ------------------------------------------------------------------ size guard + excludes
    def _scan(self) -> None:
        """Refuse huge workspaces; remember very large files so they can be excluded."""
        files = total = 0
        large: list[str] = []
        skip = ALWAYS_HIDDEN | NOISE_NAMES
        for dirpath, dirnames, filenames in os.walk(self.workspace):
            dirnames[:] = [d for d in dirnames if d not in skip]
            for name in filenames:
                if name in skip:
                    continue
                files += 1
                try:
                    size = os.lstat(os.path.join(dirpath, name)).st_size
                except OSError:
                    continue
                total += size
                if size > MAX_FILE_BYTES:
                    rel = os.path.relpath(os.path.join(dirpath, name), self.workspace)
                    large.append(rel.replace(os.sep, "/"))
                if files > MAX_FILES or total > MAX_TOTAL_BYTES:
                    raise ShadowError(f"the workspace is too large to snapshot "
                                      f"(over {MAX_FILES} files or {MAX_TOTAL_BYTES // 10**6} MB)")
        self._skipped_large = large

    def _write_excludes(self) -> None:
        lines = ["# managed by aide", *sorted(NOISE_NAMES)] + [f"/{p}" for p in self._skipped_large]
        info = self.git_dir / "info"
        info.mkdir(exist_ok=True)
        (info / "exclude").write_text("\n".join(lines) + "\n", encoding="utf-8")

    @property
    def skipped_large(self) -> list[str]:
        return list(self._skipped_large)

    # ------------------------------------------------------------------ snapshots
    def snapshot(self) -> str:
        """Record the current workspace; returns the tree id."""
        self._ensure_init()
        self._scan()
        self._write_excludes()
        self._git("add", "-A", "--ignore-errors", check=False)     # unreadable files must not block
        return self._git("write-tree").stdout.decode().strip()

    def changes(self, before: str, after: str) -> list[tuple[str, str]]:
        """(status, path) pairs: A added, M modified, D deleted, T type changed."""
        out = self._git("diff-tree", "-r", "-z", "--name-status", "--no-renames", before, after).stdout
        parts = out.decode("utf-8", "surrogateescape").split("\0")
        return [(parts[i], parts[i + 1]) for i in range(0, len(parts) - 1, 2) if parts[i]]

    def patch(self, before: str, after: str) -> str:
        out = self._git("diff-tree", "-p", "-r", "--no-renames", "--no-color", before, after).stdout
        text = out.decode("utf-8", "replace")
        # diff-tree prints the tree ids first; keep only the diff itself
        return "\n".join(ln for ln in text.splitlines() if not (len(ln) == 40 and ln.isalnum()))

    # ------------------------------------------------------------------ restore
    def _safe(self, rel: str) -> Path | None:
        p = PurePosixPath(rel)
        if p.is_absolute() or ".." in p.parts or not p.parts or ".git" in p.parts:
            return None
        target = self.workspace.joinpath(*p.parts)
        parent = Path(os.path.realpath(target.parent))
        if not parent.is_relative_to(self.workspace):
            return None
        return parent / target.name

    def restore(self, before: str, changes: list[tuple[str, str]]) -> tuple[list[str], list[str], list[str]]:
        """Put the workspace back to `before`. Returns (restored, removed, skipped) paths."""
        restored: list[str] = []
        removed: list[str] = []
        skipped: list[str] = []
        to_checkout: list[str] = []
        for status, rel in changes:
            target = self._safe(rel)
            if target is None:
                skipped.append(rel)
            elif status == "A":                      # did not exist before: delete it
                try:
                    if target.is_dir() and not target.is_symlink():
                        shutil.rmtree(target)
                    elif os.path.lexists(target):
                        target.unlink()
                    removed.append(rel)
                    self._prune_empty_parents(target.parent)
                except OSError:
                    skipped.append(rel)
            else:                                    # M, D, T: bring the old version back
                to_checkout.append(rel)
        if to_checkout:
            index = self.git_dir / "aide-restore-index"
            try:
                self._git("read-tree", before, index=index)
                for rel in to_checkout:
                    target = self._safe(rel)
                    if target is not None and target.is_dir() and not target.is_symlink():
                        shutil.rmtree(target, ignore_errors=True)    # a directory is in the way
                proc = self._git("checkout-index", "-f", "-z", "--stdin",
                                 input=("\0".join(to_checkout) + "\0").encode("utf-8", "surrogateescape"),
                                 index=index, check=False)
                if proc.returncode == 0:
                    restored += to_checkout
                else:                                 # find out which ones worked
                    for rel in to_checkout:
                        one = self._git("checkout-index", "-f", "-z", "--stdin", index=index, check=False,
                                        input=(rel + "\0").encode("utf-8", "surrogateescape"))
                        (restored if one.returncode == 0 else skipped).append(rel)
            finally:
                try:
                    index.unlink()
                except OSError:
                    pass
        return restored, removed, skipped

    def _prune_empty_parents(self, directory: Path) -> None:
        while directory != self.workspace and directory.is_relative_to(self.workspace):
            try:
                directory.rmdir()
            except OSError:
                return
            directory = directory.parent
