"""Undo: snapshots of files taken just before the agent changes them.

One checkpoint per user message ("turn"). Every file, symlink or directory that a tool is about to
create, change, move or delete is recorded once per turn, in its ORIGINAL state:

  * existing things are copied into a snapshot directory,
  * things that do not exist yet are recorded as "absent" (undo deletes what was created, and the
    topmost directory that had to be created for it).

`undo_last()` puts everything of the latest checkpoint back; `diff_last()` shows what changed.
Two backends:
  * "git" (default when git is installed): ONE snapshot of the whole workspace per turn in a private
    git repository (see shadow.py). It captures everything, including what shell commands did.
  * "files": per-file copies, recorded by the file tools only. Shell commands are not tracked; only
    their number is kept so the user can be told.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import state_dir
from .shadow import ShadowError, ShadowRepo, git_available

MAX_DIFF_FILE_BYTES = 200_000
MAX_DIFF_LINES = 400


@dataclass
class UndoReport:
    label: str
    restored: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    commands_run: int = 0

    @property
    def nothing_to_do(self) -> bool:
        return not (self.restored or self.removed or self.skipped)


def _inside(root: Path, path: Path) -> bool:
    return Path(os.path.realpath(path.parent)).joinpath(path.name).is_relative_to(root)


class UndoStore:
    def __init__(self, workspace: str | os.PathLike[str], state_root: Path | None = None, *,
                 max_checkpoints: int = 30, max_bytes: int = 100_000_000, backend: str = "auto") -> None:
        self.workspace = Path(os.path.realpath(workspace))
        digest = hashlib.sha1(str(self.workspace).encode()).hexdigest()[:12]
        self.dir = (state_root or state_dir()) / "undo" / digest
        self.max_checkpoints, self.max_bytes = max_checkpoints, max_bytes
        self._checkpoints: list[dict[str, Any]] = self._load()
        self._current: dict[str, Any] | None = None
        self._label = ""
        if backend not in ("auto", "git", "files"):
            raise ValueError(f"unknown undo backend {backend!r}")
        use_git = backend == "git" or (backend == "auto" and git_available())
        if backend == "git" and not git_available():
            raise ShadowError("git is not installed")
        self._shadow: ShadowRepo | None = ShadowRepo(self.workspace, self.dir / "shadow") if use_git else None
        self.last_problem = ""        # why the git backend could not be used (if it could not)

    @property
    def backend(self) -> str:
        return "git" if self._shadow is not None else "files"

    # ------------------------------------------------------------------ persistence
    def _index_path(self) -> Path:
        return self.dir / "index.json"

    def _load(self) -> list[dict[str, Any]]:
        try:
            data = json.loads(self._index_path().read_text(encoding="utf-8"))
            return [c for c in data.get("checkpoints", []) if isinstance(c, dict)]
        except (OSError, ValueError):
            return []

    def _save(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        tmp = self._index_path().with_suffix(".tmp")
        tmp.write_text(json.dumps({"checkpoints": self._checkpoints}), encoding="utf-8")
        os.replace(tmp, self._index_path())

    # ------------------------------------------------------------------ recording
    def begin_turn(self, label: str) -> None:
        """Start a new checkpoint for the next user message (created when first needed)."""
        self._current = None
        self._label = " ".join(label.split())[:80]

    def _ensure_current(self) -> dict[str, Any]:
        if self._current is None:
            next_id = max((c["id"] for c in self._checkpoints), default=0) + 1
            self._current = {"id": next_id, "label": self._label, "bytes": 0, "commands": 0,
                             "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                             "entries": []}
            if self._shadow is not None:
                try:
                    self._current["tree"] = self._shadow.snapshot()
                    self.last_problem = ""
                except ShadowError as exc:
                    self.last_problem = str(exc)      # this turn falls back to per-file copies
            self._checkpoints.append(self._current)
            while len(self._checkpoints) > self.max_checkpoints:
                shutil.rmtree(self.dir / f"c{self._checkpoints.pop(0)['id']}", ignore_errors=True)
            self._save()
        return self._current

    def note_command(self, command: str = "") -> None:
        self._ensure_current()["commands"] += 1
        self._save()

    def record(self, path: str | os.PathLike[str]) -> None:
        """Call just BEFORE a path is created, changed, moved or deleted."""
        path = Path(path)
        try:
            rel = path.relative_to(self.workspace).as_posix()
        except ValueError:
            return                                            # not ours
        ck = self._ensure_current()
        if "tree" in ck or self._covered(ck, rel):       # a tree snapshot already holds everything
            return
        entry = self._snapshot(ck, rel, path)
        if entry is not None and not self._covered(ck, entry["path"]):
            ck["entries"].append(entry)
            self._save()

    @staticmethod
    def _covered(ck: dict[str, Any], rel: str) -> bool:
        for e in ck["entries"]:
            if e["path"] == rel or (e["kind"] in ("dir", "absent") and rel.startswith(e["path"] + "/")):
                return True
        return False

    def _topmost_missing(self, path: Path) -> Path:
        top, parent = path, path.parent
        while parent != self.workspace and not os.path.lexists(parent):
            top, parent = parent, parent.parent
        return top

    def _snapshot(self, ck: dict[str, Any], rel: str, path: Path) -> dict[str, Any] | None:
        if os.path.islink(path):
            return {"path": rel, "kind": "symlink", "target": os.readlink(path)}
        if not os.path.lexists(path):
            return {"path": self._topmost_missing(path).relative_to(self.workspace).as_posix(),
                    "kind": "absent"}
        snap = self.dir / f"c{ck['id']}" / f"e{len(ck['entries'])}"
        try:
            if path.is_file():
                size = path.stat().st_size
                if ck["bytes"] + size > self.max_bytes:
                    return {"path": rel, "kind": "skipped"}
                snap.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copy2(path, snap)
                ck["bytes"] += size
                return {"path": rel, "kind": "file", "snap": snap.relative_to(self.dir).as_posix()}
            if path.is_dir():
                size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file() and not f.is_symlink())
                if ck["bytes"] + size > self.max_bytes:
                    return {"path": rel, "kind": "skipped"}
                snap.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copytree(path, snap, symlinks=True)
                ck["bytes"] += size
                return {"path": rel, "kind": "dir", "snap": snap.relative_to(self.dir).as_posix()}
        except OSError:
            return {"path": rel, "kind": "skipped"}
        return {"path": rel, "kind": "skipped"}                # sockets, devices, ...

    # ------------------------------------------------------------------ queries
    @property
    def checkpoint_count(self) -> int:
        return len(self._checkpoints)

    def latest(self) -> dict[str, Any] | None:
        return self._checkpoints[-1] if self._checkpoints else None

    def summary(self) -> list[str]:
        """One line per checkpoint, newest first."""
        return [f"#{c['id']}  {c['time']}  "
                f"{'workspace snapshot' if 'tree' in c else str(len(c['entries'])) + ' file(s)'}  {c['label']}"
                for c in reversed(self._checkpoints)]

    # ------------------------------------------------------------------ undo
    def undo_last(self) -> UndoReport | None:
        """Restore the state before the latest checkpoint's changes. None if there is nothing."""
        if not self._checkpoints:
            return None
        ck = self._checkpoints.pop()
        if self._current is ck:
            self._current = None
        report = UndoReport(ck["label"], commands_run=ck.get("commands", 0))
        if "tree" in ck and self._shadow is not None:
            try:
                after = self._shadow.snapshot()
                changes = self._shadow.changes(ck["tree"], after)
                report.restored, report.removed, report.skipped = self._shadow.restore(ck["tree"], changes)
                if self._shadow.skipped_large:
                    report.skipped += [f"{p} (too large to track)" for p in self._shadow.skipped_large[:5]]
            except ShadowError as exc:
                self.last_problem = str(exc)
                report.skipped.append(f"(undo failed: {exc})")
            self._save()
            return report
        for entry in reversed(ck["entries"]):
            rel, kind = entry["path"], entry["kind"]
            target = self.workspace / rel
            if kind == "skipped":
                report.skipped.append(rel)
                continue
            if not _inside(self.workspace, target):
                report.skipped.append(rel)
                continue
            try:
                if os.path.islink(target) or target.is_file():
                    target.unlink()
                elif target.is_dir():
                    shutil.rmtree(target)
                if kind == "absent":
                    report.removed.append(rel)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                if kind == "file":
                    shutil.copy2(self.dir / entry["snap"], target)
                elif kind == "dir":
                    shutil.copytree(self.dir / entry["snap"], target, symlinks=True)
                elif kind == "symlink":
                    os.symlink(entry["target"], target)
                report.restored.append(rel)
            except OSError:
                report.skipped.append(rel)
        shutil.rmtree(self.dir / f"c{ck['id']}", ignore_errors=True)
        self._save()
        return report

    # ------------------------------------------------------------------ diff
    def diff_last(self) -> str | None:
        """Unified diff of what the latest checkpoint changed (None if there is no checkpoint)."""
        ck = self.latest()
        if ck is None:
            return None
        parts: list[str] = []
        if "tree" in ck and self._shadow is not None:
            try:
                parts.append(self._shadow.patch(ck["tree"], self._shadow.snapshot()))
            except ShadowError as exc:
                parts.append(f"(diff unavailable: {exc})")
        for entry in ck["entries"]:
            rel, kind = entry["path"], entry["kind"]
            current = self.workspace / rel
            if kind == "file":
                parts.append(self._file_diff(rel, self.dir / entry["snap"], current))
            elif kind == "absent":
                parts += self._created(rel, current)
            elif kind == "dir":
                parts += self._dir_diff(rel, self.dir / entry["snap"], current)
            elif kind == "symlink":
                parts.append(f"symlink {rel} -> {entry['target']} was replaced or removed")
            else:
                parts.append(f"{rel}: too large to track; cannot be shown or undone")
        if ck.get("commands"):
            parts.append(f"({ck['commands']} shell command(s) ran in this turn; their effects are not tracked)")
        text = "\n".join(p for p in parts if p).strip() or "(no file changes recorded)"
        lines = text.splitlines()
        if len(lines) > MAX_DIFF_LINES:
            text = "\n".join(lines[:MAX_DIFF_LINES]) + f"\n... ({len(lines) - MAX_DIFF_LINES} more lines)"
        return text

    @staticmethod
    def _read_text(path: Path) -> str | None:
        try:
            if path.stat().st_size > MAX_DIFF_FILE_BYTES:
                return None
            return path.read_bytes().decode("utf-8")
        except (OSError, UnicodeDecodeError):
            return None

    def _file_diff(self, rel: str, old_path: Path, current: Path) -> str:
        old = self._read_text(old_path)
        if not os.path.lexists(current):
            return f"deleted {rel}" if old is None else self._udiff(rel, old, "")
        if not current.is_file():
            return f"{rel} was replaced by something that is not a file"
        new = self._read_text(current)
        if old is None or new is None:
            same = old_path.read_bytes() == current.read_bytes() if current.stat().st_size < 50_000_000 else False
            return "" if same else f"binary or large file changed: {rel}"
        return self._udiff(rel, old, new)

    @staticmethod
    def _udiff(rel: str, old: str, new: str) -> str:
        split = lambda s: s.split("\n")[:-1] if s.endswith("\n") else s.split("\n")  # noqa: E731
        diff = list(difflib.unified_diff(split(old), split(new), f"a/{rel}", f"b/{rel}", lineterm="", n=2))
        return "\n".join(diff)

    def _created(self, rel: str, current: Path) -> list[str]:
        if not os.path.lexists(current):
            return [f"(created {rel}, already removed)"]
        if current.is_file() and not current.is_symlink():
            text = self._read_text(current)
            return [self._udiff(rel, "", text).replace(f"--- a/{rel}", "--- /dev/null")
                    if text is not None else f"created binary or large file: {rel}"]
        out = [f"created directory {rel}/"]
        for f in sorted(p for p in current.rglob("*") if p.is_file() and not p.is_symlink()):
            sub = f.relative_to(self.workspace).as_posix()
            out += self._created(sub, f)
        return out

    def _dir_diff(self, rel: str, snap: Path, current: Path) -> list[str]:
        files = lambda root: {p.relative_to(root).as_posix(): p for p in root.rglob("*")  # noqa: E731
                              if p.is_file() and not p.is_symlink()} if root.is_dir() else {}
        old, new = files(snap), files(current)
        out = []
        for name in sorted(old.keys() | new.keys()):
            sub = f"{rel}/{name}"
            if name not in new:
                out.append(f"deleted {sub}")
            elif name not in old:
                out += self._created(sub, new[name])
            else:
                out.append(self._file_diff(sub, old[name], new[name]))
        return out or [f"directory {rel}/ unchanged"]
