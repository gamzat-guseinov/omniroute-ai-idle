"""Crash reports: when something unexpected happens, keep the details for a bug report."""
from __future__ import annotations

import os
import platform
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

from .. import __version__
from ..config import state_dir


def write_crash_report(exc: BaseException, root: Path | None = None, where: str = "") -> Path | None:
    """Write the traceback (no configuration, no keys) to crash.log; returns its path."""
    path = (root or state_dir()) / "crash.log"
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    entry = (f"=== {datetime.now(timezone.utc).isoformat(timespec='seconds')}  aide {__version__}  "
             f"python {platform.python_version()}  {platform.platform()}  {where}\n{text}\n")
    try:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if path.exists() and path.stat().st_size > 500_000:
            os.replace(path, path.with_name("crash.log.1"))
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as fh:
            os.fchmod(fh.fileno(), 0o600)
            fh.write(entry)
        return path
    except OSError:
        return None


def install_signal_handlers() -> None:
    """Make SIGTERM/SIGHUP end aide like a normal exit, so cleanup runs (background processes
    are stopped, the session is saved)."""
    import signal

    def handler(signum, frame):  # noqa: ARG001
        raise SystemExit(128 + signum)

    for name in ("SIGTERM", "SIGHUP"):
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, handler)
            except (ValueError, OSError):      # not in the main thread
                pass
