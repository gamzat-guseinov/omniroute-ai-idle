"""Slash commands: names, help text, parsing and typo suggestions."""
from __future__ import annotations

import difflib
from dataclasses import dataclass


@dataclass(frozen=True)
class CommandSpec:
    name: str
    usage: str
    help: str
    aliases: tuple[str, ...] = ()


COMMANDS: tuple[CommandSpec, ...] = (
    CommandSpec("help", "/help", "show this help"),
    CommandSpec("clear", "/clear", "forget the conversation and start a new session"),
    CommandSpec("model", "/model [name|list]", "show, change or list the model"),
    CommandSpec("mode", "/mode [ask|auto-edit|auto]", "show or change the permission mode"),
    CommandSpec("undo", "/undo", "undo the file changes of the agent's last turn"),
    CommandSpec("diff", "/diff", "show what the agent changed in its last turn"),
    CommandSpec("tokens", "/tokens", "show context usage"),
    CommandSpec("save", "/save [name]", "save this session (it is also saved automatically)"),
    CommandSpec("sessions", "/sessions", "list saved sessions of this workspace"),
    CommandSpec("load", "/load <name>", "resume a saved session"),
    CommandSpec("copy", "/copy [n]", "copy the n-th (default: last) code block of the last reply"),
    CommandSpec("markdown", "/markdown [on|off]", "toggle Markdown rendering (also F2)", ("md",)),
    CommandSpec("expand", "/expand [on|off]", "show full tool output (also F3)"),
    CommandSpec("run", "/run <command>", "run a shell command yourself (asks first)"),
    CommandSpec("audit", "/audit", "show the latest entries of the tool-call audit log"),
    CommandSpec("prompt", "/prompt", "show where the editable system prompt is"),
    CommandSpec("exit", "/exit", "quit", ("quit", "q")),
)

KEYS_HELP = ("Keys:  Enter send   Ctrl+J newline   Up/Down history   Ctrl+C stop   Ctrl+Q quit\n"
             "       F2 Markdown on/off   F3 expand/collapse tool output   F4 copy last code block\n"
             "       click a tool line to expand it")


def parse_command(text: str) -> tuple[str, str]:
    """'/mode auto' -> ('mode', 'auto'). The name is lower-cased."""
    body = text.strip()[1:]
    name, _, arg = body.partition(" ")
    return name.strip().lower(), arg.strip()


def resolve(name: str) -> CommandSpec | None:
    for spec in COMMANDS:
        if name == spec.name or name in spec.aliases:
            return spec
    return None


def suggest(name: str) -> str | None:
    names = [s.name for s in COMMANDS]
    match = difflib.get_close_matches(name, names, n=1, cutoff=0.6)
    return match[0] if match else None


def help_text() -> str:
    width = max(len(s.usage) for s in COMMANDS)
    lines = ["Describe what you want; the agent explores, edits files, runs commands and checks "
             "the results. Every step is shown.", "", "Commands:"]
    lines += [f"  {s.usage:<{width}}  {s.help}" for s in COMMANDS]
    return "\n".join(lines + ["", KEYS_HELP])
