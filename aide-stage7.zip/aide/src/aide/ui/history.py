"""Input history for the prompt (up/down arrows), persisted between sessions."""
from __future__ import annotations

import json
import os
from pathlib import Path


class InputHistory:
    def __init__(self, path: Path | None = None, limit: int = 500) -> None:
        self.path, self.limit = path, limit
        self.items: list[str] = []
        self._pos: int | None = None          # None = not browsing
        self._draft = ""
        self._load()

    def _load(self) -> None:
        if self.path is None:
            return
        try:
            for line in self.path.read_text(encoding="utf-8").splitlines():
                try:
                    text = json.loads(line)
                except ValueError:
                    continue
                if isinstance(text, str) and text:
                    self.items.append(text)
        except OSError:
            pass
        self.items = self.items[-self.limit:]

    def add(self, text: str) -> None:
        self.reset()
        if not text.strip() or (self.items and self.items[-1] == text):
            return
        self.items.append(text)
        self.items = self.items[-self.limit:]
        if self.path is not None:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                fd = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
                with os.fdopen(fd, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(text, ensure_ascii=False) + "\n")
            except OSError:
                pass

    def reset(self) -> None:
        self._pos, self._draft = None, ""

    def previous(self, current: str) -> str | None:
        """Older entry, or None if there is none. `current` is kept as a draft to come back to."""
        if not self.items:
            return None
        if self._pos is None:
            self._draft, self._pos = current, len(self.items)
        if self._pos == 0:
            return None
        self._pos -= 1
        return self.items[self._pos]

    def next(self) -> str | None:
        """Newer entry (finally the draft); None if not browsing."""
        if self._pos is None:
            return None
        self._pos += 1
        if self._pos >= len(self.items):
            draft = self._draft
            self.reset()
            return draft
        return self.items[self._pos]

    @property
    def browsing(self) -> bool:
        return self._pos is not None
