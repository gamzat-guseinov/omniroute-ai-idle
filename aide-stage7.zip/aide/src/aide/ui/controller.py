"""Everything the chat does, independent of the UI toolkit.

The Controller owns the conversation, the agent, undo, sessions and the slash commands. It talks
to the screen only through a small `View` interface, so all of it is testable without a terminal;
`ui/view.py` implements the interface with Textual widgets.
"""
from __future__ import annotations

import asyncio
import time
from contextlib import aclosing
from pathlib import Path
from typing import Any, Protocol

from .. import __version__
from ..agent.conversation import Conversation
from ..agent.events import (AssistantMessage, Failed, Notice, TextChunk, Thinking, ToolEnd,
                            ToolStart, UsageUpdate)
from ..agent.executor import ToolExecutor
from ..agent.loop import AgentLoop, tool_instructions
from ..agent.permissions import Decision, PermissionPolicy, parse_mode
from ..agent.prompt import build_system_prompt, load_template
from ..client.errors import OmniRouteError
from ..config import ConfigError, Config, state_dir
from ..debuglog import DebugLog
from ..formats.model import ToolCall
from ..safety.audit import AuditLog
from ..safety.crash import write_crash_report
from ..safety.undo import UndoStore
from ..sessions import SessionStore, check_name, default_session_name, transcript
from ..tools import Limits, ToolResult, create_registry
from .commands import help_text, parse_command, resolve, suggest
from .history import InputHistory
from .markdown import extract_code_blocks

PAINT_INTERVAL = 0.04
ALLOWED_WHILE_BUSY = {"help", "tokens", "markdown", "expand", "copy", "sessions", "prompt",
                      "mode", "diff", "exit"}


class View(Protocol):
    """What the Controller needs from the screen."""
    def add_text(self, text: str, kind: str) -> Any: ...            # kind: user|info|warning|error
    def start_assistant(self) -> Any: ...
    def update_assistant(self, handle: Any, raw: str, final: bool) -> None: ...
    def remove(self, handle: Any) -> None: ...
    def add_tool(self, call: ToolCall) -> Any: ...
    def finish_tool(self, handle: Any, call: ToolCall, result: ToolResult) -> None: ...
    def show_diff(self, text: str) -> None: ...
    def clear(self) -> None: ...
    def set_status(self, text: str) -> None: ...
    def set_markdown(self, on: bool) -> None: ...
    def set_tools_expanded(self, on: bool) -> None: ...
    def copy(self, text: str) -> str | None: ...                     # how it was copied, or None
    def start_task(self, coro: Any) -> Any: ...                      # returns a handle with .cancel()
    def set_prompt_text(self, text: str) -> None: ...
    def quit(self) -> None: ...
    async def approve(self, request: Any) -> Decision: ...


class Controller:
    def __init__(self, cfg: Config, workspace: Path, view: View, debug: DebugLog | None = None, *,
                 client: Any = None, state_root: Path | None = None, template: str | None = None,
                 prompt_path: Path | None = None, session: str | None = None,
                 resume: bool = False) -> None:
        self.cfg, self.workspace, self.view = cfg, Path(workspace), view
        self.debug = debug or DebugLog(None)
        if client is None:
            from ..client.omniroute import OmniRouteClient   # needs httpx
            client = OmniRouteClient(cfg, debug=self.debug)
        self.client = client
        root = state_root or state_dir()
        self.state_root = root
        self.undo = UndoStore(workspace, root)
        self.sessions = SessionStore(workspace, root)
        self.history = InputHistory(root / "history")
        self.registry = create_registry(
            workspace, limits=Limits(command_timeout=cfg.command_timeout),
            before_write=self.undo.record, before_exec=self.undo.note_command)
        self.policy = PermissionPolicy(cfg.permission_mode, self.registry.ctx.sandbox)
        self.audit = AuditLog(root / "audit.log" if cfg.audit_log else None, redact=self.debug.redact)
        self.executor = ToolExecutor(self.registry, self.policy, view.approve, audit=self.audit,
                                     debug=self.debug)
        if template is None:
            template, prompt_path = load_template()
        self.template, self.prompt_path = template, prompt_path
        self.conv = Conversation(self._build_prompt(cfg.tool_format))
        self.agent = AgentLoop(
            self.client, self.executor, self.conv, tool_format=cfg.tool_format,
            max_tool_calls=cfg.max_tool_calls, context_tokens=cfg.context_tokens,
            max_tokens=cfg.max_tokens, build_prompt=self._build_prompt)
        self.markdown = cfg.markdown
        self.tools_expanded = False
        self.busy = False
        self.last_assistant_text = ""
        self.last_usage: Any = None
        self.session_name = session or default_session_name()
        self._task: Any = None
        self._copy_hint_shown = False
        self._resume = resume or bool(session)
        self._start_error = ""
        self.audit.session = self.session_name
        if self._resume:
            name = session or self.sessions.latest()
            try:
                if name is None:
                    raise ConfigError("There is no saved session in this workspace yet.")
                self.sessions.load(name, self.conv)
                self.session_name = name
                self.audit.session = name
            except ConfigError as exc:
                self._resume, self._start_error = False, str(exc)

    # ------------------------------------------------------------------ setup / teardown
    def _build_prompt(self, tool_format: str) -> str:
        return build_system_prompt(self.template, workspace=self.workspace, mode=self.policy.mode.value
                                   if hasattr(self, "policy") else self.cfg.permission_mode,
                                   tool_instructions=tool_instructions(self.registry, tool_format)
                                   if hasattr(self, "registry") else "")

    def start(self) -> None:
        v = self.view
        v.add_text(f"aide {__version__}  ·  workspace: {self.workspace}\n"
                   f"model: {self.client.model}  ·  mode: {self.policy.mode.value}  ·  "
                   f"tools: {self.agent.tool_format}\nsystem prompt (editable): {self.prompt_path}\n"
                   f"undo: {self._undo_description()}\nType /help for commands.", "info")
        if self._start_error:
            v.add_text(self._start_error, "warning")
        if self._resume:
            self._replay()
            v.add_text(f"Resumed session '{self.session_name}' ({len(self.conv.messages)} messages).", "info")
        self._refresh_status()

    def _undo_description(self) -> str:
        if self.undo.backend == "git":
            return "workspace snapshots per turn (files changed by commands too; .gitignore'd files excluded)"
        return "file tools only (install git to also undo changes made by shell commands)"

    def close(self) -> None:
        try:
            self._autosave()
        finally:
            self.registry.ctx.close()          # stops background processes
            self.debug.close()

    # ------------------------------------------------------------------ status
    def estimate_tokens(self) -> int:
        return self.agent.ctx.estimate(self.conv)

    def status_line(self, note: str = "") -> str:
        parts = [f"model: {self.client.model}", f"mode: {self.policy.mode.value}",
                 f"markdown: {'on' if self.markdown else 'off'}",
                 f"ctx ~{self.estimate_tokens() / 1000:.1f}k/{self.cfg.context_tokens // 1000}k",
                 f"session: {self.session_name}"]
        if note:
            parts.append(note)
        return "  |  ".join(parts)

    def _refresh_status(self, note: str = "") -> None:
        self.view.set_status(self.status_line(note))

    # ------------------------------------------------------------------ input
    def submit(self, text: str) -> None:
        """Entry point for everything the user types. Never raises: a bug in one command must
        not take the whole interface down."""
        try:
            self._submit(text)
        except Exception as exc:
            self._internal_error("handling your input", exc)

    def _internal_error(self, where: str, exc: BaseException) -> None:
        path = write_crash_report(exc, self.state_root, where)
        self.audit.log("internal_error", where=where, error=repr(exc)[:300])
        self.debug.log("internal_error", {"where": where, "error": repr(exc)})
        self.view.add_text(f"Internal error while {where}: {exc!r}. The session is still usable."
                           + (f" Details: {path}" if path else ""), "error")
        self.busy = False

    def _submit(self, text: str) -> None:
        text = text.strip()
        if not text:
            return
        self.history.add(text)
        if text.startswith("/"):
            self._command(text)
            return
        if self.busy:
            self.view.add_text("Still working. Press Ctrl+C to stop, then send your message.", "warning")
            return
        self._start_agent(text)

    def stop(self) -> None:
        if self.busy and self._task is not None:
            self.executor.cancel()                 # kills a running command's process group
            self._task.cancel()
        else:
            self.view.add_text("Nothing is running. Press Ctrl+Q or type /exit to quit.", "info")

    # ------------------------------------------------------------------ agent
    def _start_agent(self, text: str) -> None:
        self.view.add_text(f"> {text}", "user")
        self.undo.begin_turn(text)
        self.busy = True
        self._refresh_status("working... (Ctrl+C to stop)")
        self._task = self.view.start_task(self._agent_task(text))

    async def _agent_task(self, text: str) -> None:
        v = self.view
        handle: Any = None
        chunks: list[str] = []
        last_paint = 0.0
        tools: dict[str, Any] = {}
        error_text: str | None = None
        cancelled = False
        try:
            async with aclosing(self.agent.run(text)) as events:
                async for ev in events:
                    if isinstance(ev, TextChunk):
                        if handle is None:
                            handle, chunks = v.start_assistant(), []
                        chunks.append(ev.text)
                        now = time.monotonic()
                        if now - last_paint >= PAINT_INTERVAL:
                            v.update_assistant(handle, "".join(chunks), False)
                            last_paint = now
                    elif isinstance(ev, AssistantMessage):
                        if ev.text:
                            if handle is None:
                                handle = v.start_assistant()
                            v.update_assistant(handle, ev.text, True)
                            self.last_assistant_text = ev.text
                            self._maybe_copy_hint(ev.text)
                        elif handle is not None:
                            v.remove(handle)
                        handle, chunks = None, []
                    elif isinstance(ev, ToolStart):
                        tools[ev.call.id] = v.add_tool(ev.call)
                        self._refresh_status(f"running {ev.call.name}... (Ctrl+C to stop)")
                    elif isinstance(ev, ToolEnd):
                        card = tools.pop(ev.call.id, None)
                        if card is not None:
                            v.finish_tool(card, ev.call, ev.result)
                        self._refresh_status("working... (Ctrl+C to stop)")
                    elif isinstance(ev, Notice):
                        v.add_text(ev.text, "warning" if ev.level == "warning" else "info")
                    elif isinstance(ev, Thinking):
                        self._refresh_status("model is thinking... (Ctrl+C to stop)")
                    elif isinstance(ev, UsageUpdate):
                        self.last_usage = ev.usage
                    elif isinstance(ev, Failed):
                        v.add_text(f"Error: {ev.message}", "error")
        except asyncio.CancelledError:
            cancelled = True
            raise
        except Exception as exc:      # a bug must not take the whole UI down
            path = write_crash_report(exc, self.state_root, "the agent loop")
            self.audit.log("internal_error", where="agent loop", error=repr(exc)[:300])
            error_text = f"Unexpected error: {exc!r}" + (f" (details: {path})" if path else "")
        finally:
            # synchronous on purpose: this also runs while the task is being cancelled
            self.busy, self._task = False, None
            if handle is not None and chunks:
                v.update_assistant(handle, "".join(chunks), True)
                self.last_assistant_text = "".join(chunks)
            if cancelled:
                v.add_text("Stopped.", "info")
            if error_text:
                v.add_text(error_text, "error")
            self._autosave()
            self._refresh_status()

    def _maybe_copy_hint(self, text: str) -> None:
        n = len(extract_code_blocks(text))
        if n and not self._copy_hint_shown:
            self._copy_hint_shown = True
            self.view.add_text(f"{n} code block(s) in that reply: /copy [n] or F4 copies one to the clipboard.", "info")

    def _autosave(self) -> None:
        if not self.conv.messages:
            return
        try:
            self.sessions.save(self.session_name, self.conv, {
                "model": self.client.model, "workspace": str(self.workspace),
                "mode": self.policy.mode.value, "tool_format": self.agent.tool_format})
        except (OSError, ConfigError):
            pass

    def _replay(self) -> None:
        v = self.view
        for item in transcript(self.conv, set(self.registry.names())):
            if item.kind == "user":
                v.add_text(f"> {item.text}", "user")
            elif item.kind == "assistant":
                h = v.start_assistant()
                v.update_assistant(h, item.text, True)
                self.last_assistant_text = item.text
            elif item.kind == "note":
                v.add_text(item.text, "info")
            elif item.kind == "tool" and item.call is not None:
                card = v.add_tool(item.call)
                v.finish_tool(card, item.call, item.result or ToolResult(True, "(no result recorded)"))

    # ------------------------------------------------------------------ slash commands
    def _command(self, text: str) -> None:
        name, arg = parse_command(text)
        spec = resolve(name)
        if spec is None:
            hint = suggest(name)
            self.view.add_text(f"Unknown command /{name}." + (f" Did you mean /{hint}?" if hint else " Type /help."), "error")
            return
        if self.busy and spec.name not in ALLOWED_WHILE_BUSY:
            self.view.add_text(f"/{spec.name} is not available while the agent is working. "
                               f"Press Ctrl+C to stop it first.", "warning")
            return
        getattr(self, f"_cmd_{spec.name}")(arg)

    def _say(self, text: str, kind: str = "info") -> None:
        self.view.add_text(text, kind)

    def _cmd_help(self, arg: str) -> None:
        self._say(help_text())

    def _cmd_clear(self, arg: str) -> None:
        self._autosave()
        self.conv.clear()
        self.view.clear()
        self.session_name = default_session_name()
        self.audit.session = self.session_name
        self.undo.begin_turn("")
        self._say(f"Conversation cleared. New session: {self.session_name}")
        self._refresh_status()

    def _cmd_model(self, arg: str) -> None:
        if not arg:
            self._say(f"Model: {self.client.model}   (/model list shows what the server offers, "
                      f"/model <name> switches)")
        elif arg == "list":
            self._task = self.view.start_task(self._list_models())
        else:
            self.client.set_model(arg)
            self._say(f"Model changed to {arg}.")
            self._refresh_status()

    async def _list_models(self) -> None:
        try:
            models = await self.client.list_models()
        except OmniRouteError as exc:
            self._say(f"Could not list models: {exc.user_message()}", "error")
            return
        finally:
            self._task = None
        shown = "\n".join(f"  {m}{'   <- current' if m == self.client.model else ''}" for m in models[:60])
        more = f"\n  ... and {len(models) - 60} more" if len(models) > 60 else ""
        self._say(f"{len(models)} model(s):\n{shown}{more}" if models else "The server listed no models.")

    def _cmd_mode(self, arg: str) -> None:
        if arg:
            try:
                self.policy.mode = parse_mode(arg)
            except ValueError as exc:
                self._say(str(exc), "error")
                return
            self.conv.system_prompt = self._build_prompt(self.agent.tool_format)
        self._say(f"Permission mode: {self.policy.mode.value}  (ask = confirm everything, auto-edit = "
                  f"auto-approve file edits, auto = approve everything inside the workspace; dangerous "
                  f"commands are always confirmed)")
        self._refresh_status()

    def _cmd_undo(self, arg: str) -> None:
        report = self.undo.undo_last()
        if report is None:
            self._say("Nothing to undo.")
            return
        self.audit.log("undo", label=report.label, restored=len(report.restored),
                       removed=len(report.removed), skipped=len(report.skipped))
        if self.undo.last_problem:
            self._say(f"Note: workspace snapshots were not possible ({self.undo.last_problem}); "
                      f"only changes made by file tools can be undone.", "warning")
        if report.nothing_to_do:
            self._say("That turn made no tracked file changes." + (
                f" It ran {report.commands_run} shell command(s), which cannot be undone." if report.commands_run else ""))
            return
        lines = [f"Undid the changes of: {report.label or '(turn)'}"]
        for title, items in (("restored", report.restored), ("removed (it was created)", report.removed)):
            if items:
                lines.append(f"  {title}: " + ", ".join(items[:10]) + (f" (+{len(items) - 10} more)" if len(items) > 10 else ""))
        if report.skipped:
            lines.append("  could NOT restore: " + ", ".join(report.skipped[:10]))
        if report.commands_run:
            lines.append(f"  note: {report.commands_run} shell command(s) ran in that turn; their effects were not undone.")
        self._say("\n".join(lines), "warning" if report.skipped else "info")
        self.conv.add_note("[note from the user interface] The user undid your last file changes: "
                           + "; ".join(report.restored + [f"removed {p}" for p in report.removed])
                           + ". The files are back to their earlier state. Re-read them before editing.")
        self._refresh_status()

    def _cmd_diff(self, arg: str) -> None:
        text = self.undo.diff_last()
        if text is None:
            self._say("No changes recorded yet.")
        else:
            self.view.show_diff(text)

    def _cmd_tokens(self, arg: str) -> None:
        est, budget = self.estimate_tokens(), self.cfg.context_tokens
        lines = [f"Context: about {est} of {budget} tokens ({100 * est // max(budget, 1)}%), "
                 f"{len(self.conv.messages)} messages" + (", older history summarized" if self.conv.summary else "")]
        if self.last_usage:
            u = self.last_usage
            lines.append(f"Last request: {u.prompt_tokens} prompt + {u.completion_tokens} completion tokens")
        lines.append(f"Estimate calibration: x{self.agent.ctx.scale:.2f} (estimate vs. server count)")
        self._say("\n".join(lines))

    def _cmd_save(self, arg: str) -> None:
        try:
            if arg:
                self.session_name = check_name(arg)
            path = self.sessions.save(self.session_name, self.conv, {"model": self.client.model})
        except (ConfigError, OSError) as exc:
            self._say(f"Could not save: {exc}", "error")
            return
        self._say(f"Saved session '{self.session_name}' to {path}")
        self._refresh_status()

    def _cmd_sessions(self, arg: str) -> None:
        infos = self.sessions.list()
        if not infos:
            self._say("No saved sessions for this workspace yet.")
            return
        rows = [f"{'*' if i.name == self.session_name else ' '} {i.name:<20} {i.updated[:16]}  "
                f"{i.messages:>3} msgs  {i.title}" for i in infos[:30]]
        self._say("Saved sessions (/load <name> resumes one):\n" + "\n".join(rows))

    def _cmd_load(self, arg: str) -> None:
        if not arg:
            self._say("Usage: /load <name>  (see /sessions)", "error")
            return
        self._autosave()
        probe = Conversation(self.conv.system_prompt)
        try:
            self.sessions.load(arg, probe)
        except ConfigError as exc:
            self._say(str(exc), "error")
            return
        self.conv.messages, self.conv.summary = probe.messages, probe.summary
        self.session_name = check_name(arg)
        self.audit.session = self.session_name
        self.view.clear()
        self._replay()
        self._say(f"Resumed session '{self.session_name}' ({len(self.conv.messages)} messages).")
        self._refresh_status()

    def _cmd_copy(self, arg: str) -> None:
        self.copy_code(arg)

    def copy_code(self, arg: str | None = None) -> None:
        blocks = extract_code_blocks(self.last_assistant_text)
        if not blocks:
            self._say("There is no code block in the last reply.", "warning")
            return
        try:
            n = int(arg) if arg else len(blocks)
        except ValueError:
            self._say("Usage: /copy [n]  (n = number of the code block)", "error")
            return
        if not 1 <= n <= len(blocks):
            self._say(f"The last reply has {len(blocks)} code block(s); choose 1-{len(blocks)}.", "error")
            return
        code = blocks[n - 1].code
        how = self.view.copy(code)
        if how:
            self._say(f"Copied code block {n} of {len(blocks)} ({len(code.splitlines())} lines) via {how}.")
        else:
            self._say("No clipboard available. Install wl-clipboard or xclip, or select the text with the mouse.", "warning")

    def _cmd_markdown(self, arg: str) -> None:
        self.toggle_markdown(None if not arg else arg.lower() in ("on", "true", "1", "yes"))

    def toggle_markdown(self, value: bool | None = None) -> None:
        self.markdown = (not self.markdown) if value is None else value
        self.view.set_markdown(self.markdown)
        self._refresh_status()

    def _cmd_expand(self, arg: str) -> None:
        self.toggle_tools(None if not arg else arg.lower() in ("on", "true", "1", "yes"))

    def toggle_tools(self, value: bool | None = None) -> None:
        self.tools_expanded = (not self.tools_expanded) if value is None else value
        self.view.set_tools_expanded(self.tools_expanded)

    def _cmd_run(self, arg: str) -> None:
        if not arg:
            self._say("Usage: /run <shell command>", "error")
            return
        self.view.add_text(f"$ {arg}", "user")
        self.undo.begin_turn(f"/run {arg}")
        self.busy = True
        self._refresh_status("running command... (Ctrl+C to stop)")
        self._task = self.view.start_task(self._manual_run(arg))

    async def _manual_run(self, command: str) -> None:
        call = ToolCall("run_command", {"command": command}, "manual", source="manual")
        card = self.view.add_tool(call)
        cancelled = False
        try:
            result = await self.executor.run("run_command", call.arguments)
            self.view.finish_tool(card, call, result)
        except asyncio.CancelledError:
            cancelled = True
            raise
        finally:
            self.busy, self._task = False, None
            if cancelled:
                self.view.add_text("Stopped.", "info")
            self._refresh_status()

    def _cmd_audit(self, arg: str) -> None:
        if not self.audit.enabled:
            self._say("The audit log is switched off (audit_log = false in the config).")
            return
        rows = []
        for e in self.audit.tail(12):
            if e.get("event") == "tool":
                args = e.get("args", {})
                what = args.get("command") or args.get("path") or args.get("source") or args.get("pattern") or ""
                rows.append(f"{e['ts'][11:19]}  {e['tool']:<15} {e['decision']:<20} {'ok ' if e['ok'] else 'FAIL'}  {str(what)[:60]}")
            else:
                rows.append(f"{e['ts'][11:19]}  {e['event']}")
        self._say(f"Audit log: {self.audit.path}\n" + ("\n".join(rows) if rows else "(no entries yet)"))

    def _cmd_prompt(self, arg: str) -> None:
        self._say(f"System prompt file: {self.prompt_path}\nEdit it with any editor; changes apply the "
                  f"next time aide starts.")

    def _cmd_exit(self, arg: str) -> None:
        self.close()
        self.view.quit()
