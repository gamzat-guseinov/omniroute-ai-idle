"""Approval dialog shown when the agent wants to write, delete or run something."""
from __future__ import annotations

from rich.syntax import Syntax
from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Footer, Static

from ..agent.permissions import ApprovalRequest, Decision


class ApprovalScreen(ModalScreen[Decision]):
    """Modal dialog: y = allow, n/Esc = deny, a = allow these programs for the session."""

    BINDINGS = [
        Binding("y", "approve", "Allow"),
        Binding("n", "deny", "Deny"),
        Binding("escape", "deny", "Deny", show=False),
        Binding("a", "always", "Always (session)"),
    ]
    DEFAULT_CSS = """
    ApprovalScreen { align: center middle; }
    #dialog { width: 90%; height: auto; max-height: 90%; padding: 1 2;
              border: thick $primary; background: $surface; }
    #dialog.danger { border: thick $error; }
    #detail { height: auto; max-height: 20; margin: 1 0; }
    """

    def __init__(self, request: ApprovalRequest) -> None:
        super().__init__()
        self.request = request

    def compose(self) -> ComposeResult:
        r = self.request
        title = Text()
        title.append("DANGEROUS  " if r.dangerous else "Approval needed  ",
                     style="bold red" if r.dangerous else "bold yellow")
        title.append(r.title, style="bold")
        body = Text()
        for reason in r.reasons:
            body.append(f"! {reason}\n", style="red" if r.dangerous else "yellow")
        with Vertical(id="dialog", classes="danger" if r.dangerous else ""):
            yield Static(title)
            if r.reasons:
                yield Static(body)
            if r.detail:
                looks_like_diff = r.kind in ("write", "destructive") and r.detail.startswith(("---", "+++", "@@"))
                content = Syntax(r.detail, "diff", word_wrap=True) if looks_like_diff else Text(r.detail)
                yield VerticalScroll(Static(content), id="detail")
            keys = "[y] allow   [n] deny" + ("   [a] always allow these programs this session"
                                             if r.can_remember else "")
            yield Static(Text(keys, style="dim"))
        yield Footer()

    def action_approve(self) -> None:
        self.dismiss(Decision(True))

    def action_deny(self) -> None:
        self.dismiss(Decision(False))

    def action_always(self) -> None:
        if self.request.can_remember:
            self.dismiss(Decision(True, remember=True))
        else:
            self.notify("Not available for this action.", severity="warning")
