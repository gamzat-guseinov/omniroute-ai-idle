"""Copy text to the system clipboard using whatever tool the machine has."""
from __future__ import annotations

import os
import shutil
import subprocess
from typing import Callable

_TOOLS = [("wl-copy", ["wl-copy"], "WAYLAND_DISPLAY"),
          ("xclip", ["xclip", "-selection", "clipboard"], "DISPLAY"),
          ("xsel", ["xsel", "--clipboard", "--input"], "DISPLAY")]


def copy_text(text: str, *, which: Callable[[str], str | None] = shutil.which,
              run: Callable[..., object] = subprocess.run,
              env: dict[str, str] | None = None) -> str | None:
    """Copy via wl-copy, xclip or xsel. Returns the tool used, or None if none worked
    (the UI then falls back to the terminal's OSC 52 clipboard)."""
    env = dict(os.environ) if env is None else env
    for name, argv, needs_env in _TOOLS:
        if not which(name) or not env.get(needs_env):
            continue
        try:
            run(argv, input=text.encode("utf-8"), check=True, timeout=5,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return name
        except (OSError, subprocess.SubprocessError):
            continue
    return None
