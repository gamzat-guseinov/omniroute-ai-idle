"""Plain-text rendering helpers for tool calls and results (no UI toolkit needed)."""
from __future__ import annotations

import json
from typing import Any

from ..formats.model import ToolCall
from ..tools.base import ToolResult


def _clip(text: str, width: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= width else text[: width - 1] + "…"


def describe_call(call: ToolCall, width: int = 100) -> str:
    """One-line summary of what a tool call does, e.g. `edit_file src/app.py`."""
    a: dict[str, Any] = call.arguments
    n = call.name
    if n in ("run_command", "run_background"):
        detail = str(a.get("command", ""))
    elif n == "read_file":
        detail = str(a.get("path", ""))
        if a.get("start_line") or a.get("end_line"):
            detail += f":{a.get('start_line', 1)}-{a.get('end_line', '')}"
    elif n == "move_file":
        detail = f"{a.get('source', '')} -> {a.get('destination', '')}"
    elif n == "search":
        detail = f"{a.get('pattern', '')!r} in {a.get('path', '.')}"
    elif "path" in a:
        detail = str(a["path"])
    elif "id" in a:
        detail = str(a["id"])
    else:
        detail = json.dumps(a, ensure_ascii=False, default=str) if a else ""
    return _clip(f"{n} {detail}".strip(), width)


def status_symbol(result: ToolResult) -> str:
    if result.meta.get("denied"):
        return "⊘"
    return "✓" if result.ok else "✗"


def result_lines(result: ToolResult, max_lines: int = 8, width: int = 120) -> list[str]:
    """A short preview of a tool result: the first lines, each clipped, with a 'more' note."""
    lines = [ln for ln in result.output.splitlines() if ln.strip()]
    shown = [_clip(ln, width) for ln in lines[:max_lines]]
    if len(lines) > max_lines:
        shown.append(f"… {len(lines) - max_lines} more lines")
    return shown


def styled_lines(text: str) -> list[tuple[str, str]]:
    """(line, rich-style) pairs; the lines of a unified diff get diff colours."""
    out: list[tuple[str, str]] = []
    in_diff = False
    for line in text.splitlines():
        if line.startswith(("@@ ", "--- a/", "--- /dev/null")):
            in_diff = True
        style = ""
        if in_diff:
            if line.startswith(("+++", "---")):
                style = "bold"
            elif line.startswith("+"):
                style = "green"
            elif line.startswith("-"):
                style = "red"
            elif line.startswith("@@"):
                style = "cyan"
        out.append((line, style))
    return out
