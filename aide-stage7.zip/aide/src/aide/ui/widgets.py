"""Textual widgets: multiline prompt with history, expandable tool cards, assistant messages."""
from __future__ import annotations

from rich.markdown import Markdown
from rich.text import Text
from textual.binding import Binding
from textual.message import Message
from textual.widgets import Static, TextArea

from ..formats.model import ToolCall
from ..tools.base import ToolResult
from .history import InputHistory
from .render import describe_call, result_lines, status_symbol, styled_lines

MAX_EXPANDED_LINES = 300


class PromptArea(TextArea):
    """Multiline input. Enter sends, Ctrl+J (or Alt/Shift+Enter) adds a line, Up/Down browse the
    history when the cursor is on the first/last line."""

    BINDINGS = [
        Binding("enter", "submit", "Send", priority=True),
        Binding("ctrl+j", "newline", "New line", priority=True),
        Binding("alt+enter", "newline", "New line", show=False, priority=True),
        Binding("shift+enter", "newline", "New line", show=False, priority=True),
        Binding("up", "history_prev", "History", show=False),
        Binding("down", "history_next", "History", show=False),
    ]

    class Submitted(Message):
        def __init__(self, text: str) -> None:
            super().__init__()
            self.text = text

    def __init__(self, history: InputHistory, **kwargs) -> None:
        super().__init__(**kwargs)
        self._history = history

    # -- actions
    def action_submit(self) -> None:
        text = self.text.strip()
        if text:
            self.post_message(self.Submitted(text))
            self.load_text("")
            self._fit_height()

    def action_newline(self) -> None:
        self.insert("\n")

    def action_history_prev(self) -> None:
        if self.cursor_location[0] == 0:
            previous = self._history.previous(self.text)
            if previous is not None:
                self._replace(previous)
        else:
            self.action_cursor_up()

    def action_history_next(self) -> None:
        if self.cursor_location[0] >= self.text.count("\n"):
            newer = self._history.next()
            if newer is not None:
                self._replace(newer)
                return
        self.action_cursor_down()

    # -- helpers
    def _replace(self, text: str) -> None:
        self.load_text(text)
        self.move_cursor(self.document.end)
        self._fit_height()

    def _fit_height(self) -> None:
        lines = self.text.count("\n") + 1
        self.styles.height = max(3, min(lines + 2, 10))      # +2 for the border

    def on_text_area_changed(self, event) -> None:
        self._fit_height()


class AssistantView(Static):
    """An assistant message: plain text while streaming, Markdown when finished."""

    def __init__(self, markdown: bool) -> None:
        super().__init__(Text(""), classes="msg assistant")
        self._raw, self._markdown, self._final = "", markdown, False

    def show(self, raw: str, final: bool) -> None:
        self._raw, self._final = raw, final
        self._paint()

    def set_markdown(self, on: bool) -> None:
        self._markdown = on
        self._paint()

    def _paint(self) -> None:
        if self._markdown and self._final:
            self.update(Markdown(self._raw))
        else:
            self.update(Text(self._raw))


class ToolCard(Static):
    """One tool call: a compact line with a short preview; click (or F3) to see everything."""

    def __init__(self, call: ToolCall, expanded: bool = False) -> None:
        super().__init__(Text(""), classes="msg tool")
        self._call, self._result, self._expanded = call, None, expanded
        self._paint()

    def set_result(self, result: ToolResult | None) -> None:
        self._result = result
        self._paint()

    def set_expanded(self, expanded: bool) -> None:
        self._expanded = expanded
        self._paint()

    def on_click(self) -> None:
        self.set_expanded(not self._expanded)

    def _paint(self) -> None:
        text = Text()
        result = self._result
        symbol = "●" if result is None else status_symbol(result)
        color = "" if result is None or result.ok else ("yellow" if result.meta.get("denied") else "red")
        text.append(f"{symbol} ", style=color or "bold")
        text.append(describe_call(self._call), style="bold")
        if result is not None:
            if self._expanded:
                lines = styled_lines(result.output)
                for line, style in lines[:MAX_EXPANDED_LINES]:
                    text.append("\n  " + line, style=style or "dim")
                if len(lines) > MAX_EXPANDED_LINES:
                    text.append(f"\n  … {len(lines) - MAX_EXPANDED_LINES} more lines", style="dim")
            else:
                for line in result_lines(result):
                    text.append("\n    " + line, style="dim")
                if len(result.output.splitlines()) > 1:
                    text.append("\n    (click or F3 to expand)", style="dim italic")
        self.update(text)
