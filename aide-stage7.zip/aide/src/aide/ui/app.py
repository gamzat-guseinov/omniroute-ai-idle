"""The Textual application: layout and key bindings. All behaviour lives in the Controller."""
from __future__ import annotations

from pathlib import Path

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.widgets import Footer, Header, Static

from ..config import Config
from ..debuglog import DebugLog
from .controller import Controller
from .view import TextualView
from .widgets import PromptArea


class AideApp(App):
    TITLE = "aide"
    CSS = """
    #status { height: 1; padding: 0 1; background: $panel; }
    #chat { height: 1fr; padding: 0 2; }
    #prompt { height: 3; }
    .msg { width: 100%; margin-top: 1; }
    .user { color: cyan; }
    .info { color: gray; }
    .warning { color: yellow; }
    .error { color: red; }
    .tool { margin-top: 0; }
    .diff { margin-top: 1; }
    """
    BINDINGS = [
        Binding("ctrl+c", "stop", "Stop", priority=True),
        Binding("ctrl+q", "quit", "Quit"),
        Binding("f2", "toggle_markdown", "Markdown"),
        Binding("f3", "toggle_tools", "Tool output"),
        Binding("f4", "copy_code", "Copy code"),
    ]

    def __init__(self, config: Config, workspace: Path, debug: DebugLog, *,
                 session: str | None = None, resume: bool = False) -> None:
        super().__init__()
        self.sub_title = f"workspace: {workspace}"
        self.aide_ui = TextualView(self)
        self.aide = Controller(config, workspace, self.aide_ui, debug, session=session, resume=resume)
        self.aide_ui.configure(self.aide.markdown, self.aide.tools_expanded)

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(Text(""), id="status")
        yield VerticalScroll(id="chat")
        yield PromptArea(self.aide.history, id="prompt")
        yield Footer()

    def on_mount(self) -> None:
        self.aide.start()
        self.query_one("#prompt", PromptArea).focus()

    async def on_unmount(self) -> None:
        self.aide.close()
        close = getattr(self.aide.client, "aclose", None)
        if close is not None:
            try:
                await close()
            except Exception:
                pass

    # ------------------------------------------------------------------ events and actions
    def on_prompt_area_submitted(self, event: PromptArea.Submitted) -> None:
        self.aide.submit(event.text)

    def action_stop(self) -> None:
        self.aide.stop()

    def action_toggle_markdown(self) -> None:
        self.aide.toggle_markdown()

    def action_toggle_tools(self) -> None:
        self.aide.toggle_tools()

    def action_copy_code(self) -> None:
        self.aide.copy_code()
