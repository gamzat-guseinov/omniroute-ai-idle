"""Helpers for Markdown chat output (the rendering itself is done by Rich in the UI layer)."""
from __future__ import annotations

import re
from dataclasses import dataclass

_FENCE_RE = re.compile(r"^[ \t]{0,3}(`{3,}|~{3,})[ \t]*([^\s`]*)[^\n]*$")


@dataclass(frozen=True)
class CodeBlock:
    language: str
    code: str


def extract_code_blocks(text: str) -> list[CodeBlock]:
    """Fenced code blocks of a Markdown text, in order. An unclosed fence (a reply that was cut
    off) counts up to the end of the text."""
    blocks: list[CodeBlock] = []
    lines = text.split("\n")
    i = 0
    while i < len(lines):
        m = _FENCE_RE.match(lines[i])
        if not m:
            i += 1
            continue
        fence, lang = m.group(1), m.group(2)
        body: list[str] = []
        i += 1
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith(fence[0] * len(fence)) and set(line) == {fence[0]}:
                break
            body.append(lines[i])
            i += 1
        blocks.append(CodeBlock(lang, "\n".join(body)))
        i += 1
    return blocks
