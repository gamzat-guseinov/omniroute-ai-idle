"""The Controller's View, implemented with Textual widgets."""
from __future__ import annotations

import asyncio
from typing import Any

from rich.text import Text
from textual.containers import VerticalScroll
from textual.widgets import Static

from ..agent.permissions import ApprovalRequest, Decision
from ..formats.model import ToolCall
from ..tools.base import ToolResult
from .clipboard import copy_text
from .prompts import ApprovalScreen
from .render import styled_lines
from .widgets import AssistantView, PromptArea, ToolCard


class TextualView:
    def __init__(self, app: Any) -> None:
        self.app = app
        self.markdown = True
        self.tools_expanded = False

    def configure(self, markdown: bool, tools_expanded: bool) -> None:
        self.markdown, self.tools_expanded = markdown, tools_expanded

    # ------------------------------------------------------------------ helpers
    def _chat(self) -> VerticalScroll:
        return self.app.query_one("#chat", VerticalScroll)

    def _scroll_end(self) -> None:
        chat = self._chat()
        chat.call_after_refresh(chat.scroll_end, animate=False)

    def _mount(self, widget: Any) -> Any:
        self._chat().mount(widget)
        self._scroll_end()
        return widget

    # ------------------------------------------------------------------ View protocol
    def add_text(self, text: str, kind: str) -> Any:
        return self._mount(Static(Text(text), classes=f"msg {kind}"))

    def start_assistant(self) -> Any:
        return self._mount(AssistantView(self.markdown))

    def update_assistant(self, handle: AssistantView, raw: str, final: bool) -> None:
        handle.show(raw, final)
        self._scroll_end()

    def remove(self, handle: Any) -> None:
        handle.remove()

    def add_tool(self, call: ToolCall) -> Any:
        return self._mount(ToolCard(call, self.tools_expanded))

    def finish_tool(self, handle: ToolCard, call: ToolCall, result: ToolResult) -> None:
        handle.set_result(result)
        self._scroll_end()

    def show_diff(self, text: str) -> None:
        out = Text()
        for i, (line, style) in enumerate(styled_lines(text)):
            out.append(("\n" if i else "") + line, style=style)
        self._mount(Static(out, classes="msg diff"))

    def clear(self) -> None:
        self._chat().remove_children()

    def set_status(self, text: str) -> None:
        self.app.query_one("#status", Static).update(Text(text, no_wrap=True, overflow="ellipsis"))

    def set_markdown(self, on: bool) -> None:
        self.markdown = on
        for widget in self.app.query(AssistantView):
            widget.set_markdown(on)

    def set_tools_expanded(self, on: bool) -> None:
        self.tools_expanded = on
        for card in self.app.query(ToolCard):
            card.set_expanded(on)

    def copy(self, text: str) -> str | None:
        tool = copy_text(text)
        if tool:
            return tool
        try:
            self.app.copy_to_clipboard(text)
            return "the terminal clipboard (OSC 52; needs a terminal that supports it)"
        except Exception:
            return None

    def start_task(self, coro: Any) -> Any:
        return self.app.run_worker(coro, group="agent", exclusive=True, exit_on_error=False)

    def set_prompt_text(self, text: str) -> None:
        self.app.query_one("#prompt", PromptArea).load_text(text)

    def quit(self) -> None:
        self.app.exit()

    async def approve(self, request: ApprovalRequest) -> Decision:
        loop = asyncio.get_running_loop()
        answer: asyncio.Future[Decision] = loop.create_future()
        screen = ApprovalScreen(request)
        self.app.push_screen(screen, lambda d: answer.done() or answer.set_result(d or Decision(False)))
        try:
            return await answer
        except asyncio.CancelledError:
            if self.app.screen is screen:
                self.app.pop_screen()            # Ctrl+C while the dialog is open
            raise
