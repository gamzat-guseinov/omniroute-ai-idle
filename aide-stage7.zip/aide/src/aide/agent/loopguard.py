"""Protection against runaway tool loops."""
from __future__ import annotations

import json
from typing import Any

from ..formats.model import ToolCall
from ..tools.base import ToolResult


def _key(call: ToolCall) -> str:
    return call.name + json.dumps(call.arguments, sort_keys=True, default=str)


class LoopGuard:
    """Caps the number of tool calls per user turn and stops identical calls from being
    repeated after they failed (or after they already succeeded several times)."""

    def __init__(self, max_calls: int = 25, *, max_failures: int = 2, max_successes: int = 3,
                 max_strikes: int = 3) -> None:
        self.max_calls, self.max_failures = max_calls, max_failures
        self.max_successes, self.max_strikes = max_successes, max_strikes
        self.reset()

    def reset(self) -> None:
        self.calls = 0
        self.strikes = 0
        self._failures: dict[str, list[str]] = {}
        self._successes: dict[str, int] = {}

    @property
    def exhausted(self) -> bool:
        return self.calls >= self.max_calls

    @property
    def aborted(self) -> bool:
        return self.strikes >= self.max_strikes

    def before(self, call: ToolCall) -> str | None:
        """A message to send back INSTEAD of running the call, or None to run it."""
        key = _key(call)
        failed = self._failures.get(key, [])
        if len(failed) >= self.max_failures:
            self.strikes += 1
            return (f"Not run: you already made this exact call {len(failed)} times and it failed "
                    f"each time. Last error: {failed[-1][:300]}\nChange something (different "
                    f"arguments, read the file again, another approach) or ask the user.")
        if self._successes.get(key, 0) >= self.max_successes:
            self.strikes += 1
            return ("Not run: you already made this exact call several times and got the result. "
                    "Use the earlier result and continue with the task.")
        return None

    def after(self, call: ToolCall, result: ToolResult) -> None:
        self.calls += 1
        key = _key(call)
        if result.ok:
            self._successes[key] = self._successes.get(key, 0) + 1
            self._failures.pop(key, None)
        else:
            self._failures.setdefault(key, []).append(result.output.strip().splitlines()[0] if result.output.strip() else "failed")
