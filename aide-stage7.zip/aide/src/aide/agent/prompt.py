"""The agent's system prompt: a packaged default, copied to an editable file on first use."""
from __future__ import annotations

import datetime
import platform
from importlib import resources
from pathlib import Path

from ..config import APP_DIR, config_path

PROMPT_NAME = "system_prompt.md"


def prompt_file_path() -> Path:
    return config_path().parent / PROMPT_NAME


def default_template() -> str:
    return resources.files(__package__).joinpath("prompts", "system.md").read_text(encoding="utf-8")


def load_template(path: Path | None = None) -> tuple[str, Path]:
    """Return the user's prompt template, creating the editable file from the default if needed.
    If the file cannot be written or read, the packaged default is used."""
    path = path or prompt_file_path()
    try:
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(default_template(), encoding="utf-8")
        text = path.read_text(encoding="utf-8")
        if text.strip():
            return text, path
    except OSError:
        pass
    return default_template(), path


def build_system_prompt(template: str, *, workspace: Path | str, mode: str,
                        tool_instructions: str = "") -> str:
    values = {
        "workspace": str(workspace), "os": f"{platform.system()} {platform.release()}",
        "date": datetime.date.today().isoformat(), "mode": mode,
        "tool_instructions": tool_instructions,
    }
    text = template
    for key, value in values.items():
        text = text.replace("{{" + key + "}}", value)
    if "{{tool_instructions}}" not in template and tool_instructions:
        text += "\n\n" + tool_instructions      # a customised prompt without the placeholder
    return text.strip()
