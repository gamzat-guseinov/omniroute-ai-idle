"""Agent core: permissions, guarded tool execution (the loop itself arrives in Stage 5)."""
