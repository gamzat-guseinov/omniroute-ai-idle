"""Permission policy: decides which tool calls need the user's approval.

Modes
-----
ask        every write, delete and command is confirmed (writes come with a diff preview)
auto-edit  file edits are applied automatically; deletes and commands are confirmed
auto       everything inside the workspace runs without asking

In EVERY mode the user is asked for: dangerous commands (rm -r, sudo, curl | sh, ...),
commands that refer to paths outside the workspace, recursive deletes and overwriting moves.
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any

from ..safety.dangerous import assess_command
from ..tools.base import Tool
from ..tools.sandbox import Sandbox

COMMAND_TOOLS = {"run_command", "run_background"}


class Mode(str, enum.Enum):
    ASK = "ask"
    AUTO_EDIT = "auto-edit"
    AUTO = "auto"


def parse_mode(value: str | Mode) -> Mode:
    try:
        return value if isinstance(value, Mode) else Mode(str(value).strip().lower())
    except ValueError:
        raise ValueError(f"Unknown permission mode {value!r}. Use: ask, auto-edit or auto.") from None


@dataclass
class ApprovalRequest:
    tool: str
    kind: str
    title: str
    detail: str = ""                      # the command, or a diff / description of the change
    reasons: tuple[str, ...] = ()         # warnings to show (dangerous, outside the workspace, ...)
    dangerous: bool = False               # show in red; never offer "always allow"
    always_confirm: bool = False          # asked even in auto mode
    can_remember: bool = False            # "allow for this session" is offered
    programs: tuple[str, ...] = ()        # what "allow for this session" would cover
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class Decision:
    allowed: bool
    remember: bool = False                # allow these programs for the rest of the session
    message: str = ""                     # optional note from the user, passed on to the model


class PermissionPolicy:
    def __init__(self, mode: str | Mode, sandbox: Sandbox) -> None:
        self.mode = parse_mode(mode)
        self.sandbox = sandbox
        self._allowed_programs: set[str] = set()

    def _cwd(self, args: dict[str, Any]):
        try:
            return self.sandbox.resolve(args["cwd"]) if args.get("cwd") else self.sandbox.root
        except Exception:
            return self.sandbox.root      # the tool itself will report the bad cwd

    @staticmethod
    def _title(tool: Tool, args: dict[str, Any]) -> str:
        n = tool.name
        if n == "run_command":
            return "Run command"
        if n == "run_background":
            return "Start background process"
        if n == "write_file":
            return f"Write {args.get('path')}"
        if n == "edit_file":
            return f"Edit {args.get('path')}"
        if n == "apply_patch":
            return f"Patch {args.get('path')}"
        if n == "delete_file":
            return f"Delete {args.get('path')}" + (" (recursively)" if args.get("recursive") else "")
        if n == "move_file":
            return f"Move {args.get('source')} -> {args.get('destination')}"
        return f"Run tool {n}"

    def check(self, tool: Tool, args: dict[str, Any]) -> ApprovalRequest | None:
        """None if the call may run right away, otherwise what to ask the user."""
        if tool.kind == "read":
            return None
        reasons: list[str] = []
        dangerous = always = False
        programs: list[str] = []
        detail = ""

        if tool.name in COMMAND_TOOLS:
            cwd = self._cwd(args)
            a = assess_command(args["command"], self.sandbox.root, cwd)
            reasons += a.reasons
            if a.outside:
                reasons.append("refers to paths outside the workspace: " + ", ".join(a.outside[:5]))
            dangerous, always, programs = a.dangerous, a.needs_confirmation, a.programs
            detail = args["command"] + (f"\n(in {args['cwd']})" if args.get("cwd") else "")
        elif tool.name == "delete_file" and args.get("recursive"):
            reasons.append("deletes an entire directory tree")
            always = True
        elif tool.name == "move_file" and args.get("overwrite"):
            reasons.append("replaces an existing file")
            always = True

        if always:
            ask = True
        elif tool.kind == "write":
            ask = self.mode is Mode.ASK
        elif tool.kind == "destructive":
            ask = self.mode in (Mode.ASK, Mode.AUTO_EDIT)
        elif tool.kind == "exec":
            ask = self.mode is not Mode.AUTO and not (
                programs and all(p in self._allowed_programs for p in programs))
        else:
            ask = True                    # unknown kind: be safe
        if not ask:
            return None
        return ApprovalRequest(
            tool=tool.name, kind=tool.kind, title=self._title(tool, args), detail=detail,
            reasons=tuple(reasons), dangerous=dangerous, always_confirm=always,
            can_remember=tool.kind == "exec" and not always and bool(programs),
            programs=tuple(dict.fromkeys(programs)), args=dict(args))

    def remember(self, request: ApprovalRequest) -> None:
        if request.can_remember:
            self._allowed_programs.update(request.programs)

    @property
    def allowed_programs(self) -> frozenset[str]:
        return frozenset(self._allowed_programs)
