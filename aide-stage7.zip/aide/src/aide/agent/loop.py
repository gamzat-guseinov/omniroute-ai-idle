"""The agent loop: model call -> tool calls -> results -> model call ... until the task is done."""
from __future__ import annotations

import re
from contextlib import aclosing
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable

from ..client.errors import BadRequestError, ContextOverflowError, OmniRouteError
from ..client.events import (Done, ReasoningDelta, RetryEvent, TextDelta, ToolCallDelta, Usage)
from ..formats import (NativeCallBuilder, ParsedTurn, StreamFilter, describe_tools,
                       format_tool_responses, parse_response)
from ..formats.model import ToolCall
from ..tools.base import ToolResult
from .context import ContextManager
from .conversation import Conversation, native_tool_call
from .events import (AgentEvent, AssistantMessage, Failed, Notice, TextChunk, Thinking, ToolEnd,
                     ToolStart, TurnEnd, UsageUpdate)
from .executor import ToolExecutor
from .loopguard import LoopGuard

SUMMARY_SYSTEM = ("You write concise working notes so an engineer can continue a task after older "
                  "messages are dropped. Be factual; keep file names, decisions, commands and results.")
SUMMARY_REQUEST = ("Summarize in at most 250 words: the user's goals, what was done (files created or "
                   "changed), command results, decisions, and what is still open.\n\n")
MAX_PARSE_RETRIES = 2
MAX_OVERFLOW_RETRIES = 2


@dataclass
class _ModelResult:
    parsed: ParsedTurn
    raw_text: str
    finish: str | None


class AgentLoop:
    def __init__(self, client: Any, executor: ToolExecutor, conv: Conversation, *,
                 tool_format: str = "native", max_tool_calls: int = 25,
                 context_tokens: int = 64_000, max_tokens: int = 4096,
                 build_prompt: Callable[[str], str] | None = None) -> None:
        self.client, self.executor, self.conv = client, executor, conv
        self.tool_format = tool_format
        self.guard = LoopGuard(max_tool_calls)
        self.ctx = ContextManager(context_tokens, reserve_output=max_tokens)
        self.build_prompt = build_prompt
        self.known = set(executor.registry.names())

    @property
    def native(self) -> bool:
        return self.tool_format == "native"

    # ------------------------------------------------------------------ public
    async def run(self, user_text: str) -> AsyncIterator[AgentEvent]:
        """Handle one user message. Yields events; see agent/events.py."""
        self.conv.add_user(user_text)
        self.guard.reset()
        try:
            async for event in self._run():
                yield event
        finally:
            self.conv.repair()          # valid history even if cancelled mid-way

    def set_tool_format(self, fmt: str) -> None:
        self.tool_format = fmt
        if self.build_prompt:
            self.conv.system_prompt = self.build_prompt(fmt)

    # ------------------------------------------------------------------ main loop
    async def _run(self) -> AsyncIterator[AgentEvent]:
        overflow = parse_failures = 0
        while True:
            notice = await self.ctx.prepare(self.conv, self._summarize, aggressive=overflow)
            if notice:
                yield Notice(notice)

            result: _ModelResult | None = None
            try:
                async for item in self._call_model():
                    if isinstance(item, _ModelResult):
                        result = item
                    else:
                        yield item
            except ContextOverflowError:
                overflow += 1
                if overflow > MAX_OVERFLOW_RETRIES:
                    yield Failed("The conversation does not fit into the model's context window, even "
                                 "after trimming. Use /clear to start fresh.")
                    yield TurnEnd("error")
                    return
                yield Notice("The model said the conversation is too long; trimming more...", "warning")
                continue
            except BadRequestError as exc:
                if self.native and exc.status in (400, 422) and re.search(
                        r"tool|function", f"{exc.message} {exc.detail}", re.I):
                    self.set_tool_format("xml")
                    yield Notice("The server rejected native tool calling; switching to XML tool calls "
                                 "described in the prompt.", "warning")
                    continue
                yield Failed(exc.user_message())
                yield TurnEnd("error")
                return
            except OmniRouteError as exc:
                yield Failed(exc.user_message())
                yield TurnEnd("error")
                return
            assert result is not None
            parsed = result.parsed

            self._record_assistant(parsed, result.raw_text)
            yield AssistantMessage(parsed.text, result.finish)

            if not parsed.calls and not parsed.problems:
                if result.finish == "length":
                    yield Notice("The reply was cut off by the max_tokens limit.", "warning")
                yield TurnEnd("done")
                return
            if not parsed.calls:                      # looked like a call, but unreadable
                parse_failures += 1
                if parse_failures > MAX_PARSE_RETRIES:
                    yield Failed("The model keeps sending tool calls that cannot be read. Try "
                                 "another tool_format (xml, dsml or json) or another model.")
                    yield TurnEnd("error")
                    return
                self.conv.add_text_results(
                    "Your last message contained a tool call that could not be understood: "
                    + "; ".join(parsed.problems) + ".\nRewrite the call using exactly the format "
                    "from the instructions, then wait for the result.")
                yield Notice("The model sent an unreadable tool call; asking it to retry.", "warning")
                continue

            outcomes: list[tuple[ToolCall, ToolResult]] = []
            for call in parsed.calls:
                if call.error:
                    outcome = ToolResult(False, call.error)
                    yield ToolStart(call)
                elif self.guard.exhausted:
                    outcome = ToolResult(False, "Skipped: the limit of tool calls for this task was reached.")
                    yield ToolStart(call)
                else:
                    veto = self.guard.before(call)
                    yield ToolStart(call)
                    if veto:
                        outcome = ToolResult(False, veto)
                    else:
                        outcome = await self.executor.run(call.name, call.arguments)
                        self.guard.after(call, outcome)
                outcomes.append((call, outcome))
                yield ToolEnd(call, outcome)
            self._record_results(outcomes, parsed)

            if self.guard.aborted:
                yield Notice("Stopped: the agent kept repeating the same failing call.", "warning")
                yield TurnEnd("loop")
                return
            if self.guard.exhausted:
                yield Notice(f"Stopped after {self.guard.max_calls} tool calls. Say \"continue\" to "
                             f"let the agent go on.", "warning")
                yield TurnEnd("limit")
                return
            overflow = 0

    # ------------------------------------------------------------------ one model call
    async def _call_model(self) -> AsyncIterator[Any]:
        tools = self.executor.registry.schemas() if self.native else None
        stream_filter = StreamFilter(self.known)
        builder = NativeCallBuilder()
        finish: str | None = None
        messages = self.conv.api_messages()
        async with aclosing(self.client.stream_chat(messages, tools=tools)) as stream:
            async for ev in stream:
                if isinstance(ev, TextDelta):
                    visible = stream_filter.feed(ev.text)
                    if visible:
                        yield TextChunk(visible)
                elif isinstance(ev, ReasoningDelta):
                    yield Thinking()
                elif isinstance(ev, ToolCallDelta):
                    builder.feed(ev)
                elif isinstance(ev, Usage):
                    self.ctx.calibrate(self.conv, ev.prompt_tokens)
                    yield UsageUpdate(ev)
                elif isinstance(ev, RetryEvent):
                    yield Notice(f"{ev.error.message} Retrying in {ev.delay:.0f}s "
                                 f"({ev.attempt}/{ev.max_retries})...", "warning")
                elif isinstance(ev, Done):
                    finish = ev.finish_reason
        tail = stream_filter.finish()
        if tail:
            yield TextChunk(tail)
        raw = stream_filter.text
        parsed = parse_response(raw, builder.build(), self.known, truncated=finish == "length")
        yield _ModelResult(parsed, raw, finish)

    # ------------------------------------------------------------------ history
    def _record_assistant(self, parsed: ParsedTurn, raw_text: str) -> None:
        if parsed.format == "native":
            self.conv.add_assistant(
                parsed.text, [native_tool_call(c.id, c.name, c.arguments) for c in parsed.calls])
        else:   # text formats: keep the model's own markup so it recognises its call later
            self.conv.add_assistant(raw_text if parsed.calls or parsed.problems else parsed.text)

    def _record_results(self, outcomes: list[tuple[ToolCall, ToolResult]], parsed: ParsedTurn) -> None:
        def body(res: ToolResult) -> str:
            return res.output if res.ok else f"ERROR: {res.output}"
        if parsed.format == "native":
            for call, res in outcomes:
                self.conv.add_tool_result(call.id, body(res))
            return
        text = format_tool_responses([(c.id, c.name, body(r)) for c, r in outcomes], self.tool_format)
        if parsed.problems:
            text += "\nNote: part of your message could not be understood: " + "; ".join(parsed.problems)
        self.conv.add_text_results(text)

    # ------------------------------------------------------------------ summaries
    async def _summarize(self, prompt: str) -> str:
        messages = [{"role": "system", "content": SUMMARY_SYSTEM},
                    {"role": "user", "content": SUMMARY_REQUEST + prompt}]
        parts: list[str] = []
        async with aclosing(self.client.stream_chat(messages, tools=None, max_tokens=700)) as stream:
            async for ev in stream:
                if isinstance(ev, TextDelta):
                    parts.append(ev.text)
        return "".join(parts)


def tool_instructions(registry, fmt: str) -> str:
    """Text that describes the tools to models that do not use native function calling."""
    return describe_tools(registry.schemas(), fmt)
