"""Context budget: keep the conversation inside the model's window without ever crashing.

Strategy, cheapest first:
  1. shorten old tool output and old file contents inside tool calls,
  2. replace the oldest turns by a summary (written by the model, or by a local fallback),
  3. as a last resort, do the same inside the current turn.
Token counts are estimates, calibrated against the usage numbers the server reports.
"""
from __future__ import annotations

import json
from typing import Awaitable, Callable

from .conversation import Conversation, Msg

Summarizer = Callable[[str], Awaitable[str]]

CHARS_PER_TOKEN = 3.6
MESSAGE_OVERHEAD = 6


def estimate_text_tokens(text: str) -> int:
    return int(len(text) / CHARS_PER_TOKEN) + 1


def estimate_message_tokens(m: Msg) -> int:
    n = estimate_text_tokens(m.content) + MESSAGE_OVERHEAD
    for tc in m.tool_calls or []:
        n += estimate_text_tokens(tc["function"]["name"] + tc["function"]["arguments"]) + 8
    return n


def _shrink_text(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return f"{text[:limit]}\n[... {len(text) - limit} characters omitted to save context ...]"


def _shrink_args(arguments: str, limit: int = 600) -> str:
    try:
        data = json.loads(arguments)
    except ValueError:
        return _shrink_text(arguments, limit)
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(v, str) and len(v) > limit:
                data[k] = f"[{len(v)} characters omitted to save context]"
    return json.dumps(data, ensure_ascii=False)


def shrink_message(m: Msg, limit: int = 400) -> bool:
    changed = False
    if m.kind == "result" and len(m.content) > limit + 100:
        m.content = _shrink_text(m.content, limit)
        changed = True
    for tc in m.tool_calls or []:
        args = tc["function"]["arguments"]
        if len(args) > 700:
            tc["function"]["arguments"] = _shrink_args(args)
            changed = True
    return changed


def _render(messages: list[Msg], per_message: int = 700, total: int = 14_000) -> str:
    lines = []
    for m in messages:
        label = {"user": "USER" if m.kind == "user" else "TOOL RESULT", "assistant": "ASSISTANT",
                 "tool": "TOOL RESULT"}.get(m.role, m.role)
        body = m.content
        for tc in m.tool_calls or []:
            body += f"\n[called {tc['function']['name']} {tc['function']['arguments'][:200]}]"
        lines.append(f"{label}: {_shrink_text(body.strip(), per_message)}")
    text = "\n".join(lines)
    return text if len(text) <= total else text[: total // 2] + "\n[...]\n" + text[-total // 2:]


def heuristic_summary(previous: str, dropped: list[Msg]) -> str:
    """Summary without calling the model: requests, actions and the last words."""
    requests = [m.content.strip().splitlines()[0][:160] for m in dropped if m.kind == "user" and m.content.strip()]
    actions: list[str] = []
    for m in dropped:
        for tc in m.tool_calls or []:
            try:
                args = json.loads(tc["function"]["arguments"])
            except ValueError:
                args = {}
            target = args.get("path") or args.get("command") or args.get("pattern") or ""
            actions.append(f"{tc['function']['name']} {str(target)[:60]}".strip())
    last = next((m.content.strip() for m in reversed(dropped) if m.role == "assistant" and m.content.strip()), "")
    parts = [previous] if previous else []
    if requests:
        parts.append("The user asked: " + " | ".join(requests[-5:]))
    if actions:
        parts.append("Actions taken: " + "; ".join(actions[-25:]))
    if last:
        parts.append("Last assistant note: " + _shrink_text(last, 400))
    return "\n".join(parts)


class ContextManager:
    def __init__(self, budget_tokens: int, reserve_output: int = 4096) -> None:
        self.budget = budget_tokens
        self.reserve = reserve_output
        self.scale = 1.0                        # real tokens / estimated tokens

    # ------------------------------------------------------------- sizes
    def limit(self, factor: float = 1.0) -> int:
        return int(max(self.budget * factor - self.reserve, self.budget * 0.2) * 0.92)

    def estimate(self, conv: Conversation) -> int:
        n = estimate_text_tokens(conv.system_text()) + MESSAGE_OVERHEAD
        n += sum(estimate_message_tokens(m) for m in conv.messages)
        return int(n * self.scale)

    def calibrate(self, conv: Conversation, real_prompt_tokens: int) -> None:
        """Compare the estimate with what the server counted (call with the history that was sent)."""
        raw = self.estimate(conv) / self.scale
        if raw > 200 and real_prompt_tokens > 0:
            ratio = min(max(real_prompt_tokens / raw, 0.5), 2.5)
            self.scale = 0.6 * self.scale + 0.4 * ratio

    # ------------------------------------------------------------- compaction
    async def prepare(self, conv: Conversation, summarize: Summarizer | None = None,
                      *, aggressive: int = 0) -> str | None:
        """Make the history fit. Returns a notice for the user if something was trimmed.
        `aggressive` > 0 is used after the server rejected the request as too long."""
        factor = 1.0 / (1 + aggressive)
        limit = self.limit(factor)
        if self.estimate(conv) <= limit:
            return None
        notes: list[str] = []

        keep = 2 if aggressive == 0 else 1
        shrunk = False
        turns = conv.turns()
        for turn in turns[:-keep] if len(turns) > keep else []:
            for m in turn:
                shrunk |= shrink_message(m)
        if shrunk:
            notes.append("shortened old tool output")
        if self.estimate(conv) <= limit:
            return self._notice(notes)

        turns = conv.turns()
        if len(turns) > keep:
            dropped = [m for t in turns[:-keep] for m in t]
            await self._summarize_into(conv, dropped, summarize)
            conv.set_turns(turns[-keep:])
            notes.append(f"summarized {len(dropped)} earlier messages")
        if self.estimate(conv) <= limit:
            return self._notice(notes)

        # still too big: work inside the current turn
        msgs = conv.messages
        for m in msgs[:-6]:
            shrink_message(m, limit=300)
        if self.estimate(conv) > limit and len(msgs) > 8:
            cut = len(msgs) - 6
            while cut > 1 and (msgs[cut].role == "tool" or msgs[cut].kind == "result"):
                cut -= 1                          # never separate a tool call from its results
            if cut > 1:
                middle = msgs[1:cut]
                await self._summarize_into(conv, middle, summarize)
                conv.messages = [msgs[0], *msgs[cut:]]
                notes.append(f"summarized {len(middle)} messages of the current task")
        return self._notice(notes)

    @staticmethod
    def _notice(notes: list[str]) -> str | None:
        return ("Context was getting full: " + ", ".join(notes) + ".") if notes else None

    async def _summarize_into(self, conv: Conversation, dropped: list[Msg],
                              summarize: Summarizer | None) -> None:
        text = ""
        if summarize is not None:
            prompt = ((f"Previous summary:\n{conv.summary}\n\n" if conv.summary else "")
                      + "Messages to fold into the summary:\n" + _render(dropped))
            try:
                text = (await summarize(prompt)).strip()
            except Exception:
                text = ""
        conv.summary = text or heuristic_summary(conv.summary, dropped)
