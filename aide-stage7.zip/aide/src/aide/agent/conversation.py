"""Conversation history in an internal form that is converted to API messages on demand."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class Msg:
    role: str                                   # user | assistant | tool
    content: str = ""
    tool_calls: list[dict[str, Any]] | None = None   # native assistant tool calls (OpenAI shape)
    tool_call_id: str | None = None
    kind: str = ""                              # "user" (typed by the person) | "result" | ""

    def to_api(self) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        if self.tool_call_id is not None:
            msg["tool_call_id"] = self.tool_call_id
        return msg


def native_tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    return {"id": call_id, "type": "function",
            "function": {"name": name, "arguments": json.dumps(arguments, ensure_ascii=False)}}


class Conversation:
    def __init__(self, system_prompt: str) -> None:
        self.system_prompt = system_prompt
        self.summary = ""                       # digest of history that was trimmed away
        self.messages: list[Msg] = []

    # ------------------------------------------------------------- building
    def add_user(self, text: str) -> None:
        self.messages.append(Msg("user", text, kind="user"))

    def add_assistant(self, text: str, tool_calls: list[dict[str, Any]] | None = None) -> None:
        self.messages.append(Msg("assistant", text, tool_calls=tool_calls))

    def add_tool_result(self, call_id: str, content: str) -> None:
        self.messages.append(Msg("tool", content, tool_call_id=call_id, kind="result"))

    def add_text_results(self, content: str) -> None:
        """Tool results for text-mode conversations travel in a user message."""
        self.messages.append(Msg("user", content, kind="result"))

    def add_note(self, text: str) -> None:
        """A system-style note for the model (e.g. 'the user undid your changes')."""
        self.messages.append(Msg("user", text))

    def to_dict(self) -> dict[str, Any]:
        return {"summary": self.summary, "messages": [asdict(m) for m in self.messages]}

    def load_dict(self, data: dict[str, Any]) -> None:
        self.summary = str(data.get("summary", ""))
        self.messages = [Msg(role=m["role"], content=m.get("content", ""), tool_calls=m.get("tool_calls"),
                             tool_call_id=m.get("tool_call_id"), kind=m.get("kind", ""))
                         for m in data.get("messages", [])]

    def clear(self) -> None:
        self.messages.clear()
        self.summary = ""

    # ------------------------------------------------------------- views
    def system_text(self) -> str:
        if not self.summary:
            return self.system_prompt
        return (f"{self.system_prompt}\n\n## Earlier conversation (summary)\n"
                f"Older messages were trimmed to save space. What happened so far:\n{self.summary}")

    def api_messages(self) -> list[dict[str, Any]]:
        return [{"role": "system", "content": self.system_text()}] + [m.to_api() for m in self.messages]

    def turns(self) -> list[list[Msg]]:
        """History split into turns; each starts with a message the person typed."""
        turns: list[list[Msg]] = []
        for m in self.messages:
            if m.kind == "user" or not turns:
                turns.append([])
            turns[-1].append(m)
        return turns

    def set_turns(self, turns: list[list[Msg]]) -> None:
        self.messages = [m for t in turns for m in t]

    # ------------------------------------------------------------- repair
    def repair(self) -> None:
        """After an interruption, make sure every native tool call has a result, so the
        history is valid for the next request."""
        for idx in range(len(self.messages) - 1, -1, -1):
            m = self.messages[idx]
            if m.role == "assistant":
                if m.tool_calls:
                    answered = {t.tool_call_id for t in self.messages[idx + 1:] if t.role == "tool"}
                    for tc in m.tool_calls:
                        if tc["id"] not in answered:
                            self.add_tool_result(tc["id"], "Not run: the user interrupted the agent.")
                return
