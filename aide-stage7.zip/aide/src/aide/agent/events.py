"""Events the agent loop emits; the UI renders them (it never touches the loop's internals)."""
from __future__ import annotations

from dataclasses import dataclass

from ..client.events import Usage
from ..formats.model import ToolCall
from ..tools.base import ToolResult


@dataclass(frozen=True)
class TextChunk:
    """Assistant text that is safe to display now (tool-call markup is filtered out)."""
    text: str


@dataclass(frozen=True)
class Thinking:
    """The model is sending reasoning tokens (not shown)."""


@dataclass(frozen=True)
class AssistantMessage:
    """The complete assistant message of one model call (final, markup removed)."""
    text: str
    finish_reason: str | None


@dataclass(frozen=True)
class ToolStart:
    call: ToolCall


@dataclass(frozen=True)
class ToolEnd:
    call: ToolCall
    result: ToolResult


@dataclass(frozen=True)
class Notice:
    text: str
    level: str = "info"          # info | warning


@dataclass(frozen=True)
class UsageUpdate:
    usage: Usage


@dataclass(frozen=True)
class Failed:
    message: str


@dataclass(frozen=True)
class TurnEnd:
    reason: str                  # done | limit | loop | error


AgentEvent = (TextChunk | Thinking | AssistantMessage | ToolStart | ToolEnd | Notice
              | UsageUpdate | Failed | TurnEnd)
