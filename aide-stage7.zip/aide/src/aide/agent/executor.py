"""ToolExecutor: the one place where a tool call goes through permission checks and runs."""
from __future__ import annotations

import asyncio
import dataclasses
import inspect
import time
from typing import Any, Awaitable, Callable, Union

from ..debuglog import DebugLog
from ..safety.audit import AuditLog
from ..tools.base import ToolResult
from ..tools.errors import ToolError
from ..tools.registry import ToolRegistry, validate_args
from .permissions import ApprovalRequest, Decision, PermissionPolicy

Approver = Callable[[ApprovalRequest], Union[Decision, Awaitable[Decision]]]


class ToolExecutor:
    """Permission checks, execution, audit trail and secret scrubbing for every tool call."""

    def __init__(self, registry: ToolRegistry, policy: PermissionPolicy,
                 approver: Approver | None = None, *, audit: AuditLog | None = None,
                 debug: DebugLog | None = None, redact: Callable[[str], str] | None = None) -> None:
        self.registry, self.policy, self.approver = registry, policy, approver
        self.audit = audit or AuditLog(None)
        self.debug = debug or DebugLog(None)
        self._redact = redact or self.debug.redact

    def cancel(self) -> None:
        """Stop the running command (if any). Safe to call from any thread."""
        self.registry.ctx.cancel_event.set()

    async def _ask(self, request: ApprovalRequest) -> Decision:
        if self.approver is None:
            return Decision(False, message="No way to ask the user for approval is available.")
        if inspect.iscoroutinefunction(self.approver):
            return await self.approver(request)
        result = await asyncio.to_thread(self.approver, request)   # e.g. blocking input()
        return await result if inspect.isawaitable(result) else result

    async def run(self, name: str, args: Any) -> ToolResult:
        """Validate, ask for approval if the policy says so, then execute. Never raises
        (except CancelledError): failures and denials come back as ToolResult(ok=False)."""
        started = time.monotonic()
        shown_args = args if isinstance(args, dict) else {}
        decision_label = "auto"
        result: ToolResult
        self.registry.ctx.cancel_event.clear()
        tool = self.registry.get(name)
        try:
            if tool is None:
                decision_label = "unknown tool"
                result = self.registry.execute(name, args)
            else:
                result, decision_label = await self._run_known(tool, name, args)
        except asyncio.CancelledError:
            self.audit.tool(name, shown_args, decision="cancelled", ok=False,
                            duration=time.monotonic() - started)
            raise
        result.output = self._redact(result.output)          # never pass our own secrets on
        self.audit.tool(name, shown_args, decision=decision_label, ok=result.ok,
                        duration=time.monotonic() - started, exit_code=result.meta.get("exit_code"),
                        detail="" if result.ok else result.output.strip().splitlines()[0] if result.output.strip() else "")
        self.debug.log("tool", {"name": name, "args": shown_args, "decision": decision_label,
                                "ok": result.ok, "output": result.output[:2000]})
        return result

    async def _run_known(self, tool, name: str, args: Any) -> tuple[ToolResult, str]:
        try:
            clean = validate_args(tool.parameters, args)
            request = self.policy.check(tool, clean)
            if request is not None and tool.preview is not None:
                # Compute the diff first: if the edit cannot be applied, say so instead of
                # asking the user to approve something that is going to fail anyway.
                request = dataclasses.replace(request, detail=tool.preview(self.registry.ctx, clean))
        except ToolError as exc:
            return ToolResult(False, str(exc)), "rejected before asking"

        label = "auto"
        if request is not None:
            decision = await self._ask(request)
            if not decision.allowed:
                note = f" The user said: {decision.message}" if decision.message else ""
                return ToolResult(False, "The user denied this action, so nothing was done." + note +
                                  " Do not repeat it; choose a different approach or ask the user.",
                                  meta={"denied": True}), "denied"
            label = "approved (always)" if decision.remember else "approved"
            if decision.remember:
                self.policy.remember(request)
        result = await asyncio.to_thread(self.registry.execute, name, clean)
        if result.output.startswith("Internal error in "):
            self.debug.log("tool_internal_error", {"name": name, "output": result.output})
        return result, label
