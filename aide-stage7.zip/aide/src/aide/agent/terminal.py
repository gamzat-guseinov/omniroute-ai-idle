"""Approver that asks on the terminal (used by `python -m aide.tools` and scripts)."""
from __future__ import annotations

from typing import Callable

from .permissions import ApprovalRequest, Decision


def terminal_approver(request: ApprovalRequest, *, input_fn: Callable[[str], str] = input,
                      out: Callable[[str], None] = print) -> Decision:
    banner = "!! DANGEROUS !!" if request.dangerous else "Approval needed"
    out(f"\n=== {banner}: {request.title} ===")
    for reason in request.reasons:
        out(f"  ! {reason}")
    if request.detail:
        lines = request.detail.splitlines()
        out("\n".join(lines[:40]))
        if len(lines) > 40:
            out(f"... ({len(lines) - 40} more lines)")
    options = "[y]es / [n]o" + (" / [a]lways allow these programs this session" if request.can_remember else "")
    for _ in range(3):
        try:
            answer = input_fn(f"Allow? {options}: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return Decision(False, message="No answer was given.")
        if answer in ("y", "yes"):
            return Decision(True)
        if answer in ("a", "always") and request.can_remember:
            return Decision(True, remember=True)
        if answer in ("n", "no", ""):
            return Decision(False)
    return Decision(False)
