"""XML-style tool calls: Hermes/Qwen <tool_call>, <function_calls><invoke>, and friends.

Supported shapes (all may appear several times per message, closed or not):

  <tool_call>{"name": "x", "arguments": {...}}</tool_call>                  (Hermes, Qwen)
  <tool_call><function=x><parameter=k>v</parameter></function></tool_call>  (Qwen coder)
  <function_calls><invoke name="x"><parameter name="k">v</parameter></invoke></function_calls>
  <read_file><path>a.py</path></read_file>                                  (tag per tool)

Values are taken verbatim (no XML unescaping): file contents full of `<` and `&` must survive.
"""
from __future__ import annotations

import json
import re
from typing import Any

from .json_fmt import calls_from_obj, iter_json_values, loads_loose
from .model import ToolCall

_WRAPPER_RE = re.compile(r"<(tool_call|function_calls|tool_calls|tool_use)\b[^>]*>", re.I)
_NAME_VALUE = r"""(?:"([^"]*)"|'([^']*)'|([^\s>/"']+))"""
_INVOKE_RE = re.compile(rf"<invoke\s+name\s*=\s*{_NAME_VALUE}[^>]*>", re.I)
_FUNCTION_RE = re.compile(rf"<function\s*=\s*{_NAME_VALUE}\s*>|<function\s+name\s*=\s*{_NAME_VALUE}[^>]*>", re.I)
_PARAM_RE = re.compile(
    rf"<parameter(?:\s*=\s*([^\s>]+)|\s+name\s*=\s*{_NAME_VALUE})([^>]*)>", re.I)
_STRING_ATTR_RE = re.compile(r"""string\s*=\s*["']?(true|false)["']?""", re.I)
_NAME_TAG_RE = re.compile(r"<(?:tool_)?name>\s*(.*?)\s*</(?:tool_)?name>", re.S | re.I)
_ARGS_TAG_RE = re.compile(r"<(?:arguments|parameters|args)>\s*(.*?)\s*</(?:arguments|parameters|args)>", re.S | re.I)
_LOOKS_LIKE_CALL_RE = re.compile(r"[{]|<invoke|<function|\bname\s*=|<name>|<tool_name>", re.I)


def _pick(m: re.Match[str], first: int) -> str:
    """First non-None group among the three quoting variants starting at group `first`."""
    return next((g for g in m.groups()[first - 1:first + 2] if g is not None), "")


def clean_value(value: str) -> str:
    """Single-line values are trimmed; multi-line values lose the padding newline pair."""
    if "\n" not in value.strip("\n"):
        return value.strip()
    if value.startswith("\n") and value.endswith("\n"):
        return value[1:-1]
    return value


def _typed(value: str, string_attr: str | None) -> Any:
    value = clean_value(value)
    if string_attr and string_attr.lower() == "false":
        try:
            return json.loads(value)
        except ValueError:
            try:
                return loads_loose(value)[0]
            except ValueError:
                return value
    return value


def parse_params(body: str) -> dict[str, Any]:
    params: dict[str, Any] = {}
    matches = list(_PARAM_RE.finditer(body))
    for i, m in enumerate(matches):
        name = m.group(1) or _pick(m, 2)
        start = m.end()
        close = body.find("</parameter>", start)
        nxt = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        end = close if close != -1 and close <= nxt else nxt
        attr = _STRING_ATTR_RE.search(m.group(5) or "")
        params[name] = _typed(body[start:end], attr.group(1) if attr else None)
    return params


def _parse_block_inner(inner: str, closed: bool) -> list[ToolCall]:
    calls: list[ToolCall] = []
    for regex, closer in ((_INVOKE_RE, "</invoke>"), (_FUNCTION_RE, "</function>")):
        matches = list(regex.finditer(inner))
        for i, m in enumerate(matches):
            name = next((g for g in m.groups() if g), "")
            start = m.end()
            close = inner.find(closer, start)
            nxt = matches[i + 1].start() if i + 1 < len(matches) else len(inner)
            end = close if close != -1 and close <= nxt else nxt
            calls.append(ToolCall(name=name.strip(), arguments=parse_params(inner[start:end]),
                                  source="xml", complete=closed and close != -1 and close <= nxt))
        if calls:
            return calls
    # <name>x</name><arguments>{...}</arguments>
    n, a = _NAME_TAG_RE.search(inner), _ARGS_TAG_RE.search(inner)
    if n:
        from .json_fmt import arguments_to_dict
        args, clean, err = arguments_to_dict(a.group(1)) if a else ({}, True, "")
        return [ToolCall(n.group(1), args, source="xml", complete=closed and clean, error=err)]
    # JSON objects (Hermes): possibly several in one block
    for value, clean in iter_json_values(inner):
        for c in calls_from_obj(value, None, "xml"):
            c.complete = c.complete and clean and closed
            calls.append(c)
    return calls


def _tag_per_tool(text: str, known: set[str]) -> tuple[list[ToolCall], str]:
    calls: list[ToolCall] = []
    for name in sorted(known, key=len, reverse=True):
        pattern = re.compile(rf"<{re.escape(name)}>(.*?)(?:</{re.escape(name)}>|\Z)", re.S)
        def repl(m: re.Match[str], name: str = name) -> str:
            body = m.group(1)
            args: dict[str, Any] = {}
            for child in re.finditer(r"<([A-Za-z_][\w-]*)>(.*?)</\1>", body, re.S):
                args[child.group(1)] = clean_value(child.group(2))
            calls.append(ToolCall(name, args, source="xml",
                                  complete=m.group(0).endswith(f"</{name}>")))
            return ""
        text = pattern.sub(repl, text)
    return calls, text


def extract_xml_calls(text: str, known: set[str], *, dsml: bool = False
                      ) -> tuple[list[ToolCall], str, list[str]]:
    """Find XML/DSML tool calls. Returns (calls, text without them, problems)."""
    source = "dsml" if dsml else "xml"
    calls: list[ToolCall] = []
    problems: list[str] = []
    out: list[str] = []
    pos = 0
    lowered = text.lower()
    while True:
        m = _WRAPPER_RE.search(text, pos)
        if not m:
            break
        out.append(text[pos:m.start()])
        tag = m.group(1).lower()
        close = lowered.find(f"</{tag}>", m.end())
        closed = close != -1
        inner = text[m.end(): close if closed else len(text)]
        end = close + len(tag) + 3 if closed else len(text)
        found = _parse_block_inner(inner, closed)
        if found:
            calls += found
        elif _LOOKS_LIKE_CALL_RE.search(inner):
            problems.append(f"A <{tag}> block could not be understood")
        else:
            out.append(text[m.start():end])          # prose that merely mentions the tag
        pos = end
    out.append(text[pos:])
    rest = "".join(out)

    stray, rest = _parse_stray(rest)                 # <invoke> without a wrapper
    calls += stray
    if known:
        extra, rest = _tag_per_tool(rest, known)
        calls += extra
    for c in calls:
        c.source = source
    return calls, rest, problems


def _parse_stray(text: str) -> tuple[list[ToolCall], str]:
    m = _INVOKE_RE.search(text) or _FUNCTION_RE.search(text)
    if not m:
        return [], text
    region_end = len(text)
    last_close = max(text.rfind("</invoke>"), text.rfind("</function>"))
    if last_close != -1 and last_close > m.start():
        region_end = last_close + len("</invoke>")
    calls = _parse_block_inner(text[m.start():region_end], closed=last_close != -1)
    if not calls:
        return [], text
    return calls, text[:m.start()] + text[region_end:]
