"""Streaming filter: show text token by token without ever showing tool-call markup."""
from __future__ import annotations

import re
from typing import Iterable

_BASE_MARKERS = ["<tool_call", "<function", "<tool_use", "<invoke", "<dsml", "<|dsml", "<｜dsml"]


class StreamFilter:
    """Feed text deltas in; get back the part that is safe to display.

    As soon as something that could be the start of a tool call appears, display stops (a
    partial marker such as `<tool_c` is held back until it is clear what it is). The full
    text is kept so the real parser can look at it when the reply is complete.
    """

    def __init__(self, known_tools: Iterable[str] = ()) -> None:
        names = [re.escape(n) for n in known_tools]
        tag_per_tool = (r"|(?:%s)>" % "|".join(names)) if names else ""
        self._start = re.compile(
            r"<\s*(?:tool_calls?\b|function_calls\b|invoke\b|tool_use\b|function\s*=|"
            r"(?:[｜|]\s*)?DSML" + tag_per_tool + ")", re.I)
        self._markers = _BASE_MARKERS + [f"<{n.lower()}>" for n in known_tools]
        self._max = max(len(m) for m in self._markers)
        self._pending = ""
        self._in_call = False
        self._full: list[str] = []

    @property
    def text(self) -> str:
        return "".join(self._full)

    @property
    def saw_markup(self) -> bool:
        return self._in_call

    def feed(self, chunk: str) -> str:
        self._full.append(chunk)
        if self._in_call:
            return ""
        self._pending += chunk
        m = self._start.search(self._pending)
        if m:
            visible = self._pending[:m.start()]
            self._pending = ""
            self._in_call = True
            return visible
        hold = self._holdback()
        cut = len(self._pending) - hold
        visible, self._pending = self._pending[:cut], self._pending[cut:]
        return visible

    def finish(self) -> str:
        """Release anything still held back (it turned out not to be markup)."""
        if self._in_call:
            return ""
        visible, self._pending = self._pending, ""
        return visible

    def _holdback(self) -> int:
        idx = self._pending.rfind("<")
        if idx == -1 or len(self._pending) - idx >= self._max:
            return 0
        tail = self._pending[idx:].lower()
        return len(tail) if any(m.startswith(tail) for m in self._markers) else 0
