"""DSML (DeepSeek-style markup) support.

DSML tool calls look like XML whose tags carry a `｜DSML｜` marker:

    <｜DSML｜function_calls>
    <｜DSML｜invoke name="read_file">
    <｜DSML｜parameter name="path" string="true">src/app.py</｜DSML｜parameter>
    </｜DSML｜invoke>
    </｜DSML｜function_calls>

Variants seen in the wild use an ASCII bar (`<|DSML|...>`) or drop the leading bar. We
normalise all of them to plain XML tags and let the XML parser do the rest; the
`string="true|false"` attribute on parameters tells whether a value is raw text or JSON.
"""
from __future__ import annotations

import re

_DSML_TAG_RE = re.compile(r"<(/?)\s*(?:[｜|]\s*)?DSML\s*[｜|:]\s*", re.I)


def normalize_dsml(text: str) -> tuple[str, bool]:
    """Rewrite DSML tags as plain XML tags. Returns (text, dsml_was_present)."""
    if not _DSML_TAG_RE.search(text):
        return text, False
    return _DSML_TAG_RE.sub(r"<\1", text), True
