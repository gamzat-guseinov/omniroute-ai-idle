"""Describe tools to the model in text (for models without native function calling) and
format tool results for text-mode conversations."""
from __future__ import annotations

import json
from typing import Any

FORMATS = ("native", "json", "xml", "dsml")


def tool_signatures(schemas: list[dict[str, Any]]) -> str:
    blocks = []
    for s in schemas:
        fn = s["function"]
        props = fn["parameters"].get("properties", {})
        required = set(fn["parameters"].get("required", []))
        lines = [f"### {fn['name']}", fn["description"], "Arguments:"]
        for name, spec in props.items():
            req = "required" if name in required else "optional"
            lines.append(f"- {name} ({spec.get('type', 'any')}, {req}): {spec.get('description', '')}")
        if not props:
            lines.append("- (none)")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


_RULES = ("You may call several tools in one message. After the call(s), STOP and wait: the "
          "results arrive in the next message. Never invent results.")


def describe_tools(schemas: list[dict[str, Any]], fmt: str) -> str:
    """Instructions + tool list for `fmt`. Empty for native mode (schemas go in the API call)."""
    if fmt == "native":
        return ""
    if fmt not in FORMATS:
        raise ValueError(f"Unknown tool format {fmt!r}. Use one of: {', '.join(FORMATS)}.")
    sigs = tool_signatures(schemas)
    if fmt == "json":
        example = json.dumps({"name": "read_file", "arguments": {"path": "src/app.py"}}, indent=2)
        how = (f"To call a tool, reply with a fenced JSON block containing the tool name and its "
               f"arguments, for example:\n\n```json\n{example}\n```\n\n"
               f"Use a JSON array of such objects for several calls. {_RULES}")
    elif fmt == "xml":
        example = ('<tool_call>\n{"name": "read_file", "arguments": {"path": "src/app.py"}}\n</tool_call>')
        how = (f"To call a tool, write a <tool_call> block containing a JSON object with the tool "
               f"name and arguments, for example:\n\n{example}\n\n"
               f"Write one <tool_call> block per call. {_RULES}")
    else:  # dsml
        example = ('<｜DSML｜function_calls>\n'
                   '<｜DSML｜invoke name="read_file">\n'
                   '<｜DSML｜parameter name="path" string="true">src/app.py</｜DSML｜parameter>\n'
                   '<｜DSML｜parameter name="start_line" string="false">1</｜DSML｜parameter>\n'
                   '</｜DSML｜invoke>\n'
                   '</｜DSML｜function_calls>')
        how = (f"To call a tool, use this markup (string=\"true\" for text values, string=\"false\" "
               f"for numbers, booleans and JSON):\n\n{example}\n\n"
               f"Put several <｜DSML｜invoke> elements inside one function_calls block. {_RULES}")
    return f"## Tools\n\n{how}\n\nAvailable tools:\n\n{sigs}"


def format_tool_responses(results: list[tuple[str, str, str]], fmt: str) -> str:
    """Tool results as one user message for text-mode conversations.
    `results` is a list of (call_id, tool_name, content)."""
    parts = [f'<tool_response id="{cid}" name="{name}">\n{content}\n</tool_response>'
             for cid, name, content in results]
    return "\n".join(parts)
