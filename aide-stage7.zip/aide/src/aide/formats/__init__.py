"""Tool-call formats: JSON (native + text), XML and DSML, normalised to one representation."""
from .describe import FORMATS, describe_tools, format_tool_responses
from .model import ParsedTurn, ToolCall
from .native import NativeCallBuilder
from .parser import detect_format, parse_response
from .stream import StreamFilter

__all__ = ["FORMATS", "NativeCallBuilder", "ParsedTurn", "StreamFilter", "ToolCall",
           "describe_tools", "detect_format", "format_tool_responses", "parse_response"]
