"""parse_response: turn a model reply into text + normalised tool calls."""
from __future__ import annotations

import uuid

from .dsml_fmt import normalize_dsml
from .json_fmt import extract_json_calls
from .model import ParsedTurn, ToolCall
from .xml_fmt import extract_xml_calls

TRUNCATED = ("The tool call was cut off because the reply reached the output limit, so it was NOT "
             "run. Send smaller steps (for example, write a long file in several parts).")


def detect_format(text: str) -> str | None:
    """Which tool-call markup does this text contain? (dsml | xml | json | None)"""
    norm, dsml = normalize_dsml(text)
    if dsml:
        return "dsml"
    calls, _, problems = extract_xml_calls(norm, set())
    if calls or problems:
        return "xml"
    return None


def parse_response(text: str, native: list[ToolCall] | None = None,
                   known: set[str] | None = None, *, truncated: bool = False) -> ParsedTurn:
    """Extract tool calls from a reply, whatever format it uses.

    Native (API) calls win. Otherwise the text is searched for DSML, XML and JSON calls, in
    that order. `known` (tool names) lets JSON/tag-per-tool styles be recognised safely.
    With `truncated=True` (finish_reason == "length") calls whose end had to be guessed are
    rejected instead of run: a half-written file must never be saved as if it were complete.
    """
    known = known or set()
    calls: list[ToolCall] = list(native or [])
    problems: list[str] = []
    fmt: str | None = "native" if calls else None
    cleaned = text

    if not calls:
        norm, is_dsml = normalize_dsml(text)
        xml_calls, rest, xml_problems = extract_xml_calls(norm, known, dsml=is_dsml)
        if xml_calls or xml_problems:
            calls, cleaned, problems = xml_calls, rest, xml_problems
            fmt = "dsml" if is_dsml else "xml"
        else:
            json_calls, rest = extract_json_calls(text, known)
            if json_calls:
                calls, cleaned, fmt = json_calls, rest, "json"

    for call in calls:
        if not call.id:
            call.id = "call_" + uuid.uuid4().hex[:8]
        if truncated and not call.complete and not call.error:
            call.error = TRUNCATED
    return ParsedTurn(text=cleaned.strip(), calls=calls, format=fmt, problems=problems)
