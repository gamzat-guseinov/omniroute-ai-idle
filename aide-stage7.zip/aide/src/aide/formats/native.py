"""Assemble native (API-level) tool calls from streamed fragments."""
from __future__ import annotations

from ..client.events import ToolCallDelta
from .json_fmt import arguments_to_dict
from .model import ToolCall


class NativeCallBuilder:
    def __init__(self) -> None:
        self._entries: list[dict] = []
        self._by_index: dict[int, dict] = {}

    def feed(self, delta: ToolCallDelta) -> None:
        entry = self._by_index.get(delta.index)
        # Some gateways reuse index 0 for every call: a new id means a new call.
        if entry is not None and delta.id and entry["id"] and delta.id != entry["id"]:
            entry = None
        if entry is None:
            entry = {"id": "", "name": "", "args": []}
            self._entries.append(entry)
            self._by_index[delta.index] = entry
        if delta.id:
            entry["id"] = delta.id
        if delta.name:
            entry["name"] += delta.name if entry["name"] and delta.name != entry["name"] else (
                "" if entry["name"] else delta.name)
        if delta.arguments:
            entry["args"].append(delta.arguments)

    def build(self) -> list[ToolCall]:
        calls = []
        for e in self._entries:
            raw = "".join(e["args"])
            args, clean, err = arguments_to_dict(raw)
            if not e["name"]:
                err = err or "The tool call has no name."
            calls.append(ToolCall(name=e["name"], arguments=args, id=e["id"], source="native",
                                  complete=clean, error=err))
        return calls
