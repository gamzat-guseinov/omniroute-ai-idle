"""One internal representation for tool calls, whatever format the model used."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCall:
    name: str
    arguments: dict[str, Any]
    id: str = ""
    source: str = "native"        # native | json | xml | dsml
    complete: bool = True         # False if closing tags/braces were missing and had to be guessed
    error: str = ""               # why the call cannot run (unreadable arguments, cut off, ...)


@dataclass
class ParsedTurn:
    text: str                                         # assistant text with tool-call markup removed
    calls: list[ToolCall] = field(default_factory=list)
    format: str | None = None                         # native | json | xml | dsml | None
    problems: list[str] = field(default_factory=list)  # markup that looked like a call but was unreadable
