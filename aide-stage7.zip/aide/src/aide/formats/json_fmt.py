"""Tolerant JSON handling and JSON-style tool calls (native arguments, fenced JSON in text)."""
from __future__ import annotations

import ast
import json
import re
from typing import Any

from .model import ToolCall

_FENCE_RE = re.compile(r"^\s*```[A-Za-z0-9_+-]*[ \t]*\n?(.*?)\n?[ \t]*```\s*$", re.S)
_FENCED_BLOCK_RE = re.compile(r"```[A-Za-z0-9_+-]*[ \t]*\n(.*?)\n?[ \t]*```", re.S)
_NAME_KEYS = ("name", "tool", "tool_name", "function", "function_name", "action")
_ARG_KEYS = ("arguments", "args", "parameters", "input", "params", "action_input")


def strip_fences(text: str) -> str:
    m = _FENCE_RE.match(text)
    return m.group(1) if m else text


def repair_json(text: str) -> str:
    """Make almost-JSON parseable: drop trailing commas, close open strings/brackets."""
    out: list[str] = []
    stack: list[str] = []
    in_str = esc = False
    for ch in text:
        if in_str:
            out.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            out.append(ch)
        elif ch in "{[":
            stack.append("}" if ch == "{" else "]")
            out.append(ch)
        elif ch in "}]":
            while stack and stack[-1] != ch:      # mismatched: close what is open first
                out.append(stack.pop())
            if not stack:
                continue                          # stray closer
            stack.pop()
            j = len(out) - 1
            while j >= 0 and out[j].isspace():
                j -= 1
            if j >= 0 and out[j] == ",":          # trailing comma
                del out[j]
            out.append(ch)
        else:
            out.append(ch)
    if in_str:
        if esc:
            out.pop()                             # dangling backslash
        out.append('"')
    s = "".join(out).rstrip()
    while s.endswith(","):
        s = s[:-1].rstrip()
    if s.endswith(":"):
        s += " null"
    return s + "".join(reversed(stack))


def loads_loose(text: str) -> tuple[Any, bool]:
    """Parse JSON that may be fenced, padded with prose, single-quoted or truncated.
    Returns (value, was_clean); was_clean is False if repairs were needed."""
    s = strip_fences(text.strip())
    try:
        return json.loads(s), True
    except ValueError:
        pass
    starts = [i for i in (s.find("{"), s.find("[")) if i != -1]
    if not starts:
        raise ValueError("no JSON found")
    candidate = s[min(starts):]
    decoder = json.JSONDecoder()
    try:
        return decoder.raw_decode(candidate)[0], False        # valid JSON followed by prose
    except ValueError:
        pass
    try:
        return decoder.raw_decode(repair_json(candidate))[0], False
    except ValueError:
        pass
    try:                                                       # Python-style dict: 'a': True
        return ast.literal_eval(candidate.rstrip().rstrip(";")), False
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        raise ValueError("could not parse JSON") from None


def arguments_to_dict(value: Any) -> tuple[dict[str, Any], bool, str]:
    """Normalise tool-call arguments to (dict, was_clean, error)."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return {}, True, ""
    clean = True
    for _ in range(2):                                         # allow double-encoded JSON
        if isinstance(value, str):
            try:
                value, c = loads_loose(value)
            except ValueError:
                return {}, False, "The arguments are not valid JSON."
            clean = clean and c
    if not isinstance(value, dict):
        return {}, False, "The arguments must be a JSON object."
    return value, clean, ""


def _first(obj: dict[str, Any], keys: tuple[str, ...]) -> Any:
    for k in keys:
        if k in obj:
            return obj[k]
    return None


def calls_from_obj(obj: Any, known: set[str] | None, source: str = "json") -> list[ToolCall]:
    """Recognise tool calls in the JSON shapes models use. If `known` is given, only calls
    to those tools are accepted (avoids mistaking example JSON for a call)."""
    calls: list[ToolCall] = []
    if isinstance(obj, list):
        for item in obj:
            calls += calls_from_obj(item, known, source)
        return calls
    if not isinstance(obj, dict):
        return calls
    if isinstance(obj.get("tool_calls"), list):
        return calls_from_obj(obj["tool_calls"], known, source)
    fn = obj.get("function")
    if isinstance(fn, dict):                                   # OpenAI shape
        obj = {**fn, **({"id": obj["id"]} if "id" in obj else {})}
    name = _first(obj, _NAME_KEYS)
    if isinstance(name, dict):
        name = name.get("name")
    if not isinstance(name, str) or (known is not None and name not in known):
        return calls
    args, clean, err = arguments_to_dict(_first(obj, _ARG_KEYS))
    calls.append(ToolCall(name=name, arguments=args, id=str(obj.get("id") or ""),
                          source=source, complete=clean, error=err))
    return calls


def iter_json_values(text: str) -> list[tuple[Any, bool]]:
    """All top-level JSON objects found in `text` (several may follow each other)."""
    found: list[tuple[Any, bool]] = []
    decoder = json.JSONDecoder()
    pos = 0
    while True:
        start = text.find("{", pos)
        if start == -1:
            break
        try:
            value, end = decoder.raw_decode(text, start)
            found.append((value, True))
            pos = end
            continue
        except ValueError:
            pass
        try:
            value, c = loads_loose(text[start:])
        except ValueError:
            break
        found.append((value, False))
        break
    return found


def extract_json_calls(text: str, known: set[str]) -> tuple[list[ToolCall], str]:
    """JSON tool calls written as plain text: in fenced blocks, or as the whole message."""
    calls: list[ToolCall] = []
    remaining = text
    for m in list(_FENCED_BLOCK_RE.finditer(text)):
        try:
            value, clean = loads_loose(m.group(1))
        except ValueError:
            continue
        found = calls_from_obj(value, known)
        if found:
            for c in found:
                c.complete = c.complete and clean
            calls += found
            remaining = remaining.replace(m.group(0), "", 1)
    if not calls and text.strip()[:1] in ("{", "["):
        try:
            value, clean = loads_loose(text)
        except ValueError:
            return [], text
        found = calls_from_obj(value, known)
        for c in found:
            c.complete = c.complete and clean
        if found:
            return found, ""
    return calls, remaining
