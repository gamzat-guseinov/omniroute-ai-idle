"""Saving and restoring conversations, and rebuilding what the chat showed from them."""
from __future__ import annotations

import hashlib
import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .agent.conversation import Conversation
from .config import ConfigError, state_dir
from .formats import parse_response
from .formats.model import ToolCall
from .tools.base import ToolResult

_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_RESPONSE_RE = re.compile(r'<tool_response id="([^"]*)" name="([^"]*)">\n(.*?)\n</tool_response>', re.S)


def default_session_name() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")


def check_name(name: str) -> str:
    name = name.strip()
    if not _NAME_RE.match(name):
        raise ConfigError("A session name may contain letters, digits, '.', '_' and '-' (max 64).")
    return name


@dataclass
class SessionInfo:
    name: str
    updated: str
    messages: int
    title: str


class SessionStore:
    """Sessions live under the state directory, one folder per workspace."""

    def __init__(self, workspace: str | os.PathLike[str], state_root: Path | None = None) -> None:
        digest = hashlib.sha1(str(Path(os.path.realpath(workspace))).encode()).hexdigest()[:12]
        self.dir = (state_root or state_dir()) / "sessions" / digest

    def _path(self, name: str) -> Path:
        return self.dir / f"{check_name(name)}.json"

    def save(self, name: str, conv: Conversation, meta: dict[str, Any] | None = None) -> Path:
        path = self._path(name)
        self.dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        first = next((m.content for m in conv.messages if m.kind == "user"), "")
        data = {"version": 1, "name": name, "title": " ".join(first.split())[:80],
                "updated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "meta": meta or {}, "conversation": conv.to_dict()}
        tmp = path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # may contain secrets
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            os.fchmod(fh.fileno(), 0o600)
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
        return path

    def load(self, name: str, conv: Conversation) -> dict[str, Any]:
        """Load `name` into `conv` (messages and summary; the system prompt stays as it is)."""
        path = self._path(name)
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            conv.load_dict(data["conversation"])
        except FileNotFoundError:
            raise ConfigError(f"No saved session named '{name}'. Use /sessions to list them.") from None
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise ConfigError(f"Session '{name}' could not be read: {exc}") from None
        return data.get("meta", {})

    def list(self) -> list[SessionInfo]:
        infos = []
        for path in self.dir.glob("*.json") if self.dir.is_dir() else []:
            try:
                d = json.loads(path.read_text(encoding="utf-8"))
                infos.append(SessionInfo(path.stem, d.get("updated", ""),
                                         len(d["conversation"]["messages"]), d.get("title", "")))
            except (OSError, ValueError, KeyError, TypeError):
                continue
        return sorted(infos, key=lambda i: i.updated, reverse=True)

    def latest(self) -> str | None:
        infos = self.list()
        return infos[0].name if infos else None

    def delete(self, name: str) -> bool:
        try:
            self._path(name).unlink()
            return True
        except FileNotFoundError:
            return False


# --------------------------------------------------------------------------- transcript
@dataclass
class TranscriptItem:
    kind: str                         # user | assistant | tool | note
    text: str = ""
    call: ToolCall | None = None
    result: ToolResult | None = None


def _result_from_text(content: str) -> ToolResult:
    if content.startswith("ERROR: "):
        return ToolResult(False, content[len("ERROR: "):])
    return ToolResult(True, content)


def transcript(conv: Conversation, known_tools: set[str]) -> list[TranscriptItem]:
    """What the chat showed, rebuilt from the saved messages (for resuming a session)."""
    items: list[TranscriptItem] = []
    pending: dict[str, TranscriptItem] = {}          # call id -> its tool item, waiting for a result
    for m in conv.messages:
        if m.role == "user" and m.kind == "user":
            items.append(TranscriptItem("user", m.content))
        elif m.role == "user" and m.kind == "result":
            for cid, name, body in _RESPONSE_RE.findall(m.content):
                item = pending.pop(cid, None)
                if item is None:   # ids of re-parsed text calls differ: match by tool name and order
                    item = next((it for it in pending.values()
                                 if it.call and it.call.name == name and it.result is None), None)
                    if item is not None:
                        pending.pop(item.call.id, None)
                if item is not None:
                    item.result = _result_from_text(body)
        elif m.role == "user":
            items.append(TranscriptItem("note", m.content))
        elif m.role == "tool":
            item = pending.pop(m.tool_call_id or "", None)
            if item is not None:
                item.result = _result_from_text(m.content)
        elif m.role == "assistant":
            if m.tool_calls:
                if m.content.strip():
                    items.append(TranscriptItem("assistant", m.content))
                for tc in m.tool_calls:
                    try:
                        args = json.loads(tc["function"]["arguments"])
                    except ValueError:
                        args = {}
                    call = ToolCall(tc["function"]["name"], args if isinstance(args, dict) else {}, tc["id"])
                    item = TranscriptItem("tool", call=call)
                    pending[call.id] = item
                    items.append(item)
            else:
                parsed = parse_response(m.content, [], known_tools)
                if parsed.text:
                    items.append(TranscriptItem("assistant", parsed.text))
                for call in parsed.calls:
                    item = TranscriptItem("tool", call=call)
                    pending[call.id] = item
                    items.append(item)
    return items
