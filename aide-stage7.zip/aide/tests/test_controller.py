import asyncio
import os
import tempfile
import unittest
from pathlib import Path

from aide.agent.permissions import Decision
from aide.config import Config
from aide.ui.controller import Controller

from .fakes import FakeClient, native, text


class FakeView:
    def __init__(self):
        self.texts: list[tuple[str, str]] = []
        self.assistants: list[dict] = []
        self.cards: list[dict] = []
        self.diffs: list[str] = []
        self.tasks: list[asyncio.Future] = []
        self.approvals = []
        self.decision = Decision(True)
        self.status = ""
        self.cleared = 0
        self.markdown = self.expanded = None
        self.copied: list[str] = []
        self.copy_result: str | None = "xclip"
        self.quit_called = False

    # View protocol -------------------------------------------------------
    def add_text(self, text, kind):
        self.texts.append((kind, text))

    def start_assistant(self):
        h = {"raw": "", "final": False, "removed": False}
        self.assistants.append(h)
        return h

    def update_assistant(self, h, raw, final):
        h["raw"], h["final"] = raw, final

    def remove(self, h):
        h["removed"] = True

    def add_tool(self, call):
        h = {"call": call, "result": None}
        self.cards.append(h)
        return h

    def finish_tool(self, h, call, result):
        h["result"] = result

    def show_diff(self, text):
        self.diffs.append(text)

    def clear(self):
        self.cleared += 1
        self.texts.clear()
        self.assistants.clear()
        self.cards.clear()

    def set_status(self, text):
        self.status = text

    def set_markdown(self, on):
        self.markdown = on

    def set_tools_expanded(self, on):
        self.expanded = on

    def copy(self, text):
        self.copied.append(text)
        return self.copy_result

    def start_task(self, coro):
        task = asyncio.ensure_future(coro)
        self.tasks.append(task)
        return task

    def set_prompt_text(self, text):
        pass

    def quit(self):
        self.quit_called = True

    async def approve(self, request):
        self.approvals.append(request)
        return self.decision

    # helpers --------------------------------------------------------------
    def messages(self, kind=None):
        return [t for k, t in self.texts if kind is None or k == kind]

    def last(self):
        return self.texts[-1][1]


class ControllerTestCase(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        base = Path(os.path.realpath(self._tmp.name))
        self.ws, self.state = base / "ws", base / "state"
        self.ws.mkdir()
        self.state.mkdir()
        self.view = FakeView()

    def make(self, script=(), mode="auto", **kw):
        cfg = Config(base_url="http://x/v1", api_key="k-123456", model="m", permission_mode=mode,
                     **kw.pop("cfg", {}))
        self.client = FakeClient(script)
        self.ctl = Controller(cfg, self.ws, self.view, client=self.client, state_root=self.state,
                              template="PROMPT {{workspace}} {{mode}}", prompt_path=Path("/p/prompt.md"), **kw)
        self.addCleanup(self.ctl.registry.ctx.close)
        self.ctl.start()
        return self.ctl

    async def settle(self):
        await asyncio.gather(*self.view.tasks, return_exceptions=True)

    async def say(self, line):
        self.ctl.submit(line)
        await self.settle()


class ChatTests(ControllerTestCase):
    async def test_plain_answer_is_streamed_finalized_and_saved(self):
        self.make([text("Hello there, friend!")])
        await self.say("hi")
        self.assertIn("> hi", self.view.messages("user"))
        a = self.view.assistants[0]
        self.assertEqual((a["raw"], a["final"]), ("Hello there, friend!", True))
        self.assertFalse(self.ctl.busy)
        self.assertEqual(self.ctl.history.items, ["hi"])
        self.assertEqual(len(self.ctl.sessions.list()), 1)            # autosaved
        self.assertIn("session:", self.view.status)

    async def test_start_shows_a_welcome_with_the_workspace_and_prompt_file(self):
        self.make()
        welcome = self.view.messages("info")[0]
        self.assertIn(str(self.ws), welcome)
        self.assertIn("/p/prompt.md", welcome)

    async def test_tool_cards_and_undo_flow(self):
        (self.ws / "a.txt").write_text("keep\n")
        self.make([native(("write_file", {"path": "new.py", "content": "print(1)\n"}),
                          ("edit_file", {"path": "a.txt", "old_text": "keep", "new_text": "lost"})),
                   text("All changed.")])
        await self.say("change things")
        self.assertEqual([c["call"].name for c in self.view.cards], ["write_file", "edit_file"])
        self.assertTrue(all(c["result"].ok for c in self.view.cards))
        await self.say("/diff")
        self.assertIn("+print(1)", self.view.diffs[0])
        self.assertIn("-keep", self.view.diffs[0])
        await self.say("/undo")
        self.assertEqual((self.ws / "a.txt").read_text(), "keep\n")
        self.assertFalse((self.ws / "new.py").exists())
        self.assertIn("Undid the changes", self.view.last())
        self.assertIn("a.txt", self.view.last())
        # the model is told, so it does not assume its edits are still there
        self.client.script = [text("ok")]
        await self.say("what now?")
        sent = self.client.requests[-1]["messages"]
        self.assertTrue(any("undid your last file changes" in m["content"] for m in sent))
        await self.say("/undo")
        self.assertIn("Nothing to undo", self.view.last())

    async def test_approval_flow_in_ask_mode(self):
        self.make([native(("write_file", {"path": "x.txt", "content": "data"})), text("done")], mode="ask")
        self.view.decision = Decision(False, message="not now")
        await self.say("write x")
        self.assertEqual(self.view.approvals[0].tool, "write_file")
        self.assertIn("+data", self.view.approvals[0].detail)
        self.assertFalse((self.ws / "x.txt").exists())
        self.assertIn("denied", self.view.cards[0]["result"].output)

    async def test_stop_cancels_a_running_command_and_keeps_history_valid(self):
        self.make([native(("run_command", {"command": "sleep 30"}))])
        self.ctl.submit("run it")
        for _ in range(200):
            await asyncio.sleep(0.05)
            if self.view.cards:
                break
        self.assertTrue(self.ctl.busy)
        self.ctl.submit("another message")
        self.assertIn("Still working", self.view.last())
        self.ctl.stop()
        await self.settle()
        self.assertFalse(self.ctl.busy)
        self.assertIn("Stopped.", self.view.messages("info"))
        assistant = next(m for m in self.ctl.conv.messages if m.role == "assistant")
        answered = {m.tool_call_id for m in self.ctl.conv.messages if m.role == "tool"}
        self.assertEqual({tc["id"] for tc in assistant.tool_calls}, answered)

    async def test_stop_when_idle_is_harmless(self):
        self.make()
        self.ctl.stop()
        self.assertIn("Nothing is running", self.view.last())

    async def test_errors_are_shown_not_raised(self):
        from aide.client.errors import NetworkError
        self.make([NetworkError("Cannot reach host.", detail="refused")])
        await self.say("hi")
        self.assertTrue(any("Cannot reach host" in t for t in self.view.messages("error")))
        self.assertFalse(self.ctl.busy)

    async def test_code_block_hint_is_shown_once(self):
        self.make([text("Here:\n```python\nprint(1)\n```"), text("More:\n```sh\nls\n```")])
        await self.say("one")
        await self.say("two")
        hints = [t for t in self.view.messages() if "code block(s)" in t]
        self.assertEqual(len(hints), 1)


class CommandTests(ControllerTestCase):
    async def test_help_unknown_and_suggestions(self):
        self.make()
        await self.say("/help")
        self.assertIn("/undo", self.view.last())
        await self.say("/hepl")
        self.assertEqual(self.view.texts[-1][0], "error")
        self.assertIn("Did you mean /help", self.view.last())
        await self.say("/zzzzzz")
        self.assertIn("Type /help", self.view.last())

    async def test_mode_changes_policy_and_system_prompt(self):
        self.make(mode="ask")
        await self.say("/mode auto-edit")
        self.assertEqual(self.ctl.policy.mode.value, "auto-edit")
        self.assertIn("auto-edit", self.ctl.conv.system_prompt)
        self.assertIn("mode: auto-edit", self.view.status)
        await self.say("/mode yolo")
        self.assertEqual(self.view.texts[-1][0], "error")
        await self.say("/mode")
        self.assertIn("Permission mode: auto-edit", self.view.last())

    async def test_model_show_switch_and_list(self):
        self.make()
        await self.say("/model")
        self.assertIn("Model: m", self.view.last())
        await self.say("/model list")
        self.assertIn("2 model(s)", self.view.last())
        await self.say("/model fancy-1")
        self.assertEqual(self.client.model, "fancy-1")
        self.assertIn("model: fancy-1", self.view.status)

    async def test_tokens_markdown_expand_prompt(self):
        self.make([text("ok")])
        await self.say("hi")
        await self.say("/tokens")
        self.assertIn("Context: about", self.view.last())
        await self.say("/markdown off")
        self.assertIs(self.view.markdown, False)
        await self.say("/md")
        self.assertIs(self.view.markdown, True)
        await self.say("/expand")
        self.assertIs(self.view.expanded, True)
        await self.say("/expand off")
        self.assertIs(self.view.expanded, False)
        await self.say("/prompt")
        self.assertIn("/p/prompt.md", self.view.last())

    async def test_run_executes_a_shell_command_through_the_policy(self):
        self.make(mode="ask")
        await self.say("/run echo from-run")
        self.assertEqual(self.view.approvals[0].tool, "run_command")
        self.assertIn("from-run", self.view.cards[0]["result"].output)
        self.assertFalse(self.ctl.busy)
        await self.say("/run")
        self.assertIn("Usage", self.view.last())

    async def test_busy_gating_of_commands(self):
        self.make([native(("run_command", {"command": "sleep 30"}))])
        self.ctl.submit("go")
        for _ in range(200):
            await asyncio.sleep(0.05)
            if self.view.cards:
                break
        self.ctl.submit("/clear")
        self.assertIn("not available while the agent is working", self.view.last())
        self.ctl.submit("/help")                                  # allowed
        self.assertIn("Commands:", self.view.last())
        self.ctl.stop()
        await self.settle()

    async def test_copy_command(self):
        self.make([text("A:\n```python\nprint(1)\n```\nB:\n```sh\nls -la\n```")])
        await self.say("code please")
        await self.say("/copy")
        self.assertEqual(self.view.copied[-1], "ls -la")
        self.assertIn("block 2 of 2", self.view.last())
        await self.say("/copy 1")
        self.assertEqual(self.view.copied[-1], "print(1)")
        await self.say("/copy 5")
        self.assertIn("choose 1-2", self.view.last())
        await self.say("/copy x")
        self.assertIn("Usage", self.view.last())
        self.view.copy_result = None
        await self.say("/copy")
        self.assertIn("No clipboard", self.view.last())
        self.ctl.last_assistant_text = "no code"
        await self.say("/copy")
        self.assertIn("no code block", self.view.last())

    async def test_exit_saves_and_quits(self):
        self.make([text("hi")])
        await self.say("hello")
        await self.say("/exit")
        self.assertTrue(self.view.quit_called)


class SessionTests(ControllerTestCase):
    async def test_save_list_clear_and_load(self):
        (self.ws / "a.txt").write_text("hello")
        self.make([native(("read_file", {"path": "a.txt"})), text("It says hello."), text("fresh start")])
        await self.say("read a.txt")
        await self.say("/save mywork")
        self.assertIn("Saved session 'mywork'", self.view.last())
        await self.say("/sessions")
        self.assertIn("mywork", self.view.last())
        self.assertIn("read a.txt", self.view.last())
        await self.say("/clear")
        self.assertEqual(self.view.cleared, 1)
        self.assertEqual(self.ctl.conv.messages, [])
        await self.say("/load mywork")
        self.assertIn("Resumed session 'mywork'", self.view.last())
        self.assertIn("> read a.txt", self.view.messages("user"))
        self.assertEqual(self.view.cards[0]["call"].name, "read_file")
        self.assertIn("hello", self.view.cards[0]["result"].output)
        self.assertEqual(self.view.assistants[-1]["raw"], "It says hello.")
        # the resumed conversation continues where it left off
        await self.say("thanks")
        sent = self.client.requests[-1]["messages"]
        self.assertEqual([m["role"] for m in sent][:5], ["system", "user", "assistant", "tool", "assistant"])

    async def test_bad_names_and_missing_sessions(self):
        self.make()
        await self.say("/save ../evil")
        self.assertEqual(self.view.texts[-1][0], "error")
        await self.say("/load nope")
        self.assertIn("No saved session", self.view.last())
        await self.say("/load")
        self.assertIn("Usage", self.view.last())
        await self.say("/sessions")
        self.assertIn("No saved sessions", self.view.last())

    async def test_resume_latest_on_startup(self):
        self.make([text("first answer")])
        await self.say("question")
        self.ctl.close()
        self.view = FakeView()
        self.make(resume=True)
        self.assertIn("Resumed session", self.view.messages("info")[-1])
        self.assertIn("> question", self.view.messages("user"))
        self.assertEqual(self.view.assistants[0]["raw"], "first answer")

    async def test_resume_without_sessions_warns(self):
        self.make(resume=True)
        self.assertTrue(any("no saved session" in t for t in self.view.messages("warning")))

    async def test_text_mode_session_replays_tool_calls(self):
        (self.ws / "a.txt").write_text("x")
        call = '<tool_call>{"name": "read_file", "arguments": {"path": "a.txt"}}</tool_call>'
        self.make([text("Reading.\n" + call), text("done")], cfg={"tool_format": "xml"})
        await self.say("go")
        await self.say("/load " + self.ctl.session_name)
        self.assertEqual(self.view.cards[0]["call"].name, "read_file")
        self.assertTrue(self.view.cards[0]["result"].ok)
        self.assertNotIn("tool_call", " ".join(a["raw"] for a in self.view.assistants))


if __name__ == "__main__":
    unittest.main()
