import json
import os
import shutil
import stat
import tempfile
import unittest
from pathlib import Path

from aide.agent.conversation import Conversation, native_tool_call
from aide.config import ConfigError
from aide.safety.shadow import git_available
from aide.safety.undo import UndoStore
from aide.sessions import SessionStore, check_name, transcript
from aide.tools import create_registry


class UndoScenarios:
    """Behaviour every undo backend must have; run once per backend below."""
    backend = "files"

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        base = Path(os.path.realpath(self._tmp.name))
        self.ws, self.state = base / "ws", base / "state"
        self.ws.mkdir()
        self.state.mkdir()
        self.store = UndoStore(self.ws, self.state, backend=self.backend)

    def turn(self, label="turn"):
        self.store.begin_turn(label)

    def test_modified_file_is_restored(self):
        f = self.ws / "a.txt"
        f.write_text("original")
        self.turn()
        self.store.record(f)
        f.write_text("changed")
        report = self.store.undo_last()
        self.assertEqual(f.read_text(), "original")
        self.assertEqual(report.restored, ["a.txt"])

    def test_only_the_first_snapshot_of_a_turn_counts(self):
        f = self.ws / "a.txt"
        f.write_text("v1")
        self.turn()
        self.store.record(f)
        f.write_text("v2")
        self.store.record(f)
        f.write_text("v3")
        self.store.undo_last()
        self.assertEqual(f.read_text(), "v1")

    def test_created_files_and_the_directories_made_for_them_are_removed(self):
        self.turn()
        f = self.ws / "new" / "deep" / "x.txt"
        self.store.record(f)
        f.parent.mkdir(parents=True)
        f.write_text("x")
        self.store.record(self.ws / "new" / "deep" / "y.txt")           # covered by the 'absent' parent
        report = self.store.undo_last()
        self.assertFalse((self.ws / "new").exists())
        self.assertTrue(report.removed)

    def test_deleted_directory_tree_is_restored(self):
        d = self.ws / "d"
        (d / "sub").mkdir(parents=True)
        (d / "a.txt").write_text("A")
        (d / "sub" / "b.txt").write_text("B")
        self.turn()
        self.store.record(d)
        import shutil
        shutil.rmtree(d)
        self.store.undo_last()
        self.assertEqual((d / "sub" / "b.txt").read_text(), "B")
        self.assertEqual((d / "a.txt").read_text(), "A")

    def test_move_is_undone(self):
        src, dst = self.ws / "a.txt", self.ws / "out" / "b.txt"
        src.write_text("data")
        self.turn()
        self.store.record(src)
        self.store.record(dst)
        dst.parent.mkdir()
        os.replace(src, dst)
        self.store.undo_last()
        self.assertEqual(src.read_text(), "data")
        self.assertFalse((self.ws / "out").exists())

    def test_symlink_is_restored_as_a_link(self):
        (self.ws / "t.txt").write_text("t")
        os.symlink("t.txt", self.ws / "link")
        self.turn()
        self.store.record(self.ws / "link")
        (self.ws / "link").unlink()
        self.store.undo_last()
        self.assertEqual(os.readlink(self.ws / "link"), "t.txt")

    def test_undo_walks_back_one_turn_at_a_time(self):
        f = self.ws / "a.txt"
        f.write_text("0")
        for i in (1, 2):
            self.turn(f"turn {i}")
            self.store.record(f)
            f.write_text(str(i))
        self.store.undo_last()
        self.assertEqual(f.read_text(), "1")
        self.store.undo_last()
        self.assertEqual(f.read_text(), "0")
        self.assertIsNone(self.store.undo_last())

    def test_state_survives_a_restart(self):
        f = self.ws / "a.txt"
        f.write_text("before")
        self.turn("persisted")
        self.store.record(f)
        f.write_text("after")
        again = UndoStore(self.ws, self.state, backend=self.backend)
        self.assertEqual(again.checkpoint_count, 1)
        again.undo_last()
        self.assertEqual(f.read_text(), "before")

    def test_diff_shows_modifications_creations_and_deletions(self):
        a, gone = self.ws / "a.txt", self.ws / "gone.txt"
        a.write_text("one\ntwo\n")
        gone.write_text("bye\n")
        self.turn()
        for p in (a, gone, self.ws / "new.txt"):
            self.store.record(p)
        a.write_text("one\n2\n")
        gone.unlink()
        (self.ws / "new.txt").write_text("fresh\n")
        diff = self.store.diff_last()
        self.assertIn("-two", diff)
        self.assertIn("+2", diff)
        self.assertIn("-bye", diff)
        self.assertIn("--- /dev/null", diff)
        self.assertIn("+fresh", diff)

    def test_commands_are_counted_but_not_undone(self):
        self.turn("only commands")
        self.store.note_command("make")
        report = self.store.undo_last()
        self.assertTrue(report.nothing_to_do)
        self.assertEqual(report.commands_run, 1)

    def test_oversized_snapshots_are_skipped_and_reported(self):
        if self.backend != "files":
            self.skipTest("file backend only")
        store = UndoStore(self.ws, self.state, max_bytes=10, backend="files")
        big = self.ws / "big.txt"
        big.write_text("x" * 100)
        store.begin_turn("big")
        store.record(big)
        big.write_text("y")
        report = store.undo_last()
        self.assertEqual(report.skipped, ["big.txt"])
        self.assertEqual(big.read_text(), "y")

    def test_checkpoint_limit_and_outside_paths(self):
        if self.backend != "files":
            self.skipTest("file backend only")
        store = UndoStore(self.ws, self.state, max_checkpoints=2, backend="files")
        for i in range(4):
            store.begin_turn(str(i))
            store.record(self.ws / f"f{i}")
        self.assertEqual(store.checkpoint_count, 2)
        store.record(self.state / "elsewhere")             # outside the workspace: ignored
        self.assertEqual(len(store.latest()["entries"]), 1)

    def test_tampered_index_cannot_escape_the_workspace(self):
        if self.backend != "files":
            self.skipTest("file backend only")
        self.turn()
        self.store.record(self.ws / "a.txt")
        index = self.state / "undo"
        idx = next(index.glob("*/index.json"))
        data = json.loads(idx.read_text())
        data["checkpoints"][0]["entries"].append({"path": "../outside.txt", "kind": "absent"})
        idx.write_text(json.dumps(data))
        victim = self.ws.parent / "outside.txt"
        victim.write_text("keep")
        again = UndoStore(self.ws, self.state, backend="files")
        report = again.undo_last()
        self.assertTrue(victim.exists())
        self.assertIn("../outside.txt", report.skipped)

    def test_works_as_the_tool_hook(self):
        reg = create_registry(self.ws, before_write=self.store.record, before_exec=self.store.note_command)
        self.addCleanup(reg.ctx.close)
        (self.ws / "a.txt").write_text("keep\n")
        self.turn("agent turn")
        reg.execute("edit_file", {"path": "a.txt", "old_text": "keep", "new_text": "lost"})
        reg.execute("write_file", {"path": "dir/new.py", "content": "print(1)\n"})
        reg.execute("delete_file", {"path": "a.txt"})
        self.assertFalse((self.ws / "a.txt").exists())
        self.store.undo_last()
        self.assertEqual((self.ws / "a.txt").read_text(), "keep\n")
        self.assertFalse((self.ws / "dir").exists())


class UndoFilesBackendTests(UndoScenarios, unittest.TestCase):
    backend = "files"

    def test_shell_commands_are_not_tracked(self):
        f = self.ws / "a.txt"
        f.write_text("original")
        self.turn()
        self.store.note_command("sed -i s/original/changed/ a.txt")
        f.write_text("changed")
        report = self.store.undo_last()
        self.assertEqual((report.commands_run, f.read_text()), (1, "changed"))


@unittest.skipUnless(git_available(), "git is not installed")
class UndoGitBackendTests(UndoScenarios, unittest.TestCase):
    backend = "git"

    def test_default_backend_is_git_when_available(self):
        self.assertEqual(UndoStore(self.ws, self.state).backend, "git")

    def test_effects_of_shell_commands_are_undone_too(self):
        (self.ws / "a.txt").write_text("keep\n")
        (self.ws / "gone.txt").write_text("bye\n")
        (self.ws / "d").mkdir()
        (self.ws / "d" / "x.txt").write_text("x")
        self.turn("agent ran commands")
        self.store.note_command("sed -i ... && rm ... && touch ...")      # snapshot happens here
        (self.ws / "a.txt").write_text("changed by sed\n")
        (self.ws / "gone.txt").unlink()
        shutil.rmtree(self.ws / "d")
        (self.ws / "made.txt").write_text("new")
        (self.ws / "newdir").mkdir()
        (self.ws / "newdir" / "y.txt").write_text("y")
        diff = self.store.diff_last()
        self.assertIn("-keep", diff)
        self.assertIn("+changed by sed", diff)
        self.assertIn("made.txt", diff)
        report = self.store.undo_last()
        self.assertEqual((self.ws / "a.txt").read_text(), "keep\n")
        self.assertEqual((self.ws / "gone.txt").read_text(), "bye\n")
        self.assertEqual((self.ws / "d" / "x.txt").read_text(), "x")
        self.assertFalse((self.ws / "made.txt").exists())
        self.assertFalse((self.ws / "newdir").exists())
        self.assertEqual(report.commands_run, 1)
        self.assertEqual(report.skipped, [])

    def test_gitignored_files_and_dependency_folders_are_left_alone(self):
        (self.ws / ".gitignore").write_text("secret.env\nbuild/\n")
        (self.ws / "secret.env").write_text("KEY=1")
        (self.ws / "node_modules").mkdir()
        (self.ws / "node_modules" / "m.js").write_text("m")
        self.turn()
        self.store.note_command("make")
        (self.ws / "secret.env").write_text("KEY=2")
        (self.ws / "node_modules" / "m.js").write_text("changed")
        (self.ws / "build").mkdir()
        (self.ws / "build" / "out.o").write_text("o")
        (self.ws / "src.py").write_text("print(1)")
        self.store.undo_last()
        self.assertEqual((self.ws / "secret.env").read_text(), "KEY=2")      # not tracked, not touched
        self.assertEqual((self.ws / "node_modules" / "m.js").read_text(), "changed")
        self.assertTrue((self.ws / "build" / "out.o").exists())
        self.assertFalse((self.ws / "src.py").exists())

    def test_users_own_git_repository_is_left_alone(self):
        import subprocess
        subprocess.run(["git", "init", "-q"], cwd=self.ws, check=True)
        (self.ws / "a.txt").write_text("1")
        before = subprocess.run(["git", "status", "--porcelain"], cwd=self.ws, capture_output=True, text=True).stdout
        head_before = (self.ws / ".git" / "HEAD").read_text()
        self.turn()
        self.store.note_command("x")
        (self.ws / "a.txt").write_text("2")
        self.store.undo_last()
        after = subprocess.run(["git", "status", "--porcelain"], cwd=self.ws, capture_output=True, text=True).stdout
        self.assertEqual((before, (self.ws / ".git" / "HEAD").read_text()), (after, head_before))
        self.assertEqual((self.ws / "a.txt").read_text(), "1")
        self.assertFalse((self.ws / ".git" / "aide-index").exists())

    def test_file_modes_unusual_names_and_binary_content_survive(self):
        script = self.ws / "run.sh"
        script.write_text("#!/bin/sh\n")
        os.chmod(script, 0o755)
        odd = self.ws / "sp ace é\"q\".txt"
        odd.write_text("odd")
        blob = self.ws / "data.bin"
        blob.write_bytes(bytes(range(256)) * 10)
        self.turn()
        self.store.note_command("x")
        os.chmod(script, 0o644)
        odd.unlink()
        blob.write_bytes(b"\x00")
        self.store.undo_last()
        self.assertEqual(stat.S_IMODE(os.stat(script).st_mode), 0o755)
        self.assertEqual(odd.read_text(), "odd")
        self.assertEqual(blob.read_bytes(), bytes(range(256)) * 10)

    def test_big_files_are_not_tracked_and_reported(self):
        from aide.safety import shadow
        old = shadow.MAX_FILE_BYTES
        shadow.MAX_FILE_BYTES = 100
        self.addCleanup(setattr, shadow, "MAX_FILE_BYTES", old)
        big = self.ws / "big.dat"
        big.write_bytes(b"x" * 500)
        self.turn()
        self.store.note_command("x")
        big.write_bytes(b"y" * 500)
        (self.ws / "small.txt").write_text("s")
        report = self.store.undo_last()
        self.assertFalse((self.ws / "small.txt").exists())
        self.assertEqual(big.read_bytes(), b"y" * 500)
        self.assertTrue(any("too large" in s for s in report.skipped))

    def test_a_workspace_too_large_falls_back_to_file_snapshots(self):
        from aide.safety import shadow
        old = shadow.MAX_FILES
        shadow.MAX_FILES = 2
        self.addCleanup(setattr, shadow, "MAX_FILES", old)
        for i in range(5):
            (self.ws / f"f{i}.txt").write_text(str(i))
        self.turn()
        target = self.ws / "f0.txt"
        self.store.record(target)
        self.assertIn("too large", self.store.last_problem)
        target.write_text("changed")
        self.store.undo_last()
        self.assertEqual(target.read_text(), "0")             # the file backend still worked

    def test_unknown_backend_is_rejected(self):
        with self.assertRaises(ValueError):
            UndoStore(self.ws, self.state, backend="magic")


class SessionTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.ws = Path(self._tmp.name) / "ws"
        self.ws.mkdir()
        self.store = SessionStore(self.ws, Path(self._tmp.name) / "state")

    def conv(self):
        c = Conversation("SYS")
        c.add_user("make a script")
        c.add_assistant("I'll write it.", [native_tool_call("c1", "write_file", {"path": "a.py", "content": "x"})])
        c.add_tool_result("c1", "Created a.py (1 lines, 1 B)")
        c.add_assistant("Done.")
        c.summary = "earlier stuff"
        return c

    def test_roundtrip_private_file_and_listing(self):
        path = self.store.save("first", self.conv(), {"model": "m"})
        self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
        loaded = Conversation("OTHER SYSTEM PROMPT")
        meta = self.store.load("first", loaded)
        self.assertEqual(meta, {"model": "m"})
        self.assertEqual(loaded.system_prompt, "OTHER SYSTEM PROMPT")    # prompt is not overwritten
        self.assertEqual(loaded.summary, "earlier stuff")
        self.assertEqual([m.role for m in loaded.messages], ["user", "assistant", "tool", "assistant"])
        self.assertEqual(loaded.messages[1].tool_calls[0]["id"], "c1")
        info = self.store.list()[0]
        self.assertEqual((info.name, info.messages, info.title), ("first", 4, "make a script"))

    def test_latest_delete_and_errors(self):
        self.assertIsNone(self.store.latest())
        self.store.save("a", self.conv())
        self.store.save("b", self.conv())
        self.assertIn(self.store.latest(), ("a", "b"))
        self.assertTrue(self.store.delete("a"))
        self.assertFalse(self.store.delete("a"))
        with self.assertRaises(ConfigError):
            self.store.load("missing", Conversation(""))
        for bad in ("", "../x", "a b", "a/b", ".hidden", "x" * 80):
            with self.assertRaises(ConfigError, msg=bad):
                check_name(bad)

    def test_corrupt_files_are_skipped(self):
        self.store.save("good", self.conv())
        (self.store.dir / "bad.json").write_text("{not json")
        self.assertEqual([i.name for i in self.store.list()], ["good"])
        with self.assertRaises(ConfigError):
            self.store.load("bad", Conversation(""))

    def test_sessions_are_per_workspace(self):
        other = Path(self._tmp.name) / "other"
        other.mkdir()
        self.store.save("mine", self.conv())
        self.assertEqual(SessionStore(other, Path(self._tmp.name) / "state").list(), [])

    def test_transcript_from_native_history(self):
        items = transcript(self.conv(), {"write_file"})
        self.assertEqual([i.kind for i in items], ["user", "assistant", "tool", "assistant"])
        self.assertEqual(items[2].call.name, "write_file")
        self.assertTrue(items[2].result.ok)
        self.assertIn("Created a.py", items[2].result.output)

    def test_transcript_marks_failed_results_and_notes(self):
        c = Conversation("S")
        c.add_user("go")
        c.add_assistant("", [native_tool_call("c1", "run_command", {"command": "false"})])
        c.add_tool_result("c1", "ERROR: exit code: 1")
        c.add_note("[note] undone")
        items = transcript(c, {"run_command"})
        self.assertFalse(items[1].result.ok)
        self.assertEqual(items[1].result.output, "exit code: 1")
        self.assertEqual(items[2].kind, "note")

    def test_transcript_from_text_mode_history(self):
        c = Conversation("S")
        c.add_user("read it")
        c.add_assistant('Looking.\n<tool_call>{"name": "read_file", "arguments": {"path": "a"}}</tool_call>')
        c.add_text_results('<tool_response id="zzz" name="read_file">\nhello\n</tool_response>')
        c.add_assistant("It says hello.")
        items = transcript(c, {"read_file"})
        self.assertEqual([i.kind for i in items], ["user", "assistant", "tool", "assistant"])
        self.assertEqual(items[1].text, "Looking.")
        self.assertEqual(items[2].result.output, "hello")      # matched by name although ids differ


if __name__ == "__main__":
    unittest.main()
