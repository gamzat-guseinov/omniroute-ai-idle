"""A scripted stand-in for OmniRouteClient, used by the agent-loop tests."""
from __future__ import annotations

import json

from aide.client.errors import OmniRouteError
from aide.client.events import Done, RetryEvent, TextDelta, ToolCallDelta, Usage


def text(s: str, finish: str = "stop", chunk: int = 7):
    """Events for a plain text reply, split into small chunks like a real stream."""
    return [TextDelta(s[i:i + chunk]) for i in range(0, len(s), chunk)] + [Done(finish)]


def native(*calls, text_before: str = "", finish: str = "tool_calls"):
    """Events for a reply with native tool calls: calls are (name, args-dict) tuples."""
    events = [TextDelta(text_before)] if text_before else []
    for i, (name, args) in enumerate(calls):
        raw = json.dumps(args)
        events += [ToolCallDelta(i, f"call_{i}", name, ""), ToolCallDelta(i, None, None, raw[:5]),
                   ToolCallDelta(i, None, None, raw[5:])]
    return events + [Done(finish)]


class FakeClient:
    """`script` items are event lists, or an exception instance to raise instead."""

    def __init__(self, script=(), models=("m", "m2")):
        self.script = list(script)
        self.requests: list[dict] = []
        self.model = "m"
        self.models = list(models)

    def set_model(self, name):
        self.model = name

    async def list_models(self):
        return self.models

    def stream_chat(self, messages, *, tools=None, model=None, temperature=None, max_tokens=None):
        self.requests.append({"messages": json.loads(json.dumps(messages)), "tools": tools,
                              "max_tokens": max_tokens})
        item = self.script.pop(0)
        return self._gen(item)

    async def _gen(self, item):
        if isinstance(item, Exception):
            raise item
        for ev in item:
            yield ev
