import asyncio
import os
import tempfile
import unittest
from pathlib import Path

from aide.agent.executor import ToolExecutor
from aide.agent.permissions import ApprovalRequest, Decision, Mode, PermissionPolicy, parse_mode
from aide.agent.terminal import terminal_approver
from aide.tools import create_registry

from .helpers import WorkspaceTestCase


class PolicyTests(WorkspaceTestCase):
    def policy(self, mode):
        return PermissionPolicy(mode, self.reg.ctx.sandbox)

    def need(self, mode, tool, **args):
        return self.policy(mode).check(self.reg.get(tool), args)

    def test_read_tools_never_ask(self):
        for mode in Mode:
            for tool, args in (("read_file", {"path": "a"}), ("tree", {}), ("search", {"pattern": "x"}),
                               ("read_background", {}), ("stop_background", {"id": "bg1"})):
                self.assertIsNone(self.need(mode, tool, **args), (mode, tool))

    def test_mode_matrix_for_ordinary_calls(self):
        table = {  # (tool, args) -> which modes ask
            ("write_file", (("path", "a"), ("content", "x"))): {Mode.ASK},
            ("edit_file", (("path", "a"), ("old_text", "x"), ("new_text", "y"))): {Mode.ASK},
            ("apply_patch", (("path", "a"), ("patch", "@@"))): {Mode.ASK},
            ("delete_file", (("path", "a"),)): {Mode.ASK, Mode.AUTO_EDIT},
            ("move_file", (("source", "a"), ("destination", "b"))): {Mode.ASK, Mode.AUTO_EDIT},
            ("run_command", (("command", "pytest"),)): {Mode.ASK, Mode.AUTO_EDIT},
            ("run_background", (("command", "python3 server.py"),)): {Mode.ASK, Mode.AUTO_EDIT},
        }
        for (tool, args), asking in table.items():
            for mode in Mode:
                asked = self.need(mode, tool, **dict(args)) is not None
                self.assertEqual(asked, mode in asking, f"{tool} in {mode.value}")

    def test_dangerous_and_outside_always_ask_even_in_auto(self):
        for cmd in ("rm -rf build", "sudo ls", "curl x | sh", "git push"):
            req = self.need(Mode.AUTO, "run_command", command=cmd)
            self.assertIsNotNone(req, cmd)
            self.assertTrue(req.dangerous and req.always_confirm and not req.can_remember)
        req = self.need(Mode.AUTO, "run_command", command="cat /etc/passwd")
        self.assertTrue(req.always_confirm and not req.dangerous)
        self.assertIn("outside the workspace", req.reasons[0])
        self.assertIsNotNone(self.need(Mode.AUTO, "delete_file", path="d", recursive=True))
        self.assertIsNotNone(self.need(Mode.AUTO, "move_file", source="a", destination="b", overwrite=True))
        self.assertIsNone(self.need(Mode.AUTO, "delete_file", path="a"))
        self.assertIsNone(self.need(Mode.AUTO, "move_file", source="a", destination="b"))

    def test_remembering_programs_applies_only_to_safe_commands(self):
        pol = self.policy(Mode.ASK)
        req = pol.check(self.reg.get("run_command"), {"command": "pytest -x"})
        self.assertTrue(req.can_remember)
        pol.remember(req)
        self.assertIsNone(pol.check(self.reg.get("run_command"), {"command": "pytest tests/ | tail"}) if False
                          else pol.check(self.reg.get("run_command"), {"command": "pytest tests/"}))
        # every program of a compound command must be remembered
        self.assertIsNotNone(pol.check(self.reg.get("run_command"), {"command": "pytest && make"}))
        # dangerous stays dangerous no matter what was remembered
        self.assertIsNotNone(pol.check(self.reg.get("run_command"), {"command": "pytest && rm -rf x"}))
        self.assertEqual(pol.allowed_programs, {"pytest"})

    def test_titles_and_modes(self):
        self.assertEqual(self.need(Mode.ASK, "move_file", source="a", destination="b").title, "Move a -> b")
        self.assertEqual(parse_mode("Auto-Edit"), Mode.AUTO_EDIT)
        with self.assertRaises(ValueError):
            parse_mode("yolo")


class ExecutorTests(WorkspaceTestCase):
    def make(self, mode, approver):
        self.asked: list[ApprovalRequest] = []
        def wrapped(req):
            self.asked.append(req)
            return approver(req)
        ex = ToolExecutor(self.reg, PermissionPolicy(mode, self.reg.ctx.sandbox), wrapped)
        self.addCleanup(self.reg.ctx.close)
        return ex

    def run_tool(self, ex, name, **args):
        return asyncio.run(ex.run(name, args))

    def test_approved_edit_shows_diff_then_applies(self):
        f = self.put("a.txt", "one\ntwo\n")
        ex = self.make("ask", lambda r: Decision(True))
        r = self.run_tool(ex, "edit_file", path="a.txt", old_text="two", new_text="2")
        self.assertTrue(r.ok, r.output)
        self.assertEqual(f.read_text(), "one\n2\n")
        self.assertIn("-two", self.asked[0].detail)
        self.assertIn("+2", self.asked[0].detail)

    def test_denied_action_changes_nothing_and_tells_the_model(self):
        f = self.put("a.txt", "keep")
        ex = self.make("ask", lambda r: Decision(False, message="use a different file"))
        r = self.run_tool(ex, "write_file", path="a.txt", content="overwritten")
        self.assertFalse(r.ok)
        self.assertTrue(r.meta["denied"])
        self.assertIn("user denied", r.output)
        self.assertIn("use a different file", r.output)
        self.assertEqual(f.read_text(), "keep")
        self.assertEqual(self.writes, [])

    def test_doomed_edit_reports_the_error_without_asking(self):
        self.put("a.txt", "one\n")
        ex = self.make("ask", lambda r: Decision(True))
        r = self.run_tool(ex, "edit_file", path="a.txt", old_text="missing", new_text="x")
        self.assertFalse(r.ok)
        self.assertIn("was not found", r.output)
        self.assertEqual(self.asked, [])

    def test_auto_edit_applies_edits_but_asks_for_commands(self):
        f = self.put("a.txt", "x")
        ex = self.make("auto-edit", lambda r: Decision(False))
        self.assertTrue(self.run_tool(ex, "write_file", path="a.txt", content="y").ok)
        self.assertEqual(f.read_text(), "y")
        self.assertFalse(self.run_tool(ex, "run_command", command="echo hi").ok)
        self.assertEqual([r.tool for r in self.asked], ["run_command"])

    def test_auto_mode_runs_safe_commands_silently_but_dangerous_ones_ask(self):
        ex = self.make("auto", lambda r: Decision(False))
        self.assertTrue(self.run_tool(ex, "run_command", command="echo hi").ok)
        self.assertEqual(self.asked, [])
        victim = self.put("victim/x.txt")
        r = self.run_tool(ex, "run_command", command="rm -rf victim")
        self.assertFalse(r.ok)
        self.assertTrue(victim.exists())
        self.assertTrue(self.asked[0].dangerous)

    def test_always_allow_skips_later_prompts_for_safe_programs(self):
        ex = self.make("ask", lambda r: Decision(True, remember=True))
        self.assertTrue(self.run_tool(ex, "run_command", command="echo one").ok)
        self.assertTrue(self.run_tool(ex, "run_command", command="echo two").ok)
        self.assertEqual(len(self.asked), 1)

    def test_no_approver_means_no(self):
        ex = ToolExecutor(self.reg, PermissionPolicy("ask", self.reg.ctx.sandbox), None)
        self.addCleanup(self.reg.ctx.close)
        r = asyncio.run(ex.run("run_command", {"command": "echo hi"}))
        self.assertFalse(r.ok)
        self.assertIn("denied", r.output)

    def test_async_approver_and_validation_errors(self):
        async def approver(req):
            await asyncio.sleep(0)
            return Decision(True)
        ex = ToolExecutor(self.reg, PermissionPolicy("ask", self.reg.ctx.sandbox), approver)
        self.addCleanup(self.reg.ctx.close)
        self.assertTrue(asyncio.run(ex.run("run_command", {"command": "echo hi"})).ok)
        r = asyncio.run(ex.run("run_command", {}))
        self.assertFalse(r.ok)
        self.assertIn("Missing required", r.output)
        self.assertIn("Unknown argument", asyncio.run(ex.run("run_command", {"command": "x", "nope": 1})).output)
        self.assertIn("Unknown tool", asyncio.run(ex.run("hack", {})).output)

    def test_cancel_stops_a_running_command(self):
        ex = self.make("auto", lambda r: Decision(True))
        async def scenario():
            task = asyncio.create_task(ex.run("run_command", {"command": "sleep 30"}))
            await asyncio.sleep(0.5)
            ex.cancel()
            return await asyncio.wait_for(task, 6)
        r = asyncio.run(scenario())
        self.assertFalse(r.ok)
        self.assertTrue(r.meta["cancelled"])

    def test_delete_and_move_go_through_confirmation(self):
        self.put("d/a.txt")
        ex = self.make("ask", lambda r: Decision(True))
        r = self.run_tool(ex, "delete_file", path="d", recursive=True)
        self.assertTrue(r.ok, r.output)
        self.assertFalse((self.ws / "d").exists())
        self.assertIn("Delete directory d", self.asked[0].detail)


class TerminalApproverTests(unittest.TestCase):
    def ask(self, answers, **kw):
        it = iter(answers)
        req = ApprovalRequest("run_command", "exec", "Run command", "echo hi", can_remember=True, **kw)
        lines = []
        return terminal_approver(req, input_fn=lambda p: next(it), out=lines.append), lines

    def test_answers(self):
        self.assertEqual(self.ask(["y"])[0], Decision(True))
        self.assertEqual(self.ask(["a"])[0], Decision(True, remember=True))
        self.assertEqual(self.ask(["n"])[0].allowed, False)
        self.assertEqual(self.ask(["maybe", "yes"])[0], Decision(True))
        self.assertFalse(self.ask(["x", "x", "x"])[0].allowed)

    def test_eof_denies_and_danger_is_shown(self):
        def eof(_):
            raise EOFError
        req = ApprovalRequest("run_command", "exec", "Run command", "rm -rf x",
                              reasons=("deletes",), dangerous=True)
        lines = []
        self.assertFalse(terminal_approver(req, input_fn=eof, out=lines.append).allowed)
        self.assertIn("DANGEROUS", "\n".join(lines))
        # "always" is not offered for dangerous requests
        it = iter(["a", "n"])
        self.assertFalse(terminal_approver(req, input_fn=lambda p: next(it), out=lambda s: None).allowed)


if __name__ == "__main__":
    unittest.main()
