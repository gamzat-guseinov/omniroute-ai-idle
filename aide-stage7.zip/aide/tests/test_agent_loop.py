import asyncio
import json
import sys
import unittest
from contextlib import aclosing

from aide.agent.context import ContextManager, heuristic_summary
from aide.agent.conversation import Conversation, Msg, native_tool_call
from aide.agent.events import (AssistantMessage, Failed, Notice, TextChunk, ToolEnd, ToolStart,
                               TurnEnd, UsageUpdate)
from aide.agent.executor import ToolExecutor
from aide.agent.loop import AgentLoop, tool_instructions
from aide.agent.loopguard import LoopGuard
from aide.agent.permissions import Decision, PermissionPolicy
from aide.agent.prompt import build_system_prompt, default_template, load_template
from aide.client.errors import BadRequestError, ContextOverflowError, NetworkError
from aide.client.events import Done, TextDelta, Usage
from aide.formats.model import ToolCall
from aide.tools.base import ToolResult

from .fakes import FakeClient, native, text
from .helpers import WorkspaceTestCase


class LoopTestCase(WorkspaceTestCase):
    def make(self, script, mode="auto", approver=None, **kw):
        self.client = FakeClient(script)
        policy = PermissionPolicy(mode, self.reg.ctx.sandbox)
        executor = ToolExecutor(self.reg, policy, approver or (lambda r: Decision(True)))
        self.conv = Conversation("SYSTEM")
        self.loop = AgentLoop(self.client, executor, self.conv, **kw)
        self.addCleanup(self.reg.ctx.close)
        return self.loop

    def run_loop(self, user="do it"):
        async def go():
            events = []
            async with aclosing(self.loop.run(user)) as stream:
                async for ev in stream:
                    events.append(ev)
            return events
        return asyncio.run(go())

    @staticmethod
    def kinds(events, cls):
        return [e for e in events if isinstance(e, cls)]


class BasicLoopTests(LoopTestCase):
    def test_plain_answer_streams_and_ends(self):
        self.make([text("Hello there, friend!")])
        events = self.run_loop("hi")
        self.assertEqual("".join(e.text for e in self.kinds(events, TextChunk)), "Hello there, friend!")
        self.assertEqual(self.kinds(events, AssistantMessage)[0].text, "Hello there, friend!")
        self.assertEqual(events[-1], TurnEnd("done"))
        self.assertEqual([m.role for m in self.conv.messages], ["user", "assistant"])
        self.assertIsNotNone(self.client.requests[0]["tools"])      # native mode sends schemas

    def test_native_tool_round_trip_updates_history_correctly(self):
        self.put("a.txt", "hello\n")
        self.make([native(("read_file", {"path": "a.txt"}), text_before="Reading."),
                   text("The file says hello.")])
        events = self.run_loop("what is in a.txt?")
        end = self.kinds(events, ToolEnd)[0]
        self.assertTrue(end.result.ok)
        self.assertIn("hello", end.result.output)
        roles = [m.role for m in self.conv.messages]
        self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])
        assistant = self.conv.messages[1]
        self.assertEqual(assistant.tool_calls[0]["function"]["name"], "read_file")
        self.assertEqual(json.loads(assistant.tool_calls[0]["function"]["arguments"]), {"path": "a.txt"})
        self.assertEqual(self.conv.messages[2].tool_call_id, "call_0")
        # second request carries the tool result
        second = self.client.requests[1]["messages"]
        self.assertEqual(second[-1]["role"], "tool")
        self.assertIn("hello", second[-1]["content"])

    def test_parallel_calls_run_in_order_and_all_get_results(self):
        self.put("a.txt", "A")
        self.put("b.txt", "B")
        self.make([native(("read_file", {"path": "a.txt"}), ("read_file", {"path": "b.txt"})), text("ok")])
        events = self.run_loop()
        self.assertEqual([e.call.arguments["path"] for e in self.kinds(events, ToolStart)], ["a.txt", "b.txt"])
        self.assertEqual([m.role for m in self.conv.messages], ["user", "assistant", "tool", "tool", "assistant"])

    def test_usage_and_notices_are_forwarded(self):
        self.make([[TextDelta("hi"), Usage(10, 2, 12), Done("stop")]])
        self.assertEqual(self.kinds(self.run_loop(), UsageUpdate)[0].usage.prompt_tokens, 10)

    def test_the_demo_scenario_create_run_fail_fix_verify(self):
        """The Definition of Done flow, with a scripted model: write, run, read the error, fix, re-run."""
        code = "def greet():\n    return 'hello'\nprint(greet(\n"       # syntax error on purpose
        fixed = "def greet():\n    return 'hello'\nprint(greet())\n"
        run = {"command": f"{sys.executable} app.py"}
        self.make([
            text("Plan: create app.py, run it.\n", finish="stop")[:-1] + native(("write_file", {"path": "app.py", "content": code}))[:-1] + [Done("tool_calls")],
            native(("run_command", run)),
            native(("edit_file", {"path": "app.py", "old_text": "print(greet(\n", "new_text": "print(greet())\n"})),
            native(("run_command", run)),
            text("Fixed the missing parenthesis; the script prints hello."),
        ])
        events = self.run_loop("create a hello script and run it")
        ends = self.kinds(events, ToolEnd)
        self.assertEqual([e.call.name for e in ends], ["write_file", "run_command", "edit_file", "run_command"])
        self.assertFalse(ends[1].result.ok)
        self.assertIn("SyntaxError", ends[1].result.output)
        self.assertTrue(ends[3].result.ok)
        self.assertIn("hello", ends[3].result.output)
        self.assertEqual((self.ws / "app.py").read_text(), fixed)
        self.assertEqual(events[-1], TurnEnd("done"))
        # the model saw the error before fixing it
        third_request = self.client.requests[2]["messages"]
        self.assertIn("SyntaxError", third_request[-1]["content"])
        self.assertTrue(third_request[-1]["content"].startswith("ERROR:"))


class TextFormatTests(LoopTestCase):
    def test_dsml_calls_in_text_are_executed_and_markup_never_displayed(self):
        self.put("a.txt", "from file")
        dsml = ('Let me check.\n<｜DSML｜function_calls>\n<｜DSML｜invoke name="read_file">\n'
                '<｜DSML｜parameter name="path" string="true">a.txt</｜DSML｜parameter>\n'
                '</｜DSML｜invoke>\n</｜DSML｜function_calls>')
        self.make([text(dsml, chunk=5), text("It says: from file")], tool_format="dsml")
        events = self.run_loop()
        shown = "".join(e.text for e in self.kinds(events, TextChunk))
        self.assertNotIn("DSML", shown)
        self.assertIn("Let me check.", shown)
        self.assertEqual(self.kinds(events, ToolEnd)[0].call.source, "dsml")
        self.assertIsNone(self.client.requests[0]["tools"])          # not native: no schemas sent
        # history: raw assistant markup + results as a user message
        self.assertIn("DSML", self.conv.messages[1].content)
        self.assertEqual(self.conv.messages[2].role, "user")
        self.assertIn('<tool_response id=', self.conv.messages[2].content)
        self.assertIn("from file", self.conv.messages[2].content)

    def test_text_calls_work_even_when_native_mode_is_configured(self):
        self.put("a.txt", "x")
        self.make([text('<tool_call>{"name": "read_file", "arguments": {"path": "a.txt"}}</tool_call>'),
                   text("done")])
        events = self.run_loop()
        self.assertTrue(self.kinds(events, ToolEnd)[0].result.ok)
        self.assertEqual(events[-1], TurnEnd("done"))

    def test_unreadable_call_makes_the_model_retry_then_gives_up(self):
        bad = text('<tool_call>{"oops": nope</tool_call>')
        self.make([bad, bad, bad])
        events = self.run_loop()
        self.assertEqual(len(self.kinds(events, Notice)), 2)
        self.assertEqual(self.kinds(events, Failed)[0].message[:25], "The model keeps sending t")
        self.assertEqual(events[-1], TurnEnd("error"))
        self.assertIn("could not be understood", self.client.requests[1]["messages"][-1]["content"])

    def test_cut_off_call_is_not_executed(self):
        cut = text('<tool_call>{"name": "write_file", "arguments": {"path": "big.txt", "content": "half', finish="length")
        self.make([cut, text("I will write it in parts.")])
        events = self.run_loop()
        self.assertFalse((self.ws / "big.txt").exists())
        end = self.kinds(events, ToolEnd)[0]
        self.assertFalse(end.result.ok)
        self.assertIn("cut off", end.result.output)

    def test_native_unsupported_falls_back_to_xml(self):
        self.put("a.txt", "x")
        err = BadRequestError("rejected", status=400, detail="tools is not supported by this model")
        self.make([err, text('<tool_call>{"name": "read_file", "arguments": {"path": "a.txt"}}</tool_call>'),
                   text("done")], build_prompt=lambda fmt: f"PROMPT[{fmt}]")
        events = self.run_loop()
        self.assertEqual(self.loop.tool_format, "xml")
        self.assertTrue(any("switching to XML" in n.text for n in self.kinds(events, Notice)))
        self.assertEqual(self.client.requests[1]["messages"][0]["content"], "PROMPT[xml]")
        self.assertIsNone(self.client.requests[1]["tools"])
        self.assertEqual(events[-1], TurnEnd("done"))


class GuardTests(LoopTestCase):
    def test_limit_pauses_the_turn_and_can_continue(self):
        self.put("a.txt", "x")
        calls = [native(("read_file", {"path": "a.txt", "start_line": i})) for i in range(1, 4)]
        self.make(calls + [text("continuing")], max_tool_calls=2)
        events = self.run_loop()
        self.assertEqual(events[-1], TurnEnd("limit"))
        self.assertEqual(len(self.kinds(events, ToolEnd)), 2)
        self.assertEqual([m.role for m in self.conv.messages][-1], "tool")      # history still valid
        self.client.script = [text("ok, resumed")]
        events = self.run_loop("continue")
        self.assertEqual(events[-1], TurnEnd("done"))

    def test_skipped_calls_after_the_limit_still_get_results(self):
        self.put("a.txt", "x")
        self.make([native(("read_file", {"path": "a.txt"}), ("read_file", {"path": "a.txt", "start_line": 1}),
                          ("read_file", {"path": "a.txt", "start_line": 2}))], max_tool_calls=1)
        events = self.run_loop()
        ends = self.kinds(events, ToolEnd)
        self.assertEqual([e.result.ok for e in ends], [True, False, False])
        self.assertIn("limit", ends[1].result.output)
        self.assertEqual([m.role for m in self.conv.messages].count("tool"), 3)

    def test_identical_failing_call_is_blocked_and_loop_aborts(self):
        bad = native(("read_file", {"path": "missing.txt"}))
        self.make([bad] * 8 + [text("never reached")])
        events = self.run_loop()
        ends = self.kinds(events, ToolEnd)
        self.assertIn("does not exist", ends[0].result.output)
        self.assertIn("exact call", ends[2].result.output)       # third identical attempt is vetoed
        self.assertEqual(events[-1], TurnEnd("loop"))
        self.assertTrue(any("repeating" in n.text for n in self.kinds(events, Notice)))

    def test_guard_unit(self):
        g = LoopGuard(max_calls=3)
        call = ToolCall("read_file", {"path": "x"}, "1")
        fail = ToolResult(False, "boom\nmore")
        self.assertIsNone(g.before(call))
        g.after(call, fail)
        g.after(call, fail)
        self.assertIn("boom", g.before(call))
        self.assertEqual(g.strikes, 1)
        self.assertFalse(g.exhausted)
        g.after(call, ToolResult(True, "ok"))
        self.assertTrue(g.exhausted)
        g.reset()
        self.assertEqual((g.calls, g.strikes), (0, 0))
        ok = ToolCall("search", {"pattern": "a"}, "2")
        for _ in range(3):
            g.after(ok, ToolResult(True, "found"))
        self.assertIn("several times", g.before(ok))


class RobustnessTests(LoopTestCase):
    def test_denied_action_is_reported_and_nothing_changes(self):
        self.make([native(("write_file", {"path": "x.txt", "content": "data"})), text("Okay, I will not write it.")],
                  mode="ask", approver=lambda r: Decision(False, message="no files please"))
        events = self.run_loop()
        end = self.kinds(events, ToolEnd)[0]
        self.assertTrue(end.result.meta["denied"])
        self.assertFalse((self.ws / "x.txt").exists())
        self.assertIn("no files please", self.client.requests[1]["messages"][-1]["content"])

    def test_network_error_is_reported_not_raised(self):
        self.make([NetworkError("Cannot reach host.", detail="refused")])
        events = self.run_loop()
        self.assertIn("Cannot reach host", self.kinds(events, Failed)[0].message)
        self.assertEqual(events[-1], TurnEnd("error"))

    def test_context_overflow_trims_and_retries(self):
        self.make([text("a"), text("b"), ContextOverflowError("too long", status=400), text("answer after trimming")],
                  context_tokens=100_000)
        self.run_loop("first question " * 50)
        self.run_loop("second question " * 50)
        events = self.run_loop("third")
        self.assertEqual(events[-1], TurnEnd("done"))
        self.assertTrue(any("too long" in n.text for n in self.kinds(events, Notice)))
        self.assertEqual(len(self.client.requests), 4)

    def test_overflow_that_never_ends_fails_gracefully(self):
        err = ContextOverflowError("too long", status=400)
        self.make([err, err, err])
        events = self.run_loop()
        self.assertIn("/clear", self.kinds(events, Failed)[0].message)
        self.assertEqual(events[-1], TurnEnd("error"))

    def test_cancellation_leaves_a_valid_history(self):
        self.put("a.txt", "x")
        self.make([native(("read_file", {"path": "a.txt"}), ("run_command", {"command": "sleep 30"}))], mode="auto")
        async def go():
            seen = []
            async def consume():
                async with aclosing(self.loop.run("go")) as stream:
                    async for ev in stream:
                        seen.append(ev)
            task = asyncio.create_task(consume())
            while not any(isinstance(e, ToolStart) and e.call.name == "run_command" for e in seen):
                await asyncio.sleep(0.05)
            self.loop.executor.cancel()
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        asyncio.run(go())
        assistant = next(m for m in self.conv.messages if m.role == "assistant")
        answered = {m.tool_call_id for m in self.conv.messages if m.role == "tool"}
        self.assertEqual({tc["id"] for tc in assistant.tool_calls}, answered)

    def test_summary_requests_use_no_tools(self):
        self.put("a.txt", "x")
        self.make([text("one " * 800), text("two " * 800), text("SUMMARY of the early part"), text("final")],
                  context_tokens=2500, max_tokens=500)
        self.run_loop("question one " * 40)
        self.run_loop("question two " * 40)
        events = self.run_loop("question three " * 40)
        self.assertEqual(events[-1], TurnEnd("done"))
        summary_request = next(r for r in self.client.requests if r["max_tokens"] == 700)
        self.assertIsNone(summary_request["tools"])
        self.assertIn("SUMMARY of the early part", self.conv.summary)
        self.assertIn("SUMMARY of the early part", self.client.requests[-1]["messages"][0]["content"])


class ContextTests(unittest.TestCase):
    def conv_with_turns(self, n, result_size=5000):
        conv = Conversation("SYS")
        for i in range(n):
            conv.add_user(f"request {i}")
            conv.add_assistant("calling", [native_tool_call(f"c{i}", "read_file", {"path": f"f{i}.py"})])
            conv.add_tool_result(f"c{i}", "x" * result_size)
            conv.add_assistant(f"done {i}")
        return conv

    def prepare(self, conv, budget, **kw):
        return asyncio.run(ContextManager(budget, reserve_output=200).prepare(conv, **kw))

    def test_nothing_happens_when_it_fits(self):
        conv = self.conv_with_turns(2, 100)
        self.assertIsNone(self.prepare(conv, 100_000))
        self.assertEqual(len(conv.messages), 8)

    def test_old_tool_output_is_shortened_first_and_pairs_stay_intact(self):
        conv = self.conv_with_turns(5)
        note = self.prepare(conv, 6000)
        self.assertIn("shortened old tool output", note)
        self.assertEqual(len(conv.messages), 20)
        self.assertLess(len(conv.messages[2].content), 700)
        self.assertEqual(len(conv.messages[-2].content), 5000)          # the latest turn is untouched

    def test_oldest_turns_are_summarized_with_the_model(self):
        conv = self.conv_with_turns(6)
        async def summarize(prompt):
            self.assertIn("request 0", prompt)
            return "MODEL SUMMARY"
        note = self.prepare(conv, 1500, summarize=summarize)
        self.assertIn("summarized", note)
        self.assertEqual(conv.summary, "MODEL SUMMARY")
        self.assertEqual(conv.messages[0].kind, "user")
        self.assertLessEqual(len(conv.turns()), 2)
        self.assertIn("MODEL SUMMARY", conv.system_text())

    def test_failing_summarizer_falls_back_to_a_local_summary(self):
        conv = self.conv_with_turns(6)
        async def broken(prompt):
            raise RuntimeError("no network")
        self.prepare(conv, 1500, summarize=broken)
        self.assertIn("The user asked", conv.summary)
        self.assertIn("read_file f0.py", conv.summary)

    def test_very_long_single_turn_is_compacted_without_splitting_tool_pairs(self):
        conv = Conversation("SYS")
        conv.add_user("big task")
        for i in range(12):
            conv.add_assistant("step", [native_tool_call(f"c{i}", "run_command", {"command": f"cmd{i}"})])
            conv.add_tool_result(f"c{i}", "y" * 3000)
        note = self.prepare(conv, 3000)
        self.assertIsNotNone(note)
        pending = set()
        for m in conv.messages:
            if m.role == "assistant":
                pending = {tc["id"] for tc in m.tool_calls or []}
            elif m.role == "tool":
                self.assertIn(m.tool_call_id, pending)       # every result follows its own call
        self.assertNotEqual(conv.messages[0].role, "tool")

    def test_huge_file_contents_inside_old_tool_calls_are_shrunk(self):
        conv = Conversation("SYS")
        conv.add_user("one")
        conv.add_assistant("", [native_tool_call("c", "write_file", {"path": "a", "content": "z" * 20000})])
        conv.add_tool_result("c", "ok")
        conv.add_user("two")
        conv.add_user("three")
        self.prepare(conv, 2500)
        args = json.loads(conv.messages[1].tool_calls[0]["function"]["arguments"])
        self.assertEqual(args["path"], "a")
        self.assertIn("omitted", args["content"])

    def test_calibration_moves_the_estimate_towards_reality(self):
        cm = ContextManager(10_000)
        conv = self.conv_with_turns(2, 3000)
        before = cm.estimate(conv)
        cm.calibrate(conv, before * 2)
        self.assertGreater(cm.estimate(conv), before)
        cm.calibrate(conv, 1)                      # nonsense values are clamped, never crash
        self.assertGreater(cm.scale, 0.4)

    def test_repair_adds_missing_results(self):
        conv = Conversation("S")
        conv.add_user("u")
        conv.add_assistant("", [native_tool_call("a", "x", {}), native_tool_call("b", "y", {})])
        conv.add_tool_result("a", "done")
        conv.repair()
        self.assertEqual([m.tool_call_id for m in conv.messages if m.role == "tool"], ["a", "b"])
        conv.repair()                                                    # idempotent
        self.assertEqual(len(conv.messages), 4)

    def test_heuristic_summary_mentions_requests_and_actions(self):
        msgs = [Msg("user", "fix the bug in app.py", kind="user"),
                Msg("assistant", "on it", tool_calls=[native_tool_call("1", "edit_file", {"path": "app.py"})])]
        text = heuristic_summary("", msgs)
        self.assertIn("fix the bug", text)
        self.assertIn("edit_file app.py", text)


class PromptTests(unittest.TestCase):
    def test_default_template_has_the_required_sections(self):
        t = default_template()
        for needle in ("# Role", "{{workspace}}", "UNDERSTAND", "PLAN", "VERIFY", "run_background",
                       "{{tool_instructions}}", "Ask the user"):
            self.assertIn(needle, t, needle)

    def test_placeholders_are_filled(self):
        text = build_system_prompt(default_template(), workspace="/w/p", mode="ask", tool_instructions="TOOLS!")
        self.assertIn("/w/p", text)
        self.assertIn("TOOLS!", text)
        self.assertNotIn("{{", text)

    def test_customised_prompt_without_placeholder_still_gets_tool_instructions(self):
        text = build_system_prompt("Be brief. Workspace {{workspace}}", workspace="/w", mode="ask",
                                   tool_instructions="TOOLS!")
        self.assertTrue(text.endswith("TOOLS!"))
        self.assertIn("{ and } are safe", build_system_prompt("{ and } are safe", workspace="/w", mode="ask"))

    def test_editable_file_is_created_once_and_user_edits_win(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "cfg" / "system_prompt.md"
            text, p = load_template(path)
            self.assertEqual((text, p), (default_template(), path))
            self.assertTrue(path.exists())
            path.write_text("My own prompt for {{workspace}}")
            self.assertEqual(load_template(path)[0], "My own prompt for {{workspace}}")
            path.write_text("   ")                                   # empty file -> default
            self.assertEqual(load_template(path)[0], default_template())

    def test_tool_instructions_for_the_registry(self):
        from aide.tools import create_registry
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            reg = create_registry(tmp)
            self.addCleanup(reg.ctx.close)
            self.assertEqual(tool_instructions(reg, "native"), "")
            self.assertIn("run_background", tool_instructions(reg, "xml"))


if __name__ == "__main__":
    unittest.main()
