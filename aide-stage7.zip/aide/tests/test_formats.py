import json
import unittest

from aide.client.events import ToolCallDelta
from aide.formats import (NativeCallBuilder, StreamFilter, describe_tools, detect_format,
                          format_tool_responses, parse_response)
from aide.formats.dsml_fmt import normalize_dsml
from aide.formats.json_fmt import arguments_to_dict, loads_loose, repair_json

KNOWN = {"read_file", "write_file", "edit_file", "run_command", "search"}


def parse(text, **kw):
    return parse_response(text, known=KNOWN, **kw)


def only(turn):
    assert len(turn.calls) == 1, turn
    return turn.calls[0]


# --------------------------------------------------------------------------- DSML
DSML_ONE = ('<｜DSML｜function_calls>\n<｜DSML｜invoke name="read_file">\n'
            '<｜DSML｜parameter name="path" string="true">src/app.py</｜DSML｜parameter>\n'
            '<｜DSML｜parameter name="start_line" string="false">5</｜DSML｜parameter>\n'
            '</｜DSML｜invoke>\n</｜DSML｜function_calls>')


class DsmlTests(unittest.TestCase):
    def test_single_call_with_typed_parameters(self):
        t = parse("Let me look at it.\n" + DSML_ONE)
        c = only(t)
        self.assertEqual((c.name, c.arguments, c.source, c.complete),
                         ("read_file", {"path": "src/app.py", "start_line": 5}, "dsml", True))
        self.assertEqual((t.text, t.format), ("Let me look at it.", "dsml"))

    def test_multiple_invokes_in_one_block(self):
        text = ('<｜DSML｜function_calls>'
                '<｜DSML｜invoke name="read_file"><｜DSML｜parameter name="path" string="true">a.py</｜DSML｜parameter></｜DSML｜invoke>'
                '<｜DSML｜invoke name="search"><｜DSML｜parameter name="pattern" string="true">TODO</｜DSML｜parameter>'
                '<｜DSML｜parameter name="literal" string="false">true</｜DSML｜parameter></｜DSML｜invoke>'
                '</｜DSML｜function_calls>')
        calls = parse(text).calls
        self.assertEqual([c.name for c in calls], ["read_file", "search"])
        self.assertEqual(calls[1].arguments, {"pattern": "TODO", "literal": True})

    def test_ascii_bar_and_other_marker_variants(self):
        for marker in ("|DSML|", "｜DSML｜", "DSML|", "DSML:", "｜dsml｜"):
            text = (f'<{marker}function_calls><{marker}invoke name="run_command">'
                    f'<{marker}parameter name="command" string="true">ls</{marker}parameter>'
                    f'</{marker}invoke></{marker}function_calls>')
            self.assertEqual(only(parse(text)).arguments, {"command": "ls"}, marker)

    def test_json_and_list_values(self):
        text = DSML_ONE.replace('string="false">5', 'string="false">{"a": [1, 2]}')
        self.assertEqual(only(parse(text)).arguments["start_line"], {"a": [1, 2]})

    def test_string_false_with_invalid_json_stays_text(self):
        text = DSML_ONE.replace('string="false">5', 'string="false">not json')
        self.assertEqual(only(parse(text)).arguments["start_line"], "not json")

    def test_code_content_survives_untouched(self):
        code = 'if a < b && c > d:\n    print("<tag>&amp;")\n'
        text = ('<｜DSML｜function_calls><｜DSML｜invoke name="write_file">'
                '<｜DSML｜parameter name="path" string="true">x.py</｜DSML｜parameter>'
                f'<｜DSML｜parameter name="content" string="true">{code}</｜DSML｜parameter>'
                '</｜DSML｜invoke></｜DSML｜function_calls>')
        self.assertEqual(only(parse(text)).arguments["content"], code)

    def test_unclosed_markup_is_tolerated_but_marked_incomplete(self):
        text = DSML_ONE.split("</｜DSML｜parameter>\n<｜DSML｜parameter")[0]
        c = only(parse(text))
        self.assertEqual(c.arguments["path"], "src/app.py")
        self.assertFalse(c.complete)

    def test_normalize_helper(self):
        self.assertEqual(normalize_dsml("<｜DSML｜a>x</｜DSML｜a>"), ("<a>x</a>", True))
        self.assertEqual(normalize_dsml("no markup"), ("no markup", False))


# --------------------------------------------------------------------------- XML
class XmlTests(unittest.TestCase):
    def test_hermes_json_in_tool_call_tags(self):
        c = only(parse('<tool_call>\n{"name": "read_file", "arguments": {"path": "a.py"}}\n</tool_call>'))
        self.assertEqual((c.name, c.arguments, c.source, c.complete), ("read_file", {"path": "a.py"}, "xml", True))

    def test_several_tool_call_blocks_with_text_between(self):
        text = ('First.\n<tool_call>{"name": "read_file", "arguments": {"path": "a"}}</tool_call>\n'
                'then\n<tool_call>{"name": "read_file", "arguments": {"path": "b"}}</tool_call>')
        t = parse(text)
        self.assertEqual([c.arguments["path"] for c in t.calls], ["a", "b"])
        self.assertIn("First.", t.text)
        self.assertNotIn("tool_call", t.text)

    def test_several_json_objects_in_one_block(self):
        t = parse('<tool_call>{"name":"read_file","arguments":{"path":"a"}}\n{"name":"read_file","arguments":{"path":"b"}}</tool_call>')
        self.assertEqual(len(t.calls), 2)

    def test_qwen_function_parameter_form(self):
        text = ('<tool_call>\n<function=write_file>\n<parameter=path>\nhello.py\n</parameter>\n'
                '<parameter=content>\nprint("hi")\nprint("there")\n</parameter>\n</function>\n</tool_call>')
        c = only(parse(text))
        self.assertEqual(c.arguments, {"path": "hello.py", "content": 'print("hi")\nprint("there")'})

    def test_claude_style_invoke(self):
        text = ('<function_calls>\n<invoke name="run_command">\n<parameter name="command">ls -la</parameter>\n'
                '</invoke>\n</function_calls>')
        self.assertEqual(only(parse(text)).arguments, {"command": "ls -la"})

    def test_invoke_without_wrapper(self):
        c = only(parse('<invoke name="read_file"><parameter name="path">x</parameter></invoke>'))
        self.assertEqual(c.arguments, {"path": "x"})

    def test_tag_per_tool_style(self):
        t = parse("Reading.\n<read_file>\n<path>src/a.py</path>\n<start_line>3</start_line>\n</read_file>")
        self.assertEqual(only(t).arguments, {"path": "src/a.py", "start_line": "3"})
        self.assertEqual(t.text, "Reading.")

    def test_name_and_arguments_tags(self):
        t = parse('<tool_call><name>read_file</name><arguments>{"path": "a"}</arguments></tool_call>')
        self.assertEqual(only(t).arguments, {"path": "a"})

    def test_quote_variants_and_whitespace(self):
        t = parse("<function_calls><invoke name='read_file'><parameter name=path>a.py</parameter></invoke></function_calls>")
        self.assertEqual(only(t).arguments, {"path": "a.py"})

    def test_broken_markup_cases(self):
        # unclosed block, missing closing braces
        c = only(parse('<tool_call>{"name": "run_command", "arguments": {"command": "ls"'))
        self.assertEqual(c.arguments, {"command": "ls"})
        self.assertFalse(c.complete)
        # trailing comma
        self.assertEqual(only(parse('<tool_call>{"name": "read_file", "arguments": {"path": "a",},}</tool_call>')).arguments, {"path": "a"})
        # missing </parameter> and </invoke>
        c = only(parse('<function_calls><invoke name="read_file"><parameter name="path">a.py'))
        self.assertEqual(c.arguments, {"path": "a.py"})
        self.assertFalse(c.complete)

    def test_unreadable_call_is_reported_as_a_problem(self):
        t = parse('<tool_call>{"this": is not valid at all</tool_call>')
        self.assertEqual(t.calls, [])
        self.assertEqual(len(t.problems), 1)

    def test_prose_mentioning_a_tag_is_left_alone(self):
        t = parse("Use the <tool_call> tag to call tools.")
        self.assertEqual((t.calls, t.problems, t.text), ([], [], "Use the <tool_call> tag to call tools."))

    def test_values_are_not_xml_unescaped(self):
        t = parse('<function_calls><invoke name="write_file"><parameter name="path">a.html</parameter>'
                  '<parameter name="content"><p>&amp; hi</p></parameter></invoke></function_calls>')
        self.assertEqual(only(t).arguments["content"], "<p>&amp; hi</p>")

    def test_detect_format(self):
        self.assertEqual(detect_format(DSML_ONE), "dsml")
        self.assertEqual(detect_format('<tool_call>{"name":"x","arguments":{}}</tool_call>'), "xml")
        self.assertIsNone(detect_format("just words"))


# --------------------------------------------------------------------------- JSON
class JsonTests(unittest.TestCase):
    def test_fenced_json_call_with_text(self):
        t = parse('I will read it.\n```json\n{"name": "read_file", "arguments": {"path": "x"}}\n```')
        self.assertEqual((only(t).arguments, t.format, t.text), ({"path": "x"}, "json", "I will read it."))

    def test_alternative_key_names_and_openai_shape(self):
        for obj in ({"tool": "read_file", "args": {"path": "x"}},
                    {"function": {"name": "read_file", "arguments": '{"path": "x"}'}},
                    {"tool_name": "read_file", "parameters": {"path": "x"}},
                    {"tool_calls": [{"type": "function", "function": {"name": "read_file", "arguments": {"path": "x"}}}]}):
            self.assertEqual(only(parse(json.dumps(obj))).arguments, {"path": "x"}, obj)

    def test_bare_json_array_of_calls(self):
        calls = parse('[{"name": "read_file", "arguments": {"path": "a"}}, {"name": "search", "arguments": {"pattern": "x"}}]').calls
        self.assertEqual([c.name for c in calls], ["read_file", "search"])

    def test_example_json_for_unknown_tools_is_not_a_call(self):
        t = parse('Config looks like:\n```json\n{"name": "my-app", "arguments": {"debug": true}}\n```')
        self.assertEqual(t.calls, [])
        self.assertIn("my-app", t.text)

    def test_trailing_commas_single_quotes_and_truncation(self):
        self.assertEqual(only(parse('```json\n{"name": "read_file", "arguments": {"path": "a",},}\n```')).arguments, {"path": "a"})
        self.assertEqual(only(parse("```json\n{'name': 'read_file', 'arguments': {'path': 'a'}}\n```")).arguments, {"path": "a"})
        c = only(parse('```json\n{"name": "read_file", "arguments": {"path": "a"\n```'))
        self.assertEqual(c.arguments, {"path": "a"})
        self.assertFalse(c.complete)

    def test_plain_text_is_not_json(self):
        t = parse("Everything is fine. {not json}")
        self.assertEqual((t.calls, t.format), ([], None))

    def test_loose_parsing_helpers(self):
        self.assertEqual(loads_loose('```json\n{"a": 1}\n```'), ({"a": 1}, True))
        self.assertEqual(loads_loose('Sure: {"a": 1} hope that helps'), ({"a": 1}, False))
        self.assertEqual(json.loads(repair_json('{"a": [1, 2,')), {"a": [1, 2]})
        self.assertEqual(json.loads(repair_json('{"a": "unterminated')), {"a": "unterminated"})
        self.assertEqual(arguments_to_dict('"{\\"a\\": 1}"')[0], {"a": 1})   # double encoded
        self.assertEqual(arguments_to_dict("")[0], {})
        self.assertIn("object", arguments_to_dict("[1, 2]")[2])
        self.assertIn("not valid", arguments_to_dict("???")[2])


# --------------------------------------------------------------------------- native + truncation
class NativeTests(unittest.TestCase):
    def build(self, *deltas):
        b = NativeCallBuilder()
        for d in deltas:
            b.feed(d)
        return b.build()

    def test_fragments_are_joined_and_parallel_calls_kept_apart(self):
        calls = self.build(
            ToolCallDelta(0, "c1", "read_file", ""), ToolCallDelta(0, None, None, '{"pa'),
            ToolCallDelta(0, None, None, 'th": "a"}'),
            ToolCallDelta(1, "c2", "search", '{"pattern": "x"}'))
        self.assertEqual([(c.id, c.name, c.arguments) for c in calls],
                         [("c1", "read_file", {"path": "a"}), ("c2", "search", {"pattern": "x"})])

    def test_gateway_that_reuses_index_zero(self):
        calls = self.build(ToolCallDelta(0, "a", "read_file", '{"path": "1"}'),
                           ToolCallDelta(0, "b", "read_file", '{"path": "2"}'))
        self.assertEqual([c.arguments["path"] for c in calls], ["1", "2"])

    def test_name_repeated_in_every_fragment_is_not_duplicated(self):
        calls = self.build(ToolCallDelta(0, "a", "read_file", '{"path"'), ToolCallDelta(0, None, "read_file", ': "x"}'))
        self.assertEqual((calls[0].name, calls[0].arguments), ("read_file", {"path": "x"}))

    def test_bad_arguments_become_errors_not_exceptions(self):
        c = self.build(ToolCallDelta(0, "a", "read_file", "{{{"))[0]
        self.assertTrue(c.error)

    def test_native_wins_over_markup_in_text(self):
        native = self.build(ToolCallDelta(0, "a", "read_file", '{"path": "n"}'))
        t = parse_response("text " + DSML_ONE, native, KNOWN)
        self.assertEqual((only(t).arguments, t.format), ({"path": "n"}, "native"))

    def test_truncated_reply_rejects_guessed_calls_but_keeps_complete_ones(self):
        cut = parse('<tool_call>{"name": "write_file", "arguments": {"path": "a", "content": "half', truncated=True)
        self.assertIn("cut off", only(cut).error)
        done = parse('<tool_call>{"name": "read_file", "arguments": {"path": "a"}}</tool_call>', truncated=True)
        self.assertEqual(only(done).error, "")
        native = self.build(ToolCallDelta(0, "a", "write_file", '{"path": "a", "content": "ha'))
        self.assertIn("cut off", parse_response("", native, KNOWN, truncated=True).calls[0].error)

    def test_ids_are_assigned(self):
        calls = parse('<tool_call>{"name":"read_file","arguments":{}}</tool_call><tool_call>{"name":"read_file","arguments":{}}</tool_call>').calls
        self.assertEqual(len({c.id for c in calls}), 2)


# --------------------------------------------------------------------------- streaming + describe
class StreamFilterTests(unittest.TestCase):
    def run_filter(self, chunks, known=KNOWN):
        f = StreamFilter(known)
        shown = [f.feed(c) for c in chunks]
        shown.append(f.finish())
        return "".join(shown), f

    def test_plain_text_passes_through_unchanged(self):
        text, f = self.run_filter(["Hello ", "wor", "ld! a < b ", "and x <y"])
        self.assertEqual(text, "Hello world! a < b and x <y")
        self.assertFalse(f.saw_markup)

    def test_markup_is_hidden_even_when_split_across_chunks(self):
        for chunks in (["Sure.\n<tool_call>{...}</tool_call>"],
                       ["Sure.\n<tool", "_call>{...}"],
                       ["Sure.\n<", "t", "o", "o", "l_call>x"],
                       ["Sure.\n<｜DS", "ML｜function_calls>..."],
                       ["Sure.\n<function_calls", "><invoke name=\"x\">"],
                       ["Sure.\n<read_f", "ile><path>a</path>"]):
            text, f = self.run_filter(chunks)
            self.assertEqual(text, "Sure.\n", chunks)
            self.assertTrue(f.saw_markup)
            self.assertEqual(f.text, "".join(chunks))

    def test_text_after_markup_is_not_streamed(self):
        text, _ = self.run_filter(["a<tool_call>x</tool_call>", " trailing text"])
        self.assertEqual(text, "a")

    def test_lookalike_prefix_is_released_when_it_turns_out_to_be_text(self):
        text, _ = self.run_filter(["use <tool", "bar> here"])
        self.assertEqual(text, "use <toolbar> here")

    def test_held_back_prefix_is_released_at_the_end(self):
        text, _ = self.run_filter(["done <tool_c"])
        self.assertEqual(text, "done <tool_c")


class DescribeTests(unittest.TestCase):
    SCHEMAS = [{"type": "function", "function": {
        "name": "read_file", "description": "Read a file.",
        "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "File."}},
                       "required": ["path"]}}}]

    def test_each_format_and_round_trip(self):
        self.assertEqual(describe_tools(self.SCHEMAS, "native"), "")
        for fmt in ("json", "xml", "dsml"):
            text = describe_tools(self.SCHEMAS, fmt)
            self.assertIn("read_file", text)
            self.assertIn("path (string, required)", text)
        # the example shown to the model must itself be parseable by our parser
        for fmt in ("json", "xml", "dsml"):
            text = describe_tools(self.SCHEMAS, fmt)
            t = parse_response(text, known=KNOWN)
            self.assertEqual(only(t).arguments.get("path"), "src/app.py", fmt)

    def test_unknown_format(self):
        with self.assertRaises(ValueError):
            describe_tools(self.SCHEMAS, "yaml")

    def test_tool_responses(self):
        out = format_tool_responses([("c1", "read_file", "hello"), ("c2", "search", "ERROR: x")], "xml")
        self.assertIn('<tool_response id="c1" name="read_file">\nhello\n</tool_response>', out)
        self.assertIn("ERROR: x", out)


if __name__ == "__main__":
    unittest.main()
