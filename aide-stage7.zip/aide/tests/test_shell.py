import os
import socket
import sys
import threading
import time
import unittest

from aide.tools import Limits, create_registry
from aide.tools.process import BoundedCapture, child_env, clean_output

from .helpers import WorkspaceTestCase


def _running(pid: int) -> bool:
    try:
        with open(f"/proc/{pid}/stat") as fh:
            return fh.read().rpartition(")")[2].split()[0] != "Z"   # a zombie is already dead
    except OSError:
        return False


def assert_gone(case: unittest.TestCase, pid: int, timeout: float = 3.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _running(pid):
            return
        time.sleep(0.05)
    case.fail(f"process {pid} is still running")


class CleanupTests(unittest.TestCase):
    def test_ansi_carriage_returns_and_control_chars(self):
        self.assertEqual(clean_output("\x1b[31mred\x1b[0m ok"), "red ok")
        self.assertEqual(clean_output("10%\r50%\r100%\ndone\n"), "100%\ndone\n")
        self.assertEqual(clean_output("a\r\nb\x00\x07c"), "a\nbc")

    def test_bounded_capture_keeps_head_and_tail(self):
        cap = BoundedCapture(5, 5)
        for chunk in (b"0123456789", b"abcdefghij", b"KLMNO"):
            cap.feed(chunk)
        text = cap.text()
        self.assertTrue(text.startswith("01234"))
        self.assertTrue(text.endswith("KLMNO"))
        self.assertIn("15 bytes omitted", text)
        small = BoundedCapture(5, 5)
        small.feed(b"abcdefgh")
        self.assertEqual(small.text(), "abcdefgh")

    def test_read_from_reports_dropped_bytes(self):
        cap = BoundedCapture(0, 4)
        cap.feed(b"abcdefgh")
        self.assertEqual(cap.read_from(0), ("efgh", 8, 4))
        self.assertEqual(cap.read_from(6), ("gh", 8, 0))
        cap.feed(b"ij")
        self.assertEqual(cap.read_from(8), ("ij", 10, 0))

    def test_child_env_hides_aide_secrets(self):
        env = child_env({"OMNIROUTE_API_KEY": "s", "AIDE_CONFIG": "x", "BASH_ENV": "y", "KEEP": "1"})
        self.assertEqual(env["KEEP"], "1")
        for gone in ("OMNIROUTE_API_KEY", "AIDE_CONFIG", "BASH_ENV"):
            self.assertNotIn(gone, env)
        self.assertEqual(env["TERM"], "dumb")


class RunCommandTests(WorkspaceTestCase):
    def test_success_and_separate_streams(self):
        r = self.ok("run_command", command="echo out; echo err >&2")
        self.assertIn("exit code: 0", r.output)
        self.assertIn("--- stdout ---\nout", r.output)
        self.assertIn("--- stderr ---\nerr", r.output)
        self.assertEqual(r.meta["exit_code"], 0)

    def test_nonzero_exit_is_a_failed_result_with_details(self):
        r = self.call("run_command", command="echo partial; exit 3")
        self.assertFalse(r.ok)
        self.assertEqual(r.meta["exit_code"], 3)
        self.assertIn("exit code: 3", r.output)
        self.assertIn("partial", r.output)

    def test_command_not_found(self):
        r = self.call("run_command", command="definitely_not_a_command_xyz")
        self.assertFalse(r.ok)
        self.assertEqual(r.meta["exit_code"], 127)
        self.assertIn("not found", r.output)

    def test_runs_in_workspace_and_cwd_is_sandboxed(self):
        self.put("sub/f.txt")
        self.assertIn(str(self.ws), self.ok("run_command", command="pwd").output)
        self.assertIn(str(self.ws / "sub"), self.ok("run_command", command="pwd", cwd="sub").output)
        self.assertIn("outside the workspace", self.fails("run_command", command="pwd", cwd="/tmp"))
        self.assertIn("'..'", self.fails("run_command", command="pwd", cwd=".."))
        self.assertIn("not a directory", self.fails("run_command", command="pwd", cwd="sub/f.txt"))

    def test_timeout_kills_the_whole_process_tree(self):
        pidfile = self.ws / "child.pid"
        t0 = time.monotonic()
        r = self.call("run_command", command=f"sleep 30 & echo $! > {pidfile}; wait", timeout=1)
        self.assertLess(time.monotonic() - t0, 6)
        self.assertFalse(r.ok)
        self.assertTrue(r.meta["timed_out"])
        self.assertIn("TIMED OUT after 1s", r.output)
        assert_gone(self, int(pidfile.read_text()))

    def test_background_children_are_not_left_behind(self):
        pidfile = self.ws / "bg.pid"
        r = self.call("run_command", command=f"sleep 30 & echo $! > {pidfile}; echo started")
        self.assertIn("started", r.output)
        self.assertIn("run_background", r.output)
        assert_gone(self, int(pidfile.read_text()))

    def test_cancel_event_stops_a_running_command(self):
        threading.Timer(0.4, self.reg.ctx.cancel_event.set).start()
        t0 = time.monotonic()
        r = self.call("run_command", command="sleep 30")
        self.assertLess(time.monotonic() - t0, 5)
        self.assertFalse(r.ok)
        self.assertTrue(r.meta["cancelled"])
        self.assertIn("CANCELLED", r.output)

    def test_huge_output_is_bounded_and_keeps_the_end(self):
        r = self.ok("run_command", command=f"{sys.executable} -c \"print('x'*300000); print('THE-END')\"")
        self.assertLess(len(r.output), 14_000)
        self.assertIn("bytes omitted", r.output)
        self.assertIn("THE-END", r.output)

    def test_stdin_is_closed_so_interactive_programs_do_not_hang(self):
        t0 = time.monotonic()
        r = self.ok("run_command", command="cat; echo after-cat")
        self.assertLess(time.monotonic() - t0, 3)
        self.assertIn("after-cat", r.output)

    def test_aide_secrets_are_not_visible_to_commands(self):
        os.environ["OMNIROUTE_API_KEY"] = "sk-super-secret-value"
        self.addCleanup(os.environ.pop, "OMNIROUTE_API_KEY", None)
        r = self.ok("run_command", command="env | grep -c OMNIROUTE || true")
        self.assertIn("0", r.output)
        self.assertNotIn("sk-super-secret-value", r.output)

    def test_ansi_and_progress_output_is_cleaned(self):
        r = self.ok("run_command", command=r"printf '\033[31mred\033[0m\n'; printf 'a\rb\rc\n'")
        self.assertIn("red", r.output)
        self.assertNotIn("\x1b", r.output)
        self.assertIn("\nc", r.output)

    def test_non_utf8_output_does_not_crash(self):
        self.assertIn("exit code: 0", self.ok("run_command", command=r"printf 'caf\xe9\n'").output)

    def test_invalid_commands_are_rejected(self):
        self.assertIn("empty", self.fails("run_command", command="   "))
        self.assertIn("NUL", self.fails("run_command", command="echo a\x00b"))
        self.assertIn("too long", self.fails("run_command", command="x" * 30000))

    def test_before_exec_hook_and_default_timeout(self):
        seen = []
        reg = create_registry(self.ws, before_exec=seen.append, limits=Limits(command_timeout=1))
        self.addCleanup(reg.ctx.close)
        self.assertFalse(reg.execute("run_command", {"command": "sleep 10"}).ok)   # default 1s applies
        self.assertEqual(seen, ["sleep 10"])


class BackgroundTests(WorkspaceTestCase):
    def tearDown(self):
        self.reg.ctx.close()

    def test_lifecycle_start_read_stop(self):
        code = "import time\nprint('ready', flush=True)\ntime.sleep(60)"
        r = self.ok("run_background", command=f"{sys.executable} -c \"{code}\"", name="sleeper")
        self.assertIn("Started bg1", r.output)
        self.assertIn("ready", r.output)
        pid = r.meta["pid"]
        listing = self.ok("read_background").output
        self.assertIn("bg1", listing)
        self.assertIn("running", listing)
        self.assertIn("(no new output)", self.ok("read_background", id="bg1").output)
        stopped = self.ok("stop_background", id="bg1").output
        self.assertIn("Stopped bg1", stopped)
        assert_gone(self, pid)
        self.assertIn("killed by signal", self.ok("read_background").output)

    def test_new_output_is_reported_once(self):
        cmd = "for i in 1 2 3; do echo tick$i; sleep 0.3; done; sleep 30"
        self.ok("run_background", command=cmd, startup_wait=0.1)
        out = self.ok("read_background", id="bg1", wait_seconds=5).output
        self.assertIn("tick", out)
        time.sleep(1.2)
        second = self.ok("read_background", id="bg1").output
        self.assertIn("tick3", second)
        self.assertNotIn("tick1", second)

    def test_process_that_fails_at_startup_is_reported(self):
        r = self.call("run_background", command="echo boom >&2; exit 2")
        self.assertFalse(r.ok)
        self.assertIn("exited with code 2", r.output)
        self.assertIn("boom", r.output)

    def test_unknown_id_and_limit(self):
        self.assertIn("Unknown background process 'bg9'", self.fails("read_background", id="bg9"))
        self.assertIn("Unknown background process", self.fails("stop_background", id="nope"))
        self.assertIn("No background processes", self.ok("read_background").output)
        reg = create_registry(self.ws, limits=Limits(max_background=1))
        self.addCleanup(reg.ctx.close)
        self.assertTrue(reg.execute("run_background", {"command": "sleep 30", "startup_wait": 0}).ok)
        r = reg.execute("run_background", {"command": "sleep 30", "startup_wait": 0})
        self.assertFalse(r.ok)
        self.assertIn("Too many background processes", r.output)

    def test_shutdown_kills_everything(self):
        r = self.ok("run_background", command="sleep 60", startup_wait=0)
        self.reg.ctx.close()
        assert_gone(self, r.meta["pid"])

    def test_web_server_can_be_started_and_queried(self):
        """The 'definition of done' flow: start a server, verify it responds, stop it."""
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        self.put("index.html", "hello from aide")
        self.ok("run_background", command=f"{sys.executable} -m http.server {port} --bind 127.0.0.1",
                name="web", startup_wait=1.0)
        fetch = (f"{sys.executable} -c \"import urllib.request as u; "
                 f"print(u.urlopen('http://127.0.0.1:{port}/index.html', timeout=3).read().decode())\"")
        r = self.ok("run_command", command=fetch)
        self.assertIn("hello from aide", r.output)
        self.assertIn("GET /index.html", self.ok("read_background", id="bg1", wait_seconds=2).output)


if __name__ == "__main__":
    unittest.main()
