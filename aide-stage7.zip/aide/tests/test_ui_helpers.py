import subprocess
import tempfile
import unittest
from pathlib import Path

from aide.ui.clipboard import copy_text
from aide.ui.commands import COMMANDS, help_text, parse_command, resolve, suggest
from aide.ui.history import InputHistory
from aide.ui.markdown import extract_code_blocks
from aide.ui.render import styled_lines


class HistoryTests(unittest.TestCase):
    def test_navigation_with_draft(self):
        h = InputHistory()
        for t in ("one", "two", "three"):
            h.add(t)
        self.assertIsNone(h.next())                       # not browsing yet
        self.assertEqual(h.previous("draft"), "three")
        self.assertEqual(h.previous("ignored"), "two")
        self.assertEqual(h.previous(""), "one")
        self.assertIsNone(h.previous(""))                 # at the oldest
        self.assertEqual(h.next(), "two")
        self.assertEqual(h.next(), "three")
        self.assertEqual(h.next(), "draft")               # back to what was being typed
        self.assertFalse(h.browsing)

    def test_duplicates_blank_and_limit(self):
        h = InputHistory(limit=3)
        for t in ("a", "a", "  ", "b", "c", "d"):
            h.add(t)
        self.assertEqual(h.items, ["b", "c", "d"])
        self.assertIsNone(InputHistory().previous("x"))

    def test_persistence_and_multiline_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sub" / "history"
            h = InputHistory(path)
            h.add("first")
            h.add("line1\nline2 \"quoted\"")
            again = InputHistory(path)
            self.assertEqual(again.items, ["first", "line1\nline2 \"quoted\""])
            path.write_text(path.read_text() + "garbage\n")
            self.assertEqual(len(InputHistory(path).items), 2)


class MarkdownTests(unittest.TestCase):
    def test_code_blocks(self):
        text = "Intro\n```python\nprint(1)\n```\ntext\n```\nplain\nblock\n```\nend"
        self.assertEqual([(b.language, b.code) for b in extract_code_blocks(text)],
                         [("python", "print(1)"), ("", "plain\nblock")])

    def test_tilde_and_longer_fences_and_inner_backticks(self):
        text = "~~~sh\nls\n~~~\n````md\n```inner\nx\n```\n````"
        blocks = extract_code_blocks(text)
        self.assertEqual([b.language for b in blocks], ["sh", "md"])
        self.assertEqual(blocks[1].code, "```inner\nx\n```")

    def test_unclosed_fence_and_no_blocks(self):
        self.assertEqual(extract_code_blocks("a\n```js\nlet x = 1;")[0].code, "let x = 1;")
        self.assertEqual(extract_code_blocks("no code here, just `inline`"), [])
        self.assertEqual(extract_code_blocks(""), [])

    def test_indented_fences_inside_lists(self):
        self.assertEqual(extract_code_blocks("1. step\n   ```bash\n   ls\n   ```")[0].language, "bash")


class ClipboardTests(unittest.TestCase):
    def test_uses_the_first_working_tool_for_the_display_server(self):
        calls = []
        def run(argv, **kw):
            calls.append((argv[0], kw["input"]))
        which = lambda n: f"/usr/bin/{n}" if n in ("xclip", "wl-copy") else None  # noqa: E731
        self.assertEqual(copy_text("héllo", which=which, run=run, env={"DISPLAY": ":0"}), "xclip")
        self.assertEqual(calls, [("xclip", "héllo".encode())])
        self.assertEqual(copy_text("x", which=which, run=run, env={"WAYLAND_DISPLAY": "w"}), "wl-copy")

    def test_failures_fall_through_to_none(self):
        def failing(argv, **kw):
            raise subprocess.CalledProcessError(1, argv)
        which = lambda n: f"/usr/bin/{n}"  # noqa: E731
        self.assertIsNone(copy_text("x", which=which, run=failing, env={"DISPLAY": ":0"}))
        self.assertIsNone(copy_text("x", which=lambda n: None, env={"DISPLAY": ":0"}))
        self.assertIsNone(copy_text("x", which=which, run=failing, env={}))      # no display at all


class CommandTests(unittest.TestCase):
    def test_parse_resolve_suggest(self):
        self.assertEqual(parse_command("/Mode  auto "), ("mode", "auto"))
        self.assertEqual(parse_command("/run echo a  b"), ("run", "echo a  b"))
        self.assertEqual(resolve("md").name, "markdown")
        self.assertEqual(resolve("quit").name, "exit")
        self.assertIsNone(resolve("nope"))
        self.assertEqual(suggest("hepl"), "help")
        self.assertEqual(suggest("sesions"), "sessions")
        self.assertIsNone(suggest("zzzzzz"))

    def test_required_commands_exist_and_help_lists_them(self):
        names = {c.name for c in COMMANDS}
        self.assertTrue({"help", "clear", "model", "mode", "undo", "diff", "tokens", "save", "exit"} <= names)
        text = help_text()
        for c in COMMANDS:
            self.assertIn(c.usage, text)
        self.assertIn("Ctrl+J", text)


class RenderTests(unittest.TestCase):
    def test_diff_lines_are_coloured_only_inside_a_diff(self):
        out = styled_lines("Edited a.py\n- not a diff line\n--- a/a.py\n+++ b/a.py\n@@ -1 +1 @@\n-old\n+new\n ctx")
        styles = [s for _, s in out]
        self.assertEqual(styles, ["", "", "bold", "bold", "cyan", "red", "green", ""])


if __name__ == "__main__":
    unittest.main()
