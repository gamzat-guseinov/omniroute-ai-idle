import asyncio
import json
import os
import signal
import stat
import tempfile
import unittest
from pathlib import Path

from aide.agent.executor import ToolExecutor
from aide.agent.permissions import Decision, PermissionPolicy
from aide.debuglog import DebugLog
from aide.safety.audit import AuditLog, summarize_args
from aide.safety.crash import install_signal_handlers, write_crash_report
from aide.safety.shadow import git_available

from .fakes import native, text
from .helpers import WorkspaceTestCase
from .test_controller import ControllerTestCase

KEY = "sk-super-secret-key-12345"


class AuditLogTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "state" / "audit.log"

    def test_entries_are_private_json_lines_without_file_contents(self):
        log = AuditLog(self.path, session="s1")
        log.tool("write_file", {"path": "a.py", "content": "x" * 5000}, decision="approved", ok=True, duration=0.0123)
        log.tool("run_command", {"command": "pytest -x"}, decision="auto", ok=False, duration=1.5,
                 exit_code=1, detail="exit code: 1")
        self.assertEqual(stat.S_IMODE(os.stat(self.path).st_mode), 0o600)
        first, second = log.tail(10)
        self.assertEqual((first["tool"], first["args"]["content"], first["session"]), ("write_file", "<5000 chars>", "s1"))
        self.assertEqual((second["args"]["command"], second["exit_code"], second["ok"]), ("pytest -x", 1, False))
        self.assertNotIn("xxxx", self.path.read_text())

    def test_rotation_redaction_and_failures(self):
        log = AuditLog(self.path, max_bytes=300, redact=lambda s: s.replace(KEY, "***"))
        for i in range(20):
            log.log("tool", note=f"{KEY} #{i}")
        self.assertTrue(self.path.with_name("audit.log.1").exists())
        self.assertNotIn(KEY, self.path.read_text() + self.path.with_name("audit.log.1").read_text())
        AuditLog(None).log("x")                                     # disabled: no-op
        self.assertEqual(AuditLog(None).tail(), [])
        AuditLog(Path("/proc/nope/audit.log")).log("x")             # unwritable: must not raise

    def test_summarize_args(self):
        self.assertEqual(summarize_args({"a": "x" * 400, "b": "short", "c": 5}), {"a": "<400 chars>", "b": "short", "c": 5})


class ExecutorSafetyTests(WorkspaceTestCase):
    def make(self, mode, approver):
        self.audit = AuditLog(Path(self.ws.parent) / "audit.log")
        self.debug = DebugLog(Path(self.ws.parent) / "debug.log", secrets=[KEY])
        ex = ToolExecutor(self.reg, PermissionPolicy(mode, self.reg.ctx.sandbox), approver,
                          audit=self.audit, debug=self.debug)
        self.addCleanup(self.reg.ctx.close)
        self.addCleanup(self.debug.close)
        return ex

    def run_tool(self, ex, name, **args):
        return asyncio.run(ex.run(name, args))

    def decisions(self):
        return [(e["tool"], e["decision"], e["ok"]) for e in self.audit.tail(20)]

    def test_every_call_is_audited_with_the_decision(self):
        answers = iter([Decision(True), Decision(True, remember=True), Decision(False)])
        ex = self.make("ask", lambda r: next(answers))
        self.put("a.txt", "x")
        self.run_tool(ex, "read_file", path="a.txt")                       # read: no question
        self.run_tool(ex, "write_file", path="b.txt", content="y")          # approved
        self.run_tool(ex, "run_command", command="echo hi")                 # approved (always)
        self.run_tool(ex, "delete_file", path="a.txt")                      # denied
        self.run_tool(ex, "read_file", path="missing.txt")                  # fails
        self.run_tool(ex, "read_file")                                      # invalid arguments
        self.run_tool(ex, "no_such_tool")
        self.assertEqual(self.decisions(), [
            ("read_file", "auto", True), ("write_file", "approved", True),
            ("run_command", "approved (always)", True), ("delete_file", "denied", False),
            ("read_file", "auto", False), ("read_file", "rejected before asking", False),
            ("no_such_tool", "unknown tool", False)])
        self.assertTrue((self.ws / "a.txt").exists())
        entries = self.audit.tail(20)
        self.assertEqual(entries[2]["args"], {"command": "echo hi"})
        self.assertEqual(entries[2]["exit_code"], 0)

    def test_our_own_secrets_never_reach_the_model_or_the_logs(self):
        ex = self.make("auto", lambda r: Decision(True))
        self.put("config.txt", f"api_key = {KEY}\nother = 1\n")
        r = self.run_tool(ex, "read_file", path="config.txt")
        self.assertNotIn(KEY, r.output)
        self.assertIn("***", r.output)
        r = self.run_tool(ex, "run_command", command="cat config.txt")
        self.assertNotIn(KEY, r.output)
        for log in ("audit.log", "debug.log"):
            self.assertNotIn(KEY, (self.ws.parent / log).read_text(), log)
        self.assertIn('"kind": "tool"', (self.ws.parent / "debug.log").read_text())

    def test_other_common_secret_shapes_are_redacted_in_logs(self):
        d = DebugLog(self.ws.parent / "d2.log")
        d.log("x", {"a": "ghp_" + "a" * 36, "b": "AKIAABCDEFGHIJKLMNOP", "c": "xoxb-1234567890-abcdef",
                    "d": "-----BEGIN RSA PRIVATE KEY-----", "e": "Bearer abc.def.ghi"})
        d.close()
        out = (self.ws.parent / "d2.log").read_text()
        for leaked in ("ghp_aaaa", "AKIAABCDEF", "xoxb-1234", "RSA PRIVATE KEY", "abc.def.ghi"):
            self.assertNotIn(leaked, out)

    def test_cancellation_is_audited(self):
        ex = self.make("auto", lambda r: Decision(True))
        async def scenario():
            task = asyncio.create_task(ex.run("run_command", {"command": "sleep 30"}))
            await asyncio.sleep(0.4)
            ex.cancel()
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        asyncio.run(scenario())
        self.assertIn(("run_command", "cancelled", False), self.decisions())


class CrashAndSignalTests(unittest.TestCase):
    def test_crash_report_has_the_traceback_but_no_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            try:
                raise RuntimeError("boom " + "x")
            except RuntimeError as exc:
                path = write_crash_report(exc, Path(tmp), "testing")
            text_ = path.read_text()
            self.assertIn("RuntimeError: boom x", text_)
            self.assertIn("testing", text_)
            self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
            self.assertIsNone(write_crash_report(RuntimeError("x"), Path("/proc/nope")))

    def test_sigterm_and_sighup_become_a_clean_exit(self):
        old = {s: signal.getsignal(s) for s in (signal.SIGTERM, signal.SIGHUP)}
        self.addCleanup(lambda: [signal.signal(s, h) for s, h in old.items()])
        install_signal_handlers()
        for sig in (signal.SIGTERM, signal.SIGHUP):
            with self.assertRaises(SystemExit) as ctx:
                signal.raise_signal(sig)
            self.assertEqual(ctx.exception.code, 128 + sig)


class ControllerRobustnessTests(ControllerTestCase):
    async def test_a_bug_in_a_command_does_not_break_the_interface(self):
        self.make()
        def broken(arg):
            raise RuntimeError("kaboom")
        self.ctl._cmd_help = broken
        await self.say("/help")
        self.assertEqual(self.view.texts[-1][0], "error")
        self.assertIn("kaboom", self.view.last())
        self.assertIn("crash.log", self.view.last())
        self.assertIn("RuntimeError: kaboom", (self.state / "crash.log").read_text())
        await self.say("/tokens")                                   # still works afterwards
        self.assertIn("Context:", self.view.last())

    async def test_a_bug_inside_the_agent_task_is_reported_and_leaves_things_usable(self):
        self.make([RuntimeError("model client exploded")])
        await self.say("hi")
        self.assertIn("Unexpected error", " ".join(self.view.messages("error")))
        self.assertFalse(self.ctl.busy)
        self.assertTrue((self.state / "crash.log").exists())

    @unittest.skipUnless(git_available(), "git is not installed")
    async def test_undo_reverts_what_a_shell_command_did(self):
        (self.ws / "data.txt").write_text("precious\n")
        self.make([native(("run_command", {"command": "echo ruined > data.txt && rm -f nothing && touch made.txt"})),
                   text("Done.")])
        await self.say("clean up the data")
        self.assertEqual((self.ws / "data.txt").read_text(), "ruined\n")
        await self.say("/diff")
        self.assertIn("-precious", self.view.diffs[-1])
        await self.say("/undo")
        self.assertEqual((self.ws / "data.txt").read_text(), "precious\n")
        self.assertFalse((self.ws / "made.txt").exists())
        self.assertIn("data.txt", self.view.last())

    async def test_audit_command_and_welcome_describe_the_safety_features(self):
        (self.ws / "a.txt").write_text("x")
        self.make([native(("read_file", {"path": "a.txt"})), text("ok")])
        self.assertIn("undo:", self.view.messages("info")[0])
        await self.say("read it")
        await self.say("/audit")
        self.assertIn("read_file", self.view.last())
        self.assertIn("audit.log", self.view.last())

    async def test_audit_can_be_switched_off(self):
        self.make(cfg={"audit_log": False})
        await self.say("/audit")
        self.assertIn("switched off", self.view.last())
        self.assertFalse((self.state / "audit.log").exists())


if __name__ == "__main__":
    unittest.main()
