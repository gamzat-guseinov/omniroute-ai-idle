import unittest

from aide.config import ConfigError, load_config
from aide.formats.model import ToolCall
from aide.tools.base import ToolResult
from aide.ui.render import describe_call, result_lines, status_symbol


class RenderTests(unittest.TestCase):
    def test_call_summaries(self):
        c = lambda name, **a: describe_call(ToolCall(name, a))  # noqa: E731
        self.assertEqual(c("read_file", path="a.py", start_line=3, end_line=9), "read_file a.py:3-9")
        self.assertEqual(c("run_command", command="pytest -x"), "run_command pytest -x")
        self.assertEqual(c("move_file", source="a", destination="b"), "move_file a -> b")
        self.assertEqual(c("search", pattern="TODO"), "search 'TODO' in .")
        self.assertEqual(c("stop_background", id="bg1"), "stop_background bg1")
        self.assertLessEqual(len(c("run_command", command="x" * 500)), 100)
        self.assertEqual(c("run_command", command="a\n  b"), "run_command a b")

    def test_result_preview_and_symbols(self):
        out = "\n".join(f"line {i}" for i in range(20))
        lines = result_lines(ToolResult(True, out))
        self.assertEqual(len(lines), 9)
        self.assertEqual(lines[-1], "… 12 more lines")
        self.assertEqual(status_symbol(ToolResult(True, "")), "✓")
        self.assertEqual(status_symbol(ToolResult(False, "")), "✗")
        self.assertEqual(status_symbol(ToolResult(False, "", meta={"denied": True})), "⊘")


class NewConfigTests(unittest.TestCase):
    def load(self, **env):
        return load_config(None, env={f"OMNIROUTE_{k.upper()}": v for k, v in env.items()}, overrides=None) \
            if False else load_config(__import__("pathlib").Path("/nonexistent/c.toml"),
                                      env={f"OMNIROUTE_{k.upper()}": v for k, v in env.items()})

    def test_defaults_and_validation(self):
        cfg = self.load()
        self.assertEqual((cfg.tool_format, cfg.max_tool_calls, cfg.context_tokens, cfg.permission_mode),
                         ("native", 25, 64000, "ask"))
        self.assertEqual(self.load(tool_format="dsml").tool_format, "dsml")
        for bad in ({"tool_format": "yaml"}, {"max_tool_calls": "0"}, {"context_tokens": "500"},
                    {"permission_mode": "yolo"}):
            with self.assertRaises(ConfigError, msg=bad):
                self.load(**bad)


if __name__ == "__main__":
    unittest.main()
